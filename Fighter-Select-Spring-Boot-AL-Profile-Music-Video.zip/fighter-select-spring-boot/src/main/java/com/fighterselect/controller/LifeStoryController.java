package com.fighterselect.controller;

import com.fighterselect.model.LifeStory;
import com.fighterselect.service.LifeStoryService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/life-stories")
public class LifeStoryController {
    private final LifeStoryService service;

    public LifeStoryController(LifeStoryService service) {
        this.service = service;
    }

    @GetMapping
    public List<LifeStory> all() {
        return service.findAll();
    }

    @GetMapping("/{playerId}")
    public LifeStory one(@PathVariable String playerId) {
        return service.findByPlayerId(playerId);
    }
}
