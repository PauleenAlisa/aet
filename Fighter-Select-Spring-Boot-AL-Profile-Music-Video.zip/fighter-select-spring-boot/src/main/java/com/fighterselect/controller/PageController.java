package com.fighterselect.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/** Allow refreshing or deep-linking to an interactive page. */
@Controller
public class PageController {
    @GetMapping({
            "/", "/select", "/versus", "/roster",
            "/life/{playerId}",
            "/profile/{playerId}",
            "/profile/{playerId}/music",
            "/profile/{playerId}/video/{videoId}",
            "/profile/{playerId}/games",
            "/profile/{playerId}/games/{gameSlug}",
            "/profile/{playerId}/hobby/{hobbySlug}"
    })
    public String app() {
        return "forward:/index.html";
    }
}
