package com.fighterselect.controller;

import com.fighterselect.model.Player;
import com.fighterselect.service.PlayerService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class PlayerController {
    private final PlayerService service;

    public PlayerController(PlayerService service) {
        this.service = service;
    }

    @GetMapping("/players")
    public List<Player> players() {
        return service.findAll();
    }

    @GetMapping("/players/{id}")
    public Player player(@PathVariable String id) {
        return service.findById(id);
    }

    @GetMapping("/health")
    public Map<String, Object> health() {
        return Map.of("status", "UP", "fighterCount", service.findAll().size());
    }
}
