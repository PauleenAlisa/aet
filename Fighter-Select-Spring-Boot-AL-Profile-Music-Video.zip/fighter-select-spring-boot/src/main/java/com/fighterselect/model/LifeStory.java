package com.fighterselect.model;

import java.util.List;
import java.util.Map;

/** College-only, character-specific branching story and its editable game data. */
public record LifeStory(
        String playerId,
        String alias,
        String tagline,
        String intro,
        String startNode,
        Map<String, Integer> startingStats,
        int startingAcademics,
        Map<String, Integer> startingBonds,
        Map<String, LifeNode> nodes,
        Map<String, LifeEnding> endings
) {
    public record LifeNode(
            int age,
            String year,
            int semester,
            String category,
            String emoji,
            String title,
            String prompt,
            List<LifeChoice> choices
    ) {}

    public record LifeChoice(
            String label,
            String result,
            String next,
            Map<String, Integer> effects,
            Map<String, Integer> bonds,
            int grades,
            String path,
            Map<String, Integer> needs
    ) {}

    public record LifeEnding(String title, String description) {}
}
