# Life Mode — 1st Year to 4th Year (Spring Boot)

## How it works

1. Start at the character select screen, select JI, PAU, AL, or MOND, then **VIEW CHARACTER PROFILE**.
2. Read the full character profile first. Click **PLAY THIS LIFE** on the profile to enter the simulation.
3. Begin as an 18-year-old **first-year college IT student**. Make choices through first, second, third, and fourth year (two semesters each).
4. Each of the four characters has **40 college-life milestone events** and **20 consequence decisions**. That means **60 story decisions per completed playthrough**, not counting optional activities.
5. Choices affect five personal stats, **academic standing**, and relationships with **friends, family, mentors, romance, and career contacts**. Some special choices require minimum academic standing.
6. **Campus Free Time** offers up to **two optional activities per semester** (studying, friends, resting, or side projects). They influence stats without advancing the story; 16 activity opportunities are available across eight semesters.
7. All paths end with **college graduation after fourth year**. Graduation summaries depend on the decisions made.
8. **UNDO LAST CHOICE** restores the state before that decision, including later optional activities; **RESTART** begins a fresh college life. Progress saves automatically in this browser using localStorage.

## Character story themes

| Player | Themes |
|---|---|
| JI | Strategy gaming, teamwork, code quality, personal projects |
| PAU | Digital art, UI design, accessible interfaces, creativity |
| AL | Music, photography, storytelling, media technology |
| MOND | Sports, campus events, group organization, game platforms |

These are **fictional branching college stories**, inspired by the existing roster descriptions and not records of real people's lives.

## What the simulation covers

- **Year 1:** Orientation, campus life, coding labs, time management, organizations, money, first exams, new relationships, group projects.
- **Year 2:** Java OOP, databases, club leadership, friend conflict, part-time work, hackathons, relationship milestones, portfolio building.
- **Year 3:** Data structures, internships, full-stack apps, burnout, research topics, interviews, academic integrity, mentors.
- **Year 4:** Capstone planning, real-world data limitations, practicum, group disagreements, mock defense, job applications, final defense, school clearance, and the last college day.

## Edit the story

The Java backend serves the content at `GET /api/life-stories` and `GET /api/life-stories/{playerId}`. Edit:

`src/main/resources/data/life-stories.json`

Story nodes each include age (18–21 for gameplay, 22 for graduation), year, semester, event title/prompt, and two or three choices. A choice has `label`, `result`, `next`, `effects` (personal stat differences), `bonds` (relationship differences), `grades` (academic score difference), `path` (study, heart, bold), and optional `needs` (required academic/stat/relationship score). The Java startup validator rejects broken links, invalid ages, loops, and unreachable scenes.

## Technical details

- Java JDK 17+, Spring Boot 3.5.6, Maven 3.9+, Spring MVC REST API.
- Vanilla JS/CSS browser UI. No React dev server or database required.
- Per-character saves use localStorage, version `3`. Earlier five-decision saves are preserved under their old keys but deliberately not loaded by this edition.
- Run with `mvn spring-boot:run` and open http://localhost:8080.
