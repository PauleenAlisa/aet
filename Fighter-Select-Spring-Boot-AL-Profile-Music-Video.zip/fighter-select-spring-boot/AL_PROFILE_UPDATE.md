# AL Profile Update — The Only Child

AL is the fighter mapped to `echo` in the Spring Boot data. This update includes the profile details supplied by the user.

## Your updates

- Title: **The Only Child**
- Motto: *You can't have an easy life and a great character. You only get to choose one.*
- Soundtrack (five favorites): Dilaw — Uhaw; The Jackson 5 — Who's Loving You; Asin — Masdan Mo ang Kapaligiran; Luther Vandross — Dance with My Father; Eraserheads — Spoliarium
- Favorite games: League of Legends, VALORANT, FIFA, NBA 2K, Mobile Legends: Bang Bang
- Stats: Analytical and System Design Thinking 78%; Discipline and Consistency 94%; Backend Logic 68%; Leadership and Operations 60%; Clutch Adaptability 88%
- Four supplied fun facts, four skills, and four hobbies (physical sports, chess, music discovery, esports)
- **Music video chosen:** Dilaw — Uhaw (Tayong Lahat), official artist video: https://www.youtube.com/watch?v=rWF42VRvsLg

## How to view

1. Run `mvn spring-boot:run`, then open `http://localhost:8080`.
2. Select **AL** on the fighter selection screen and choose **VIEW CHARACTER PROFILE**.
3. Scroll through stats, fun facts, skills, hobbies, and **AL SOUNDTRACK**. The official YouTube video is embedded on AL's profile.
4. Scroll to **LIFE JOURNEY (18 MILESTONES)**. These are **fictional college-life game events** that unlock as AL's story progresses, not claims about real-life events.
5. Click **PLAY AL'S LIFE** to play the eight-semester story, including four AL-specific extra activities and graduation ending.

## Music attribution and behavior

This project does not distribute or host commercial audio recordings. Only the official Dilaw video is embedded using the YouTube player. Other songs are named in the playlist with links to YouTube search, not guaranteed verified videos. You need Internet access to watch the embedded video; embedding may be disabled by the source owner.

## Files edited

- `src/main/resources/data/players.json` — AL profile data
- `src/main/resources/data/life-stories.json` — AL college-life story detail revisions
- `src/main/resources/static/js/app.js` — profile sections, 18 milestone unlocks, embedded video, 4 AL side activities
- `src/main/resources/static/css/app.css` — responsive soundtrack and milestone sections
- `src/main/java/com/fighterselect/model/Player.java` — nullable ability ratings to avoid inventing percentages
- `src/test/java/com/fighterselect/FighterSelectApplicationTests.java` — AL API assertions
