export type Ability = {
  kind: string
  name: string
  description: string
  level: number
}

export type Track = {
  title: string
  artist: string
  src: string
}

export type Game = {
  slug: string
  title: string
  category: string
  platform: string
  role: string
  description: string
  cover: string
  videoId?: string
}

export type Hobby = {
  slug: string
  name: string
  kicker: string
  description: string
  items: string[]
}

export type Player = {
  id: string
  number: string
  fighterId: string
  name: string
  nickname: string
  age: string
  birthday: string
  role: string
  title: string
  personality: string
  intro: string
  quote: string
  portrait: string
  hoverPortrait: string
  photoCredit: string
  accent: string
  accent2: string
  rgb: string
  stats: Record<string, number>
  abilities: Ability[]
  hobbies: Hobby[]
  artists: string[]
  genres: string[]
  tracks: Track[]
  videos: { id: string; title: string; artist: string; description: string }[]
  games: Game[]
  funFacts: string[]
}

const audio = [
  'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
  'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
  'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
]

export const players: Player[] = [
  {
    id: 'nova',
    number: '01',
    fighterId: 'FTR-001',
    name: 'Player 01 Name',
    nickname: 'NOVA',
    age: 'Add age',
    birthday: 'Add birthday',
    role: 'Add course or occupation',
    title: 'The Cool One',
    personality: 'Focused / Competitive / Calm',
    intro: 'A calculated contender who turns quiet focus into perfect timing.',
    quote: '“Stay sharp. Move smarter.”',
    portrait:
      'https://images.unsplash.com/photo-1644353224392-7e532d7b8f4b?crop=faces&fit=crop&w=1200&h=1600&q=86',
    hoverPortrait:
      'https://images.unsplash.com/photo-1620215175664-cb9a6f5b6103?crop=faces&fit=crop&w=1200&h=1600&q=86',
    photoCredit: 'Photo by Victor Serban on Unsplash',
    accent: '#72DDF7',
    accent2: '#FF8FA3',
    rgb: '114,221,247',
    stats: { Creativity: 84, Intelligence: 92, Confidence: 88, Humor: 64, Gaming: 96 },
    abilities: [
      { kind: 'Passive', name: 'Tactical Read', description: 'Spots the winning route before the round begins.', level: 92 },
      { kind: 'Special', name: 'Clutch Mode', description: 'Focus increases when the pressure is highest.', level: 88 },
      { kind: 'Ultimate', name: 'Perfect Counter', description: 'Turns one small opening into a complete comeback.', level: 96 },
    ],
    hobbies: [
      { slug: 'gaming', name: 'Gaming', kicker: 'Ranked mode', description: 'Competitive queues, clean mechanics, and one more match.', items: ['Team strategy', 'Fighting games', 'Late-night ranked'] },
      { slug: 'photography', name: 'Photography', kicker: 'Street frames', description: 'Chasing sharp geometry and electric city light.', items: ['Night portraits', 'Architecture', 'Color studies'] },
      { slug: 'reading', name: 'Reading', kicker: 'Mind library', description: 'Ideas worth bookmarking and stories worth replaying.', items: ['Sci-fi', 'Strategy', 'Graphic novels'] },
    ],
    artists: ['Add favorite artist', 'Add favorite artist', 'Add favorite artist'],
    genres: ['Alt R&B', 'Electronic', 'Hip-hop'],
    tracks: [
      { title: 'Neon Run — Demo', artist: 'SoundHelix', src: audio[0] },
      { title: 'Blue Shift — Demo', artist: 'SoundHelix', src: audio[1] },
      { title: 'Final Round — Demo', artist: 'SoundHelix', src: audio[2] },
    ],
    videos: [{ id: 'dQw4w9WgXcQ', title: 'Add favorite music video', artist: 'Add artist', description: 'Replace this authorized YouTube video ID in src/data.ts.' }],
    games: [
      { slug: 'tekken-8', title: 'Add favorite fighter', category: 'Competitive', platform: 'Add platform', role: 'Add main character', description: 'Add a personal highlight or reason this game belongs in the loadout.', cover: '01', videoId: 'ToYthh-_Xk0' },
      { slug: 'valorant', title: 'Add squad game', category: 'Multiplayer', platform: 'PC', role: 'Add in-game role', description: 'Add favorite mode, in-game name, and a memorable match.', cover: '02' },
    ],
    funFacts: ['Add a surprising fun fact', 'Add a hidden talent', 'Add a signature habit'],
  },
  {
    id: 'mimi',
    number: '02',
    fighterId: 'FTR-002',
    name: 'Player 02 Name',
    nickname: 'MIMI',
    age: 'Add age',
    birthday: 'Add birthday',
    role: 'Add course or occupation',
    title: 'The Cutie',
    personality: 'Warm / Playful / Bright',
    intro: 'A sparkling support-class hero with unstoppable good energy.',
    quote: '“Soft heart. Strong combo.”',
    portrait:
      'https://images.unsplash.com/photo-1559828801-04565cd31e27?crop=faces&fit=crop&w=1200&h=1600&q=86',
    hoverPortrait:
      'https://images.unsplash.com/photo-1634910440823-193b061d28a5?crop=faces&fit=crop&w=1200&h=1600&q=86',
    photoCredit: 'Photo by Daniel Monteiro on Unsplash',
    accent: '#FF91CF',
    accent2: '#C7B3FF',
    rgb: '255,145,207',
    stats: { Creativity: 96, Intelligence: 78, Confidence: 82, Humor: 91, 'Social Energy': 94 },
    abilities: [
      { kind: 'Passive', name: 'Mood Booster', description: 'Adds positive status effects to the entire party.', level: 96 },
      { kind: 'Special', name: 'Playlist Magic', description: 'Always finds the right song for the exact moment.', level: 94 },
      { kind: 'Ultimate', name: 'Charm Burst', description: 'Converts awkward silence into instant friendship.', level: 91 },
    ],
    hobbies: [
      { slug: 'art', name: 'Digital Art', kicker: 'Create mode', description: 'Cute characters, bright palettes, and tiny details.', items: ['Character art', 'Stickers', 'Color palettes'] },
      { slug: 'anime', name: 'Anime', kicker: 'Watch list', description: 'Comfort shows, dramatic arcs, and favorite openings.', items: ['Add favorite series', 'Add comfort show', 'Add favorite hero'] },
      { slug: 'cooking', name: 'Cooking', kicker: 'Co-op kitchen', description: 'Small treats and recipes made to share.', items: ['Add signature dish', 'Dessert nights', 'Recipe experiments'] },
    ],
    artists: ['Add favorite artist', 'Add favorite artist', 'Add favorite artist'],
    genres: ['K-pop', 'Pop', 'Indie'],
    tracks: [
      { title: 'Sugar Rush — Demo', artist: 'SoundHelix', src: audio[1] },
      { title: 'Dream Lobby — Demo', artist: 'SoundHelix', src: audio[2] },
      { title: 'Heart Combo — Demo', artist: 'SoundHelix', src: audio[0] },
    ],
    videos: [{ id: '9bZkp7q19f0', title: 'Add favorite music video', artist: 'Add artist', description: 'Replace this authorized YouTube video ID in src/data.ts.' }],
    games: [{ slug: 'cozy-game', title: 'Add favorite cozy game', category: 'Casual', platform: 'Add platform', role: 'Add favorite character', description: 'Add what makes this game the perfect comfort pick.', cover: '01' }],
    funFacts: ['Add a cute collection', 'Add a comfort food', 'Add an unexpected skill'],
  },
  {
    id: 'echo',
    number: '03',
    fighterId: 'FTR-003',
    name: 'Player 03 Name',
    nickname: 'ECHO',
    age: 'Add age',
    birthday: 'Add birthday',
    role: 'Add course or occupation',
    title: 'The Mystery',
    personality: 'Observant / Creative / Low-key',
    intro: 'An unreadable wildcard whose best moves arrive without warning.',
    quote: '“Not everything needs an explanation.”',
    portrait:
      'https://images.unsplash.com/photo-1520563683082-7ef74b616a89?crop=faces&fit=crop&w=1200&h=1600&q=86',
    hoverPortrait:
      'https://images.unsplash.com/flagged/photo-1579451443170-44b3963c3341?crop=faces&fit=crop&w=1200&h=1600&q=86',
    photoCredit: 'Photo by Yoal Desurmont on Unsplash',
    accent: '#A992F7',
    accent2: '#8EC5FC',
    rgb: '169,146,247',
    stats: { Creativity: 93, Intelligence: 89, Confidence: 74, Humor: 80, 'Music Knowledge': 97 },
    abilities: [
      { kind: 'Passive', name: 'Quiet Scan', description: 'Notices the detail everybody else missed.', level: 93 },
      { kind: 'Special', name: 'Plot Twist', description: 'Changes the energy of a round without warning.', level: 87 },
      { kind: 'Ultimate', name: 'Midnight Mix', description: 'Builds a soundtrack that rewrites the whole mood.', level: 97 },
    ],
    hobbies: [
      { slug: 'music', name: 'Music Digging', kicker: 'Deep cuts', description: 'Finding the track before the algorithm does.', items: ['Hidden gems', 'Album artwork', 'Late-night listening'] },
      { slug: 'travel', name: 'Travel', kicker: 'Open map', description: 'Quiet streets, unfamiliar places, and stories to keep.', items: ['Add dream city', 'Photo walks', 'Local cafés'] },
      { slug: 'films', name: 'Films', kicker: 'Director mode', description: 'Atmospheric stories and frames that linger.', items: ['Add favorite film', 'Mystery', 'Animation'] },
    ],
    artists: ['Add favorite artist', 'Add favorite artist', 'Add favorite artist'],
    genres: ['Dream pop', 'Alternative', 'Lo-fi'],
    tracks: [
      { title: 'Afterimage — Demo', artist: 'SoundHelix', src: audio[2] },
      { title: 'No Signal — Demo', artist: 'SoundHelix', src: audio[0] },
      { title: 'Hidden Level — Demo', artist: 'SoundHelix', src: audio[1] },
    ],
    videos: [{ id: 'kJQP7kiw5Fk', title: 'Add favorite music video', artist: 'Add artist', description: 'Replace this authorized YouTube video ID in src/data.ts.' }],
    games: [{ slug: 'story-game', title: 'Add favorite story game', category: 'Story Games', platform: 'Add platform', role: 'Add favorite character', description: 'Add the story beat or world that made this one memorable.', cover: '01' }],
    funFacts: ['Add a niche interest', 'Add a favorite place', 'Add a plot twist'],
  },
  {
    id: 'jax',
    number: '04',
    fighterId: 'FTR-004',
    name: 'Player 04 Name',
    nickname: 'JAX',
    age: 'Add age',
    birthday: 'Add birthday',
    role: 'Add course or occupation',
    title: 'The Chaotic One',
    personality: 'Bold / Spontaneous / Funny',
    intro: 'A high-energy rushdown fighter powered by ideas and bad timing.',
    quote: '“Plan B is where the fun starts.”',
    portrait:
      'https://images.unsplash.com/photo-1620215175664-cb9a6f5b6103?crop=faces&fit=crop&w=1200&h=1600&q=86',
    hoverPortrait:
      'https://images.unsplash.com/photo-1655373325205-bbae7ede0e21?crop=faces&fit=crop&w=1200&h=1600&q=86',
    photoCredit: 'Photo by Andrey Zvyagintsev on Unsplash',
    accent: '#FFBE5C',
    accent2: '#B9E77B',
    rgb: '255,190,92',
    stats: { Creativity: 88, Intelligence: 81, Confidence: 98, Humor: 99, 'Social Energy': 96 },
    abilities: [
      { kind: 'Passive', name: 'Unplanned Combo', description: 'Accidentally discovers the funniest possible outcome.', level: 99 },
      { kind: 'Special', name: 'Energy Spike', description: 'Turns a quiet room into the main event.', level: 96 },
      { kind: 'Ultimate', name: 'Chaos Theory', description: 'No one knows the plan, but somehow it works.', level: 98 },
    ],
    hobbies: [
      { slug: 'gaming', name: 'Party Games', kicker: 'Four-player mode', description: 'Fast rounds, loud victories, dramatic rematches.', items: ['Local multiplayer', 'Mobile games', 'Wild challenges'] },
      { slug: 'sports', name: 'Sports', kicker: 'Match day', description: 'Big moments, friendly rivalries, and full-send energy.', items: ['Add favorite team', 'Add favorite player', 'Add a highlight'] },
      { slug: 'dance', name: 'Dancing', kicker: 'Rhythm mode', description: 'Learning the move, then adding a little extra.', items: ['Add dance style', 'Freestyle', 'Group routines'] },
    ],
    artists: ['Add favorite artist', 'Add favorite artist', 'Add favorite artist'],
    genres: ['Dance', 'Rock', 'Anything loud'],
    tracks: [
      { title: 'Bonus Round — Demo', artist: 'SoundHelix', src: audio[0] },
      { title: 'Full Send — Demo', artist: 'SoundHelix', src: audio[2] },
      { title: 'No Rules — Demo', artist: 'SoundHelix', src: audio[1] },
    ],
    videos: [{ id: 'fJ9rUzIMcZQ', title: 'Add favorite music video', artist: 'Add artist', description: 'Replace this authorized YouTube video ID in src/data.ts.' }],
    games: [
      { slug: 'party-game', title: 'Add favorite party game', category: 'Multiplayer', platform: 'Add platform', role: 'Chaos agent', description: 'Add the group story that gets retold every time this game appears.', cover: '01' },
      { slug: 'mobile-game', title: 'Add favorite mobile game', category: 'Mobile Games', platform: 'Mobile', role: 'Add in-game name', description: 'Add a favorite mode and current personal best.', cover: '02' },
    ],
    funFacts: ['Add the funniest story', 'Add a competitive habit', 'Add a signature phrase'],
  },
]

export const getPlayer = (id?: string) => players.find((player) => player.id === id) ?? players[0]
