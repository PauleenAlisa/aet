import { CSSProperties, ReactNode, useEffect, useRef, useState } from 'react'
import {
  createBrowserRouter,
  Link,
  Navigate,
  Outlet,
  RouterProvider,
  useLocation,
  useNavigate,
  useOutletContext,
  useParams,
} from 'react-router'
import selectedPlayerBasePose from '@/imports/763925829_1039672735429831_7750910218737029479_n.jpg'
import selectedPlayerHoverPose from '@/imports/5009b66c-6554-4adc-8bf4-c701f24f4834.jpg'
import { getPlayer, Player, players } from './data'

type ThemeStyle = CSSProperties & { '--accent': string; '--accent-2': string; '--accent-rgb': string }
type LifeStat = 'Happiness' | 'Energy' | 'Smarts' | 'Confidence' | 'Social'
type LifeStats = Record<LifeStat, number>

const selectNames: Record<string, string> = {
  nova: 'JI',
  mimi: 'PAU',
  echo: 'AL',
  jax: 'MOND',
}

const selectTitles: Record<string, string> = {
  nova: 'Sunoo',
  mimi: 'Alisa',
  echo: 'Juvir',
  jax: 'Dekaizer',
}

const theme = (player: Player): ThemeStyle => ({
  '--accent': player.accent,
  '--accent-2': player.accent2,
  '--accent-rgb': player.rgb,
})

function Icon({ name }: { name: 'arrow' | 'sound' | 'mute' | 'play' | 'pause' | 'next' | 'back' | 'spark' }) {
  const glyphs = {
    arrow: '→',
    sound: ')))',
    mute: '×',
    play: '▶',
    pause: 'Ⅱ',
    next: '▶|',
    back: '←',
    spark: '✦',
  }
  return (
    <span aria-hidden="true" className={`icon icon--${name}`}>
      {glyphs[name]}
    </span>
  )
}

function Button({
  children,
  onClick,
  variant = 'primary',
  type = 'button',
  disabled,
}: {
  children: ReactNode
  onClick?: () => void
  variant?: 'primary' | 'ghost'
  type?: 'button' | 'submit'
  disabled?: boolean
}) {
  return (
    <button className={`button button--${variant}`} disabled={disabled} onClick={onClick} type={type}>
      {children}
    </button>
  )
}

function Portrait({
  player,
  className = '',
  interactive = false,
  portraitSrc,
  hoverPortraitSrc,
}: {
  player: Player
  className?: string
  interactive?: boolean
  portraitSrc?: string
  hoverPortraitSrc?: string
}) {
  const [failed, setFailed] = useState(false)
  const [hoverFailed, setHoverFailed] = useState(false)
  return (
    <div className={`portrait ${interactive ? 'portrait--interactive' : ''} ${className}`}>
      {failed ? (
        <div className="portrait__fallback">{player.nickname.slice(0, 1)}</div>
      ) : (
        <img
          alt={`${player.nickname} placeholder portrait`}
          className="portrait__pose portrait__pose--base"
          onError={() => setFailed(true)}
          src={portraitSrc ?? player.portrait}
        />
      )}
      {interactive && !hoverFailed && (
        <img
          alt=""
          aria-hidden="true"
          className="portrait__pose portrait__pose--hover"
          onError={() => setHoverFailed(true)}
          src={hoverPortraitSrc ?? player.hoverPortrait}
        />
      )}
      <div className="portrait__scan" />
    </div>
  )
}

function SoundToggle({ muted, setMuted }: { muted: boolean; setMuted: (value: boolean) => void }) {
  return (
    <button
      aria-label={muted ? 'Enable interface sound' : 'Mute interface sound'}
      className="sound-toggle"
      onClick={() => setMuted(!muted)}
      type="button"
    >
      <Icon name={muted ? 'mute' : 'sound'} />
      <span>{muted ? 'SFX OFF' : 'SFX ON'}</span>
    </button>
  )
}

function Ambient({ accent = 'cyan' }: { accent?: string }) {
  return (
    <div aria-hidden="true" className={`ambient ambient--${accent}`}>
      <div className="grid-floor" />
      <div className="orb orb--one" />
      <div className="orb orb--two" />
      <div className="noise" />
    </div>
  )
}

function BootScreen({ muted, setMuted }: { muted: boolean; setMuted: (value: boolean) => void }) {
  const navigate = useNavigate()
  return (
    <main className="boot screen">
      <Ambient />
      <div className="topbar">
        <div className="brand-mark">FS // 24</div>
        <SoundToggle muted={muted} setMuted={setMuted} />
      </div>
      <div className="boot__content">
        <div className="eyebrow">BSIT 3-2</div>
        <div aria-label="Fighter Select" className="mega-title">
          <span>PROFILE</span>
          <span className="mega-title__outline">SELECT</span>
        </div>
        <p className="boot__subtitle">uwu</p>
        <Button onClick={() => navigate('/select')}>
          START{'\u00A0\u00A0'} <Icon name="arrow" />
        </Button>
        <div className="press-start">PRESS START TO CONTINUE</div>
      </div>
      <div className="boot__footer">
        <span>Jaemar Ibanez</span>
        <span>Alfrancis Juvir Delos Trino</span>
        <span>Pauleen Alisa Amatorio</span>
        <span>Richmond Ebasan</span>
      </div>
    </main>
  )
}

function SelectScreen() {
  const [selected, setSelected] = useState<Player | null>(null)
  const [hovered, setHovered] = useState<Player>(players[0])
  const navigate = useNavigate()

  const randomize = () => {
    const choice = players[Math.floor(Math.random() * players.length)]
    setSelected(choice)
    setHovered(choice)
  }

  return (
    <main className="select screen" style={theme(selected ?? hovered)}>
      <Ambient accent="red" />
      <header className="select__header">
        <Link className="mini-brand" key="profile-select-brand-v2" to="/">
          <span>
            PROFILE <span className="fg-inline-bold">SELECT</span>
          </span>
        </Link>
        <div className="round-label">ROSTER / 04</div>
      </header>
      <section className="select__intro">
        <div>
          <div className="eyebrow">YOOHOOOO PILI NA!</div>
          <div className="display-title">SELECT STUDENT</div>
        </div>
        <p>{selected ? 'Selection locked. Confirm your fighter.' : hovered.intro}</p>
      </section>
      <section className="fighter-grid" aria-label="Fighter roster">
        {players.map((player) => (
          <button
            aria-pressed={selected?.id === player.id}
            className={`fighter-card ${selected?.id === player.id ? 'is-selected' : ''}`}
            key={player.id}
            onClick={() => {
              setSelected(player)
              setHovered(player)
            }}
            onFocus={() => setHovered(player)}
            onMouseEnter={() => setHovered(player)}
            style={theme(player)}
            type="button"
          >
            <Portrait
              hoverPortraitSrc={player.id === 'nova' ? selectedPlayerHoverPose : undefined}
              interactive
              player={player}
              portraitSrc={player.id === 'nova' ? selectedPlayerBasePose : undefined}
            />
            <div className="fighter-card__shade" />
            <div className="fighter-card__number">{player.number}</div>
            <div className="fighter-card__meta">
              <span>PLAYER {player.number}</span>
              <strong>{selectNames[player.id]}</strong>
              <small key={`select-title-${player.id}-${selectTitles[player.id]}`}>
                {selectTitles[player.id]}
              </small>
            </div>
            <div className="fighter-card__corner">+</div>
          </button>
        ))}
      </section>
      <section className="selection-bar">
        <div className="selection-bar__status">
          <span key={selected ? 'selected-caption' : 'current-target-caption'}>
            {selected ? 'SELECTED:' : 'CURRENT TARGET'}
          </span>
          <strong>{selectNames[(selected ?? hovered).id]}</strong>
          <small>{selected ? selectTitles[selected.id] : 'Click to lock in'}</small>
        </div>
        <div className="selection-bar__actions">
          <Button onClick={randomize} variant="ghost">
            RANDOM SELECT
          </Button>
          <Button disabled={!selected} onClick={() => selected && navigate(`/life/${selected.id}`)}>
            {selected ? 'READY / CONFIRM' : 'SELECT A FIGHTER'} <Icon name="arrow" />
          </Button>
        </div>
      </section>
      <nav className="select__nav" aria-label="Secondary navigation">
        <Link to="/">BACK TO MENU</Link>
        <Link to="/versus">GROUP VERSUS</Link>
      </nav>
    </main>
  )
}

type LifeChoice = {
  label: string
  outcome: string
  effects: Partial<LifeStats>
}

type LifeChapter = {
  age: number
  kicker: string
  title: string
  prompt: (player: Player) => string
  choices: (player: Player) => LifeChoice[]
}

const lifeChapters: LifeChapter[] = [
  {
    age: 18,
    kicker: "FIRST DAY / BSIT 3-2",
    title: "A NEW SAVE FILE",
    prompt: () =>
      "You walk into class and spot a room full of possible party members. What is your opening move?",
    choices: () => [
      {
        label: "Introduce yourself first",
        outcome:
          "You broke the ice. A future group chat was born before lunch.",
        effects: { Confidence: 9, Social: 12, Energy: -4 },
      },
      {
        label: "Find a seat and observe",
        outcome: "You quietly mapped the room and remembered everyone’s name.",
        effects: { Smarts: 10, Confidence: 3, Social: -2 },
      },
    ],
  },
  {
    age: 19,
    kicker: "MIDTERM ARC",
    title: "THE DEADLINE BOSS",
    prompt: () =>
      "A major project is due tomorrow and the progress bar is looking dangerous. How do you play it?",
    choices: () => [
      {
        label: "Call the squad for co-op",
        outcome:
          "Everyone brought one strong skill. The build shipped with minutes to spare.",
        effects: { Social: 10, Smarts: 7, Happiness: 8, Energy: -8 },
      },
      {
        label: "Enter solo focus mode",
        outcome:
          "Headphones on. Notifications off. You found the bug at 2:13 AM.",
        effects: { Smarts: 13, Confidence: 8, Energy: -14, Happiness: -3 },
      },
    ],
  },
  {
    age: 20,
    kicker: "BONUS ROUND",
    title: "A FREE AFTERNOON",
    prompt: (player) =>
      `Classes end early. ${player.hobbies[0]?.name ?? "Your favorite hobby"} is calling your name.`,
    choices: (player) => [
      {
        label: `Choose ${player.hobbies[0]?.name ?? "your hobby"}`,
        outcome: `You spent the afternoon on ${player.hobbies[0]?.name.toLowerCase() ?? "a favorite hobby"} and unlocked a fresh idea.`,
        effects: { Happiness: 13, Energy: 7, Confidence: 4 },
      },
      {
        label: "Invite everyone to hang out",
        outcome:
          "One quick invite turned into a core memory for the whole roster.",
        effects: { Happiness: 11, Social: 14, Energy: -5 },
      },
    ],
  },
]

const clampStat = (value: number) => Math.max(0, Math.min(100, value))

function LifeGamePage() {
  const player = getPlayer(useParams().playerId)
  const [chapter, setChapter] = useState(0)
  const [stats, setStats] = useState<LifeStats>({
    Happiness: 78,
    Energy: 84,
    Smarts: player.stats.Intelligence ?? 80,
    Confidence: player.stats.Confidence ?? 80,
    Social: player.stats["Social Energy"] ?? 72,
  })
  const [story, setStory] = useState<{ age: number text: string }[]>([
    { age: 17, text: `${selectNames[player.id]} joined the BSIT 3-2 roster.` },
  ])
  const current = lifeChapters[chapter]
  const finished = chapter >= lifeChapters.length

  const choose = (choice: LifeChoice) => {
    setStats((previous) => {
      const next = { ...previous }
      Object.entries(choice.effects).forEach(([name, change]) => {
        const key = name as LifeStat
        next[key] = clampStat(previous[key] + (change ?? 0))
      })
      return next
    })
    setStory((previous) => [
      ...previous,
      { age: current.age, text: choice.outcome },
    ])
    setChapter((value) => value + 1)
  }

  const restart = () => {
    setChapter(0)
    setStats({
      Happiness: 78,
      Energy: 84,
      Smarts: player.stats.Intelligence ?? 80,
      Confidence: player.stats.Confidence ?? 80,
      Social: player.stats["Social Energy"] ?? 72,
    })
    setStory([
      {
        age: 17,
        text: `${selectNames[player.id]} joined the BSIT 3-2 roster.`,
      },
    ])
  }

  return (
    <main className="life-game screen" style={theme(player)}>
      <Ambient />
      <header className="select__header life-game__header">
        <Link className="mini-brand" to="/select">
          FIGHTER <b>LIFE</b>
        </Link>
        <div className="round-label">SAVE SLOT / {player.number}</div>
      </header>

      <div className="life-game__layout">
        <aside className="life-card panel">
          <div className="life-card__portrait">
            <Portrait player={player} />
            <span>PLAYER {player.number}</span>
          </div>
          <div className="life-card__identity">
            <small>YOUR CHARACTER</small>
            <strong>{selectNames[player.id]}</strong>
            <span>
              {selectTitles[player.id]} / {player.title}
            </span>
          </div>
          <div className="life-card__stats" aria-label="Current life stats">
            {Object.entries(stats).map(([name, value]) => (
              <div className="life-meter" key={name}>
                <div>
                  <span>{name}</span>
                  <b>{value}%</b>
                </div>
                <div className="life-meter__track">
                  <i style={{ width: `${value}%` }} />
                </div>
              </div>
            ))}
          </div>
        </aside>

        <section className="life-story">
          <div className="life-story__heading">
            <div>
              <div className="eyebrow">
                LIFE MODE / CHAPTER {Math.min(chapter + 1, lifeChapters.length)}{" "}
                OF {lifeChapters.length}
              </div>
              <h1>
                BUILD YOUR <span>STORY</span>
              </h1>
            </div>
            <p>
              Every choice changes your player stats. There are no wrong routes,
              only different save files.
            </p>
          </div>

          <div className="life-timeline" aria-live="polite">
            {story.map((entry, index) => (
              <article className="life-memory" key={`${entry.age}-${index}`}>
                <div className="life-memory__age">
                  AGE <strong>{entry.age}</strong>
                </div>
                <div>
                  <span>
                    {index === 0 ? "CHARACTER SELECTED" : "CHOICE SAVED"}
                  </span>
                  <p>{entry.text}</p>
                </div>
              </article>
            ))}
          </div>

          {finished ? (
            <div className="life-event life-event--complete panel">
              <span className="life-event__kicker">
                CHAPTER COMPLETE / SAVE SUCCESSFUL
              </span>
              <h2>YOUR FIGHTER IS READY.</h2>
              <p>
                You shaped this version of {selectNames[player.id]}. Open the
                complete player file to explore their music, games, abilities,
                and hobbies.
              </p>
              <div className="life-event__actions">
                <Link
                  className="button button--primary"
                  to={`/profile/${player.id}`}
                >
                  OPEN PLAYER PROFILE <Icon name="arrow" />
                </Link>
                <Button onClick={restart} variant="ghost">
                  REPLAY CHAPTER
                </Button>
              </div>
            </div>
          ) : (
            <div className="life-event panel">
              <div className="life-event__top">
                <span className="life-event__kicker">{current.kicker}</span>
                <b>AGE {current.age}</b>
              </div>
              <h2>{current.title}</h2>
              <p>{current.prompt(player)}</p>
              <div className="life-choices">
                {current.choices(player).map((choice, index) => (
                  <button
                    key={choice.label}
                    onClick={() => choose(choice)}
                    type="button"
                  >
                    <span>0{index + 1}</span>
                    <strong>{choice.label}</strong>
                    <small>
                      {Object.entries(choice.effects)
                        .map(
                          ([name, value]) =>
                            `${value! > 0 ? "+" : ""}${value} ${name}`,
                        )
                        .join(" / ")}
                    </small>
                    <Icon name="arrow" />
                  </button>
                ))}
              </div>
            </div>
          )}
          <Link className="life-story__back" to="/select">
            <Icon name="back" /> CHANGE CHARACTER
          </Link>
        </section>
      </div>
    </main>
  )
}

function PageFrame({ player, children }: { player: Player; children: ReactNode }) {
  return (
    <main className={`profile-shell player-${player.id}`} style={theme(player)}>
      <Ambient />
      <header className="profile-nav">
        <Link className="mini-brand" to="/select">
          FIGHTER <b>SELECT</b>
        </Link>
        <nav aria-label="Profile navigation">
          <Link to={`/profile/${player.id}`}>PROFILE</Link>
          <Link to={`/profile/${player.id}/music`}>MUSIC</Link>
          <Link to={`/profile/${player.id}/games`}>GAMES</Link>
          <Link to="/select">ROSTER</Link>
        </nav>
      </header>
      {children}
    </main>
  )
}

function SectionHead({ index, kicker, title }: { index: string; kicker: string; title: string }) {
  return (
    <div className="section-head">
      <span>{index}</span>
      <div>
        <small>{kicker}</small>
        <div className="section-title">{title}</div>
      </div>
      <i />
    </div>
  )
}

function ProfilePage() {
  const { playerId } = useParams()
  const player = getPlayer(playerId)
  return (
    <PageFrame player={player}>
      <section className="hero">
        <div className="hero__copy">
          <div className="eyebrow">{player.fighterId} / ONLINE</div>
          <div className="hero__name">
            <span>{player.nickname}</span>
            <em>{player.title}</em>
          </div>
          <p>{player.intro}</p>
          <blockquote>{player.quote}</blockquote>
          <div className="hero__actions">
            <Link className="button button--primary" to={`/profile/${player.id}/music`}>
              OPEN SOUNDTRACK <Icon name="arrow" />
            </Link>
            <Link className="button button--ghost" to={`/profile/${player.id}/games`}>
              GAME LIBRARY
            </Link>
          </div>
        </div>
        <div className="hero__visual">
          <div className="hero__number">{player.number}</div>
          <Portrait className="portrait--hero" player={player} />
          <div className="hero__tag">READY TO FIGHT</div>
          <small>{player.photoCredit}</small>
        </div>
        <div className="hero__quick">
          <div><span>FULL NAME</span><strong>{player.name}</strong></div>
          <div><span>ROLE</span><strong>{player.role}</strong></div>
          <div><span>PERSONALITY</span><strong>{player.personality}</strong></div>
        </div>
      </section>

      <section className="content-section">
        <SectionHead index="01" kicker="FIGHTER DATA" title="PLAYER PROFILE" />
        <div className="data-grid">
          <div className="info-card panel">
            <div className="info-row"><span>Legal name</span><strong>{player.name}</strong></div>
            <div className="info-row"><span>Age</span><strong>{player.age}</strong></div>
            <div className="info-row"><span>Birthday</span><strong>{player.birthday}</strong></div>
            <div className="info-row"><span>Occupation</span><strong>{player.role}</strong></div>
          </div>
          <div className="stats panel">
            {Object.entries(player.stats).map(([name, value]) => (
              <div className="stat" key={name}>
                <div><span>{name}</span><strong>{value}</strong></div>
                <div className="stat__track"><i style={{ width: `${value}%` }} /></div>
              </div>
            ))}
          </div>
          <div className="fun-facts panel">
            <span className="panel-label">FUN FACT FILES</span>
            {player.funFacts.map((fact, index) => (
              <div key={fact}><b>0{index + 1}</b><p>{fact}</p></div>
            ))}
          </div>
        </div>
      </section>

      <section className="content-section">
        <SectionHead index="02" kicker="COMBAT LOADOUT" title="SKILLS & ABILITIES" />
        <div className="ability-grid">
          {player.abilities.map((ability, index) => (
            <article className="ability panel" key={ability.name}>
              <div className="ability__top"><span>{ability.kind} skill</span><b>0{index + 1}</b></div>
              <div className="ability__glyph">{ability.name.slice(0, 2).toUpperCase()}</div>
              <div className="card-title">{ability.name}</div>
              <p>{ability.description}</p>
              <div className="ability__level"><span>MASTERY</span><strong>{ability.level}%</strong></div>
            </article>
          ))}
        </div>
      </section>

      <section className="content-section content-section--last">
        <SectionHead index="03" kicker="SIDE QUESTS" title="HOBBIES" />
        <div className="hobby-grid">
          {player.hobbies.map((hobby, index) => (
            <Link className="hobby-card panel" key={hobby.slug} to={`/profile/${player.id}/hobby/${hobby.slug}`}>
              <span>0{index + 1}</span>
              <small>{hobby.kicker}</small>
              <div className="card-title">{hobby.name}</div>
              <p>{hobby.description}</p>
              <i><Icon name="arrow" /></i>
            </Link>
          ))}
        </div>
      </section>
    </PageFrame>
  )
}

function MusicPlayer({ player }: { player: Player }) {
  const audioRef = useRef<HTMLAudioElement>(null)
  const [track, setTrack] = useState(0)
  const [playing, setPlaying] = useState(false)
  const [progress, setProgress] = useState(0)
  const [duration, setDuration] = useState(0)
  const current = player.tracks[track]

  useEffect(() => {
    setPlaying(false)
    setProgress(0)
  }, [track])

  const toggle = async () => {
    const node = audioRef.current
    if (!node) return
    if (node.paused) {
      await node.play()
      setPlaying(true)
    } else {
      node.pause()
      setPlaying(false)
    }
  }

  const move = (direction: number) => setTrack((track + direction + player.tracks.length) % player.tracks.length)
  const time = (seconds: number) => `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`

  return (
    <div className="music-console panel">
      <audio
        onEnded={() => move(1)}
        onLoadedMetadata={(event) => setDuration(event.currentTarget.duration || 0)}
        onTimeUpdate={(event) => setProgress(event.currentTarget.currentTime)}
        ref={audioRef}
        src={current.src}
      />
      <div className="album-art">
        <span>{String(track + 1).padStart(2, '0')}</span>
        <i />
        <b>DEMO AUDIO</b>
      </div>
      <div className="now-playing">
        <small>NOW PLAYING / PLAYABLE DEMO</small>
        <div className="card-title">{current.title}</div>
        <p>{current.artist}</p>
        <input
          aria-label="Track progress"
          className="range"
          max={duration || 100}
          onChange={(event) => {
            if (audioRef.current) audioRef.current.currentTime = Number(event.target.value)
          }}
          type="range"
          value={progress}
        />
        <div className="time-row"><span>{time(progress)}</span><span>{time(duration)}</span></div>
        <div className="player-controls">
          <button aria-label="Previous track" onClick={() => move(-1)} type="button"><Icon name="next" /></button>
          <button aria-label={playing ? 'Pause' : 'Play'} className="play-button" onClick={toggle} type="button">
            <Icon name={playing ? 'pause' : 'play'} />
          </button>
          <button aria-label="Next track" onClick={() => move(1)} type="button"><Icon name="next" /></button>
          <label>VOL <input aria-label="Volume" defaultValue="80" max="100" onChange={(event) => {
            if (audioRef.current) audioRef.current.volume = Number(event.target.value) / 100
          }} type="range" /></label>
        </div>
      </div>
      <div className="track-list">
        <span className="panel-label">PLAYLIST / {player.tracks.length} TRACKS</span>
        {player.tracks.map((item, index) => (
          <button className={index === track ? 'is-active' : ''} key={item.title} onClick={() => setTrack(index)} type="button">
            <b>0{index + 1}</b><span>{item.title}<small>{item.artist}</small></span><i>{index === track && playing ? 'PLAYING' : 'LOAD'}</i>
          </button>
        ))}
      </div>
    </div>
  )
}

function MusicPage() {
  const player = getPlayer(useParams().playerId)
  return (
    <PageFrame player={player}>
      <div className="subpage">
        <Link className="back-link" to={`/profile/${player.id}`}><Icon name="back" /> BACK TO PROFILE</Link>
        <SectionHead index="M01" kicker={`${player.nickname}'S AUDIO ARCHIVE`} title="MUSIC LOADOUT" />
        <MusicPlayer player={player} />
        <div className="music-meta">
          <div className="panel"><span className="panel-label">FAVORITE GENRES</span>{player.genres.map((genre) => <b key={genre}>{genre}</b>)}</div>
          <div className="panel"><span className="panel-label">FAVORITE ARTISTS</span>{player.artists.map((artist, index) => <b key={`${artist}-${index}`}>{artist}</b>)}</div>
          <div className="panel video-tease">
            <span className="panel-label">VIDEO CHANNEL</span>
            <div className="card-title">{player.videos[0].title}</div>
            <p>{player.videos[0].artist}</p>
            <Link className="button button--primary" to={`/profile/${player.id}/video/${player.videos[0].id}`}>WATCH MUSIC VIDEO <Icon name="arrow" /></Link>
          </div>
        </div>
      </div>
    </PageFrame>
  )
}

function VideoPage() {
  const { playerId, videoId } = useParams()
  const player = getPlayer(playerId)
  const video = player.videos.find((item) => item.id === videoId) ?? player.videos[0]
  return (
    <PageFrame player={player}>
      <div className="subpage">
        <Link className="back-link" to={`/profile/${player.id}/music`}><Icon name="back" /> BACK TO SOUNDTRACK</Link>
        <SectionHead index="V01" kicker="AUTHORIZED YOUTUBE EMBED" title="VIDEO CHANNEL" />
        <div className="video-layout">
          <div className="video-frame">
            <iframe
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              src={`https://www.youtube-nocookie.com/embed/${video.id}`}
              title={video.title}
            />
          </div>
          <div className="video-copy panel">
            <span className="panel-label">NOW SCREENING</span>
            <div className="card-title">{video.title}</div>
            <h3>{video.artist}</h3>
            <p>{video.description}</p>
            <div className="system-note">If the source owner disables embedding, open the configured YouTube URL directly.</div>
          </div>
        </div>
      </div>
    </PageFrame>
  )
}

function GamesPage() {
  const player = getPlayer(useParams().playerId)
  const categories = [...new Set(player.games.map((game) => game.category))]
  return (
    <PageFrame player={player}>
      <div className="subpage">
        <Link className="back-link" to={`/profile/${player.id}`}><Icon name="back" /> BACK TO PROFILE</Link>
        <SectionHead index="G01" kicker={`${player.nickname}'S SAVE DATA`} title="MY GAME LIBRARY" />
        <div className="filter-row">{categories.map((category) => <span key={category}>{category}</span>)}</div>
        <div className="game-grid">
          {player.games.map((game, index) => (
            <Link className="game-card panel" key={game.slug} to={`/profile/${player.id}/games/${game.slug}`}>
              <div className="game-cover"><span>{game.cover}</span><b>{player.nickname}</b></div>
              <small>{game.category} / {game.platform}</small>
              <div className="card-title">{game.title}</div>
              <p>{game.description}</p>
              <i>OPEN SAVE FILE <Icon name="arrow" /></i>
            </Link>
          ))}
        </div>
      </div>
    </PageFrame>
  )
}

function GameDetailPage() {
  const { playerId, gameSlug } = useParams()
  const player = getPlayer(playerId)
  const game = player.games.find((item) => item.slug === gameSlug) ?? player.games[0]
  return (
    <PageFrame player={player}>
      <div className="subpage">
        <Link className="back-link" to={`/profile/${player.id}/games`}><Icon name="back" /> BACK TO LIBRARY</Link>
        <div className="game-detail">
          <div className="game-detail__art"><span>{game.cover}</span><b>{game.category}</b></div>
          <div className="game-detail__copy">
            <div className="eyebrow">SAVE FILE / {game.slug.toUpperCase()}</div>
            <div className="display-title">{game.title}</div>
            <p>{game.description}</p>
            <div className="detail-row"><span>PLATFORM</span><strong>{game.platform}</strong></div>
            <div className="detail-row"><span>FAVORITE ROLE</span><strong>{game.role}</strong></div>
            <div className="detail-row"><span>MODE</span><strong>{game.category}</strong></div>
          </div>
        </div>
        {game.videoId ? (
          <div className="video-frame video-frame--game">
            <iframe allowFullScreen src={`https://www.youtube-nocookie.com/embed/${game.videoId}`} title={`${game.title} gameplay`} />
          </div>
        ) : (
          <div className="media-placeholder panel"><Icon name="play" /><div><b>GAMEPLAY SLOT EMPTY</b><span>Add an authorized YouTube video ID in src/data.ts.</span></div></div>
        )}
      </div>
    </PageFrame>
  )
}

function HobbyPage() {
  const { playerId, hobbySlug } = useParams()
  const player = getPlayer(playerId)
  const hobby = player.hobbies.find((item) => item.slug === hobbySlug) ?? player.hobbies[0]
  if (hobby.slug === 'gaming') return <Navigate replace to={`/profile/${player.id}/games`} />
  return (
    <PageFrame player={player}>
      <div className="subpage">
        <Link className="back-link" to={`/profile/${player.id}`}><Icon name="back" /> BACK TO PROFILE</Link>
        <div className="hobby-hero">
          <span>{hobby.kicker}</span>
          <div className="display-title">{hobby.name}</div>
          <p>{hobby.description}</p>
        </div>
        <div className="showcase-grid">
          {hobby.items.map((item, index) => (
            <div className="showcase-card panel" key={item}>
              <span>ARCHIVE 0{index + 1}</span>
              <div className="showcase-card__art"><Icon name="spark" /></div>
              <div className="card-title">{item}</div>
              <p>Replace this card with {hobby.name.toLowerCase()} details, images, links, or an authorized embed.</p>
            </div>
          ))}
        </div>
      </div>
    </PageFrame>
  )
}

function VersusPage() {
  return (
    <main className="versus screen">
      <Ambient accent="red" />
      <header className="select__header"><Link className="mini-brand" to="/select">FIGHTER <b>SELECT</b></Link><div className="round-label">TEAM BATTLE</div></header>
      <div className="versus__title"><small>FOUR PLAYERS ENTER</small><div>THE WHOLE <b>ROSTER</b></div><p>Four personalities. One unbeatable party.</p></div>
      <div className="versus-grid">
        {players.map((player, index) => (
          <div className="versus-card" key={player.id} style={theme(player)}>
            <Portrait player={player} />
            <div><span>P{player.number}</span><strong>{player.nickname}</strong><small>{player.title}</small></div>
            {index < players.length - 1 && <i>VS</i>}
          </div>
        ))}
      </div>
      <div className="versus__actions"><Link className="button button--primary" to="/roster">MEET THE WHOLE ROSTER <Icon name="arrow" /></Link><Link className="button button--ghost" to="/select">BACK TO SELECT</Link></div>
    </main>
  )
}

function RosterPage() {
  return (
    <main className="roster-page screen">
      <Ambient />
      <header className="select__header"><Link className="mini-brand" to="/select">FIGHTER <b>SELECT</b></Link><div className="round-label">FRIENDSHIP MODE</div></header>
      <section className="roster-hero">
        <div className="eyebrow">GROUP PROFILE / CO-OP MODE</div>
        <div className="display-title">ONE ROSTER.<br />ZERO QUIET MOMENTS.</div>
        <p>This space is ready for the group’s real story, shared memories, and favorite traditions.</p>
      </section>
      <section className="memory-grid">
        {['How the squad formed', 'The story everyone retells', 'Favorite group activity', 'Next adventure'].map((title, index) => (
          <article className="memory panel" key={title}><span>MEMORY 0{index + 1}</span><div className="card-title">{title}</div><p>Add a true group memory or friendship fact here.</p></article>
        ))}
      </section>
      <section className="roster-strip">
        {players.map((player) => <Link key={player.id} style={theme(player)} to={`/profile/${player.id}`}><Portrait player={player} /><span>{player.nickname}<small>{player.title}</small></span></Link>)}
      </section>
    </main>
  )
}

function ScrollReset() {
  const { pathname } = useLocation()
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' })
  }, [pathname])
  return null
}

function AppRoutes() {
  const [muted, setMuted] = useState(true)
  return (
    <>
      <ScrollReset />
      <Outlet context={{ muted, setMuted }} />
    </>
  )
}

function BootRoute() {
  const { muted, setMuted } = useOutletContext<{
    muted: boolean
    setMuted: (value: boolean) => void
  }>()
  return <BootScreen muted={muted} setMuted={setMuted} />
}

const router = createBrowserRouter([
  {
    Component: AppRoutes,
    children: [
      { index: true, Component: BootRoute },
      { path: "select", Component: SelectScreen },
      { path: "life/:playerId", Component: LifeGamePage },
      { path: "profile/:playerId", Component: ProfilePage },
      { path: "profile/:playerId/music", Component: MusicPage },
      { path: "profile/:playerId/video/:videoId", Component: VideoPage },
      { path: "profile/:playerId/games", Component: GamesPage },
      { path: "profile/:playerId/games/:gameSlug", Component: GameDetailPage },
      { path: "profile/:playerId/hobby/:hobbySlug", Component: HobbyPage },
      { path: "versus", Component: VersusPage },
      { path: "roster", Component: RosterPage },
      { path: "*", element: <Navigate replace to="/" /> },
    ],
  },
])

export default function App() {
  return <RouterProvider router={router} />
}
