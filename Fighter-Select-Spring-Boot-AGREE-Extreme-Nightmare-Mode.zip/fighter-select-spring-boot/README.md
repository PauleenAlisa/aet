**NEW:** [Hard Mode guide](HARD_MODE_GUIDE.md) — 10 shuffled challenges drawn from 15 frustrating but completable mechanics, with the same admin bypass.

## New: AGREE CHALLENGE (10 terms) + Admin bypass

Before choosing a character, guests complete 10 shuffled, original "Agree or Disagree" mini-games. Admins can skip all 10 or disable the game for everyone with a password configured on the Java server. **There is no default password.** See [AGREE_GATE_GUIDE.md](AGREE_GATE_GUIDE.md) for complete Mac setup, admin controls and configuration.

```bash
cd /Users/pau/Downloads/fighter-select-spring-boot
export AGREE_ADMIN_PASSWORD='CHOOSE_YOUR_OWN_STRONG_PASSWORD'
mvn clean spring-boot:run
```

Open http://localhost:8080 and click **START**. On the agreement page, click **⚙ ADMIN** if you want to bypass or disable the challenge.

---

# Fighter Select — Spring Boot (profiles, music & games)

Four-player character-selection site with **JI, PAU, AL and MOND**. Built using Spring Boot 3.5.6 (Java 17+), HTML, CSS and JavaScript. **Life Stories has been removed** from this edition.

## Requirements and how to launch

- JDK 17 or later.
- **Apache Maven 3.6.3+** installed and available as `mvn` in Terminal.

From the folder containing `pom.xml`:

```sh
mvn clean spring-boot:run
```

Then open **http://localhost:8080**. In VS Code, import the folder as a Maven project and wait for Java compilation before launching the main class. If you see `ClassNotFoundException`, build with Maven first. If you see `zsh: command not found: mvn`, Maven is not installed or not on the PATH. This archive includes `pom.xml` but **does not bundle Maven or a Maven Wrapper**.

## Available pages and APIs

- `/` — welcome screen
- `/select` — character selection
- `/profile/ji`, `/profile/pau`, `/profile/al`, `/profile/mond` — character profiles
- `/profile/{id}/music` — dedicated soundtrack / YouTube embed
- `/profile/{id}/games` — favorite-game library
- `/profile/{id}/games/{slug}` — game details and user-provided screenshots
- `/profile/{id}/hobby/{slug}` — hobbies
- `/versus` and `/roster` — group views
- `/api/players` and `/api/players/{id}` — editable roster and individual player data

The Life Stories UI, API, controller, service, model and JSON story dataset have all been removed. Legacy `/life/{id}` links are no longer supported. Legacy character-ID profile URLs (`nova`, `mimi`, `echo`, `jax`) redirect to (`ji`, `pau`, `al`, `mond`) in the browser.

## Edit content

- **Player data:** `src/main/resources/data/players.json`
- **Java model:** `src/main/java/com/fighterselect/model/Player.java`
- **Page logic:** `src/main/resources/static/js/app.js`
- **Styles:** `src/main/resources/static/css/app.css`
- **Photos and screenshots:** `src/main/resources/static/assets/`

AL's four Skills & Abilities percentages are *game-style estimates* chosen for presentation, not an externally validated assessment.

PAU's Adopt Me library card shows PAU's uploaded black-cat Roblox avatar; the detailed pet photo displays her Crocodile screenshot. JI's library card shows JI's house avatar; the detailed pet photo displays the Arctic Reindeer. These pictures use 4:3 containers with `object-fit: contain` so they display without stretching. 

## Testing

```sh
mvn test
```

## Latest update: Extreme AGREEEEE! mode

The pre-roster agreement game now randomly selects 10 out of 19 deliberately difficult challenges. Three wrong answers reset the entire session to step one and reshuffle the puzzles. The Java server counts strikes; reloading the page does not clear them. The admin password bypass and global enable/disable control remain available. See `EXTREME_MODE_GUIDE.md` for mechanics and startup instructions. This demo's parody "terms" are not legally binding.
