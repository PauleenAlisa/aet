package com.fighterselect.gate;

import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

/**
 * Session-scoped, light-hearted agreement game and server-verified admin control.
 * The playful terms are NOT a substitute for actual legal terms or consent.
 */
@Service
public class AgreeGateService {
    private static final int TOTAL = 10;
    private static final String PROGRESS = "agreeGate.progress";
    private static final String GRANTED = "agreeGate.granted";
    private static final String ADMIN = "agreeGate.admin";
    private static final String ATTEMPTS = "agreeGate.adminAttempts";
    private static final String LOCK_UNTIL = "agreeGate.adminLockUntil";
    private static final long LOCK_TIME_MS = 30_000L;

    private final SecureRandom random = new SecureRandom();
    private final String adminPassword;
    private final boolean defaultEnabled;
    private final String stateFileName;
    private volatile boolean enabled;

    public AgreeGateService(@Value("${agree.admin.password:}") String adminPassword,
                            @Value("${agree.gate.initial-enabled:true}") boolean defaultEnabled,
                            @Value("${agree.gate.state-file:./config/agree-gate.properties}") String stateFileName) {
        this.adminPassword = adminPassword;
        this.defaultEnabled = defaultEnabled;
        this.stateFileName = stateFileName;
        this.enabled = defaultEnabled;
    }

    @PostConstruct
    void loadState() {
        if (stateFileName.isBlank()) return;
        Path file = Path.of(stateFileName);
        if (!Files.exists(file)) return;
        try (var in = Files.newInputStream(file)) {
            Properties properties = new Properties();
            properties.load(in);
            String value = properties.getProperty("enabled");
            if ("true".equals(value) || "false".equals(value)) enabled = Boolean.parseBoolean(value);
        } catch (IOException e) {
            throw new IllegalStateException("Could not read agreement gate state: " + file, e);
        }
    }

    public boolean canEnter(HttpSession session) {
        return !enabled || Boolean.TRUE.equals(session.getAttribute(GRANTED)) || isAdmin(session);
    }

    public void requireAccess(HttpSession session) {
        if (!canEnter(session)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Complete the agreement game first");
        }
    }

    public boolean isAdmin(HttpSession session) {
        return Boolean.TRUE.equals(session.getAttribute(ADMIN));
    }

    public boolean adminConfigured() {
        return !adminPassword.isBlank();
    }

    public Map<String, Object> status(HttpSession session) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("enabled", enabled);
        result.put("accessGranted", canEnter(session));
        result.put("adminAuthenticated", isAdmin(session));
        result.put("adminConfigured", adminConfigured());
        result.put("totalSteps", TOTAL);
        Progress attempt = (Progress) session.getAttribute(PROGRESS);
        result.put("strikes", attempt == null ? 0 : attempt.strikes);
        if (enabled && !canEnter(session)) {
            Progress progress = getOrCreateProgress(session);
            result.put("completedSteps", progress.step);
            Map<String, Object> current = progress.current().publicView();
            if (progress.current().mode().equals("timer")) {
                current.put("waitMs", Math.max(0, ((Number) progress.current().config().getOrDefault("waitMillis", 12000)).longValue() - (System.currentTimeMillis() - progress.startedAt)));
            }
            result.put("challenge", current);
        } else {
            Progress progress = (Progress) session.getAttribute(PROGRESS);
            result.put("completedSteps", progress == null ? (canEnter(session) ? TOTAL : 0) : progress.step);
            result.put("challenge", null);
        }
        return result;
    }

    public Map<String, Object> agree(HttpSession session, String challengeId, String proof) {
        if (canEnter(session)) return status(session);
        Progress progress = getOrCreateProgress(session);
        Challenge challenge = progress.current();
        if (!challenge.id.equals(challengeId) || !challenge.expected.equals(proof)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "That agreement didn't count. Try the current challenge.");
        }
        if (challenge.mode.equals("timer") && System.currentTimeMillis() - progress.startedAt < ((Number) challenge.config().getOrDefault("waitMillis", 12000)).longValue()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "The clock hasn't finished yet.");
        }
        progress.step++;
        progress.startedAt = System.currentTimeMillis();
        if (progress.step == TOTAL) session.setAttribute(GRANTED, Boolean.TRUE);
        return status(session);
    }

    // In Extreme Mode, three bad clicks burn the entire run. The gate tracks
    // strikes server-side, so refreshing the page does not reset the penalty.
    public Map<String, Object> mistake(HttpSession session) {
        if (canEnter(session)) return status(session);
        Progress progress = getOrCreateProgress(session);
        progress.strikes++;
        if (progress.strikes >= 3) {
            session.removeAttribute(PROGRESS);
        }
        return status(session);
    }

    public Map<String, Object> restart(HttpSession session) {
        if (!isAdmin(session)) session.removeAttribute(GRANTED);
        session.removeAttribute(PROGRESS);
        return status(session);
    }

    public Map<String, Object> login(HttpSession session, String inputPassword) {
        if (!adminConfigured()) {
            throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,
                    "Admin access is disabled. Set AGREE_ADMIN_PASSWORD before starting Spring Boot.");
        }
        long now = System.currentTimeMillis();
        Object lock = session.getAttribute(LOCK_UNTIL);
        if (lock instanceof Long until && until > now) {
            throw new ResponseStatusException(HttpStatus.TOO_MANY_REQUESTS,
                    "Too many incorrect attempts. Try again in 30 seconds.");
        }
        byte[] stored = adminPassword.getBytes(StandardCharsets.UTF_8);
        byte[] attempted = (inputPassword == null ? "" : inputPassword).getBytes(StandardCharsets.UTF_8);
        if (!MessageDigest.isEqual(stored, attempted)) {
            int attempts = session.getAttribute(ATTEMPTS) instanceof Integer n ? n + 1 : 1;
            session.setAttribute(ATTEMPTS, attempts);
            if (attempts >= 5) {
                session.setAttribute(LOCK_UNTIL, now + LOCK_TIME_MS);
                session.setAttribute(ATTEMPTS, 0);
            }
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Incorrect admin password.");
        }
        session.removeAttribute(ATTEMPTS);
        session.removeAttribute(LOCK_UNTIL);
        session.setAttribute(ADMIN, Boolean.TRUE);
        return status(session);
    }

    public Map<String, Object> logout(HttpSession session) {
        session.invalidate();
        return Map.of("loggedOut", true);
    }

    public synchronized Map<String, Object> setEnabled(HttpSession session, boolean value) {
        if (!isAdmin(session)) throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Admin login required");
        if (!stateFileName.isBlank()) {
            Path file = Path.of(stateFileName);
            try {
                if (file.getParent() != null) Files.createDirectories(file.getParent());
                Files.writeString(file, "# Local Fighter Select gate settings\nenabled=" + value + "\n",
                        StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
            } catch (IOException e) {
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                        "Could not save the gate setting; check folder permissions.");
            }
        }
        enabled = value;
        return status(session);
    }

    private Progress getOrCreateProgress(HttpSession session) {
        Object existing = session.getAttribute(PROGRESS);
        if (existing instanceof Progress progress) return progress;
        List<Challenge> challenges = createChallenges();
        Progress progress = new Progress(challenges);
        session.setAttribute(PROGRESS, progress);
        return progress;
    }

    private List<Challenge> createChallenges() {
        List<Challenge> challenges = new ArrayList<>();
        challenges.add(new Challenge("double", "SEVEN CLICKS OR ZERO",
                "I agree to destroy my mouse warranty in pursuit of character selection.",
                "Click SEVEN times in a row. Each gap must be under 320 milliseconds.", "septuple", Map.of("clicks", 7)));
        challenges.add(new Challenge("hold", "THE ETERNAL HOLD",
                "I will hold this button for an unreasonable amount of time.",
                "Press and HOLD for 8.5 continuous seconds. Releasing at 8.4 resets it.", "held", Map.of("holdMillis", 8500)));
        challenges.add(new Challenge("chase", "RUN AFTER YOUR RIGHTS",
                "I agree that my approval button has superior athletic ability.",
                "Catch the moving Agree button TWELVE times.", "caught", Map.of("count", 12)));
        challenges.add(new Challenge("reverse", "IT'S A TRAP",
                "I agree to disagree that I disagree to agree.",
                "The obvious AGREE button is a trap. Only DISAGREE works.", "reverse", Map.of()));
        challenges.add(new Challenge("checks", "NINE BOXES OF MISERY",
                "I love confusing checkboxes that are technically unnecessary.",
                "Check ONLY boxes 2, 5, and 8. One extra box is a strike.", "010010010", Map.of()));
        String[] phrases = {
                "I AGREE, but this is the LAST time! (probably)",
                "Terms & Conditions? More like Tears & Confusion!",
                "No refunds. No mercy. Just AGREE! (x10)",
                "I hereby surrender my patience, NOT my snacks."
        };
        String phrase = phrases[random.nextInt(phrases.length)];
        challenges.add(new Challenge("type", "THE TYPO DEATH PENALTY",
                "I consent to perfectly transcribing this sentence.",
                "Copy the sentence exactly, including spaces, apostrophes and punctuation.", phrase, Map.of("phrase", phrase)));
        int target = new int[]{43, 67, 83, 97, 29}[random.nextInt(5)];
        challenges.add(new Challenge("slider", "THE 1-PIXEL SURRENDER",
                "My exact approval percentage is subject to meaningless precision.",
                "Set the slider to the EXACT number. One percent off costs a strike.", String.valueOf(target), Map.of("target", target)));
        List<Integer> order = new ArrayList<>(List.of(1,2,3,4,5,6,7,8));
        Collections.shuffle(order, random);
        String sequence = order.stream().map(String::valueOf).collect(java.util.stream.Collectors.joining("-"));
        challenges.add(new Challenge("sequence", "MEMORIZE EIGHT NUMBERS",
                "I must remember eight taps that nobody will ever ask about again.",
                "The order disappears after 4 seconds. Press all eight without a mistake.", sequence, Map.of("sequence", List.copyOf(order))));
        challenges.add(new Challenge("timer", "THE HOLD MUSIC WITHOUT MUSIC",
                "I have waited twelve full seconds to read a button.",
                "Wait twelve seconds doing absolutely nothing. Clicking early won't count.", "waited", Map.of("waitMillis", 12000)));
        int slot = random.nextInt(30) + 1;
        challenges.add(new Challenge("target", "THIRTY IDENTICAL BUTTONS",
                "I accept that the difference between a period and an exclamation is life-changing.",
                "Only ONE of the thirty buttons says AGREE! instead of AGREE.", "slot-"+slot, Map.of("correctSlot", slot)));
        int a=random.nextInt(13)+14, b=random.nextInt(8)+9, c=random.nextInt(8)+4, d=random.nextInt(9)+6, minus=random.nextInt(16)+8;
        challenges.add(new Challenge("math", "YOU NEED A CALCULATOR NOW",
                "A meaningless arithmetic expression is required to see a profile.",
                "Calculate the expression exactly. One mistake is a strike.", String.valueOf(a*b+c*d-minus),
                Map.of("a",a,"b",b,"c",c,"d",d,"minus",minus)));
        String[] codes = {"PINK-71-FOX-902", "MINT-04-CAT-185", "RAGE-63-TAX-742", "OUCH-92-LOL-314"};
        String code = codes[random.nextInt(codes.length)];
        challenges.add(new Challenge("memory", "BLINK AND IT'S GONE",
                "I remember one very long code after 1.1 seconds of exposure.",
                "The code disappears after 1.1 seconds. You get ONE extra reveal.", code, Map.of("code", code)));
        challenges.add(new Challenge("scroll", "THE NEVER-ENDING CONTRACT",
                "I love reading all forty clauses of an entirely fake contract.",
                "Scroll INSIDE the tiny box to the bottom of all 40 clauses.", "scrolled", Map.of()));
        challenges.add(new Challenge("switches", "THE NINE-SWITCH AUDIT",
                "I can make sense of a switch panel that looks like a cockpit.",
                "Turn ON switches 1, 3, 6, and 9 ONLY.", "101001001", Map.of()));
        List<String> ritual = List.of("A", "D", "D", "A", "A", "D", "A", "D", "A");
        challenges.add(new Challenge("combo", "NINE-CLICK SECRET HANDSHAKE",
                "I will not complain about memorizing a bureaucratic button ritual.",
                "Memorize the 9-button ritual before it disappears after four seconds.", "combo", Map.of("combo", ritual)));
        int taps = random.nextInt(8)+24;
        challenges.add(new Challenge("tapcount", "THE CLICKING TAX",
                "I am willing to click the same button a pointless number of times.",
                "Click exactly the requested number of times, then press CLAIM. No extras.", String.valueOf(taps), Map.of("count", taps)));
        List<String> icons = new ArrayList<>();
        int appleCount = 0;
        for (int i=0;i<72;i++) {
            String symbol = random.nextInt(5)==0 ? "🍎" : "🍋";
            icons.add(symbol);
            if (symbol.equals("🍎")) appleCount++;
        }
        challenges.add(new Challenge("captcha", "COUNT EVERY APPLE",
                "I have counted dozens of tiny fruit icons for no good reason.",
                "Count ONLY the red apples in the entire grid, not the lemons.", String.valueOf(appleCount), Map.of("icons", List.copyOf(icons))));
        String[] dirs = {"U", "D", "L", "R"};
        List<String> arrows = new ArrayList<>();
        for(int i=0;i<11;i++) arrows.add(dirs[random.nextInt(dirs.length)]);
        challenges.add(new Challenge("arrows", "ELEVEN-STEP BUTTON MAZE",
                "I will use all four directions for absolutely no reason.",
                "Follow the ELEVEN arrows. A single wrong direction restarts the sequence.", String.join("",arrows), Map.of("arrows", List.copyOf(arrows))));
        String[] mirrorWords={"AGREE?! NOT TODAY.","RAGE MODE ACTIVATED!","SOMEONE SEND HELP!"};
        String original=mirrorWords[random.nextInt(mirrorWords.length)];
        challenges.add(new Challenge("mirror", "THE MIRROR CONTRACT",
                "I will learn to write sentences backwards to enter a profile site.",
                "Type the displayed phrase BACKWARDS, character by character.", new StringBuilder(original).reverse().toString(), Map.of("phrase", original)));
        Collections.shuffle(challenges, random);
        return List.copyOf(challenges.subList(0,TOTAL));
    }

    private static class Progress {
        final List<Challenge> challenges;
        int step = 0;
        int strikes = 0;
        long startedAt = System.currentTimeMillis();
        Progress(List<Challenge> challenges) { this.challenges = challenges; }
        Challenge current() { return challenges.get(step); }
    }

    private record Challenge(String mode, String title, String term, String hint, String expected,
                             Map<String, Object> config, String id) {
        Challenge(String mode, String title, String term, String hint, String expected, Map<String, Object> config) {
            this(mode, title, term, hint, expected, config, UUID.randomUUID().toString());
        }
        Map<String, Object> publicView() {
            Map<String, Object> output = new HashMap<>();
            output.put("id", id);
            output.put("mode", mode);
            output.put("title", title);
            output.put("term", term);
            output.put("hint", hint);
            output.put("config", config);
            return output;
        }
    }
}
