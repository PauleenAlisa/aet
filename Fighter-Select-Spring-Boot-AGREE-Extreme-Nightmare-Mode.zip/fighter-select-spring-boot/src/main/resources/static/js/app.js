/*
 * Spring Boot edition of the four-player fighter select application.
 * The Java backend owns the roster (GET /api/players). This browser-side file
 * replaces React's rendering/router with standard, dependency-free JavaScript.
 */
'use strict';

const app = document.getElementById('app');
const selectNames = { ji: 'JI', pau: 'PAU', al: 'AL', mond: 'MOND' };
const selectTitles = { ji: 'The Maldita', pau: 'The Charming One', al: 'The Only Child', mond: 'The Dark One' };
const localJiPose = '/assets/763925829_1039672735429831_7750910218737029479_n.jpg';
const localJiHover = '/assets/5009b66c-6554-4adc-8bf4-c701f24f4834.jpg';
const memoryTitles = ['How the squad formed', 'The story everyone retells', 'Favorite group activity', 'Next adventure'];
let players = [];
let selectedId = null;
let hoveredId = 'ji';
let musicState = null;
let muted = true;

const e = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[ch]));
const enc = encodeURIComponent;
const palette = p => `--accent:${e(p.accent)};--accent-2:${e(p.accent2)};--accent-rgb:${e(p.rgb)}`;
const icon = name => `<span class="icon icon--${e(name)}" aria-hidden="true">${({arrow:'→',sound:')))',mute:'×',play:'▶',pause:'Ⅱ',next:'▶|',back:'←',spark:'✦'})[name] ?? ''}</span>`;
const purl = p => `/profile/${enc(p.id)}`;
const ambient = (accent = '') => `<div aria-hidden="true" class="ambient ${accent ? `ambient--${e(accent)}` : ''}"><div class="grid-floor"></div><div class="orb orb--one"></div><div class="orb orb--two"></div><div class="noise"></div></div>`;
const linkButton = (url, label, variant = 'primary') => `<a class="button button--${variant}" href="${e(url)}">${label}</a>`;
const btn = (label, action, variant = 'primary', disabled = false) => `<button class="button button--${variant}" type="button" data-action="${e(action)}"${disabled ? ' disabled' : ''}>${label}</button>`;
const playerById = id => players.find(p => p.id === id);
const sectionHead = (index, kicker, title) => `<div class="section-head"><span>${e(index)}</span><div><small>${e(kicker)}</small><div class="section-title">${e(title)}</div></div><i></i></div>`;
const portrait = (p, {interactive = false, hero = false, local = false} = {}) => {
  const src = local && p.id === 'ji' ? localJiPose : p.portrait;
  const hover = local && p.id === 'ji' ? localJiHover : p.hoverPortrait;
  return `<div class="portrait ${interactive ? 'portrait--interactive' : ''} ${hero ? 'portrait--hero' : ''}">
    <img class="portrait__pose portrait__pose--base" alt="${e(p.nickname)} portrait" src="${e(src)}" loading="${hero || interactive ? 'eager' : 'lazy'}">
    ${interactive ? `<img class="portrait__pose portrait__pose--hover" alt="" aria-hidden="true" src="${e(hover)}" loading="lazy">` : ''}
    <div class="portrait__fallback" hidden>${e(p.nickname.slice(0,1))}</div><div class="portrait__scan"></div>
  </div>`;
};
const navHeader = (label, subtitle) => `<header class="select__header"><a href="/select" class="mini-brand">FIGHTER <b>${e(label)}</b></a><div class="round-label">${e(subtitle)}</div></header>`;
const pageFrame = (p, inner) => `<main class="profile-shell player-${e(p.id)}" style="${palette(p)}">${ambient()}
  <header class="profile-nav"><a class="mini-brand" href="/select">FIGHTER <b>SELECT</b></a>
  <nav aria-label="Profile navigation"><a href="${purl(p)}">PROFILE</a><a href="${purl(p)}/music">MUSIC</a><a href="${purl(p)}/games">GAMES</a><a href="/select">ROSTER</a><button type="button" class="gate-admin-launch" data-action="admin-open">⚙ ADMIN</button></nav></header>
  ${inner}</main>`;
const back = (url, label) => `<a class="back-link" href="${e(url)}">${icon('back')} ${e(label)}</a>`;
const subpage = (p, inner) => pageFrame(p, `<div class="subpage">${inner}</div>`);
const formatTime = secs => Number.isFinite(secs) ? `${Math.floor(secs / 60)}:${String(Math.floor(secs % 60)).padStart(2,'0')}` : '0:00';
const ytEmbed = id => /^[a-zA-Z0-9_-]{6,20}$/.test(id || '') ? `https://www.youtube-nocookie.com/embed/${enc(id)}` : '';

function bootPage() {
  return `<main class="boot screen">${ambient()}
    <div class="topbar"><div class="brand-mark">FS // 24</div><div class="boot-admin-actions"><button type="button" class="gate-admin-launch" data-action="admin-open">⚙ ADMIN</button><button class="sound-toggle" type="button" data-action="toggle-sound" aria-label="${muted ? 'Enable' : 'Mute'} interface sound">${icon(muted ? 'mute' : 'sound')}<span>${muted ? 'SFX OFF' : 'SFX ON'}</span></button></div></div>
    <div class="boot__content"><div class="eyebrow">BSIT 3-2</div><div class="mega-title" aria-label="Fighter Select"><span>PROFILE</span><span class="mega-title__outline">SELECT</span></div><p class="boot__subtitle">uwu</p>${linkButton('/select', `START&nbsp;&nbsp; ${icon('arrow')}`)}<div class="press-start">PRESS START TO CONTINUE</div></div>
    <div class="boot__footer"><span>Jaemar Ibanez</span><span>Alfrancis Juvir Delos Trino</span><span>Pauleen Alisa Amatorio</span><span>Richmond Ebasan</span></div>
  </main>`;
}

function selectPage() {
  const display = playerById(selectedId || hoveredId) || players[0];
  return `<main class="select screen" style="${palette(display)}">${ambient('red')}
    <header class="select__header"><a class="mini-brand" href="/">PROFILE <span class="fg-inline-bold">SELECT</span></a><div class="round-label">ROSTER / 04</div></header>
    <section class="select__intro"><div><div class="eyebrow">YOOHOOOO PILI NA!</div><div class="display-title">SELECT STUDENT</div></div><p id="select-intro">${selectedId ? 'Selection locked. Confirm your fighter.' : e(display.intro)}</p></section>
    <section class="fighter-grid" aria-label="Fighter roster">${players.map(p => `<button class="fighter-card ${selectedId === p.id ? 'is-selected' : ''}" aria-pressed="${selectedId === p.id}" style="${palette(p)}" data-action="select-player" data-id="${e(p.id)}" type="button">
      ${portrait(p, {interactive:true,local:true})}<div class="fighter-card__shade"></div><div class="fighter-card__number">${e(p.number)}</div><div class="fighter-card__meta"><span>PLAYER ${e(p.number)}</span><strong>${e(selectNames[p.id])}</strong><small>${e(selectTitles[p.id])}</small></div><div class="fighter-card__corner">+</div>
    </button>`).join('')}</section>
    <section class="selection-bar"><div class="selection-bar__status"><span id="selection-caption">${selectedId ? 'SELECTED:' : 'CURRENT TARGET'}</span><strong id="selection-name">${e(selectNames[display.id])}</strong><small id="selection-title">${selectedId ? e(selectTitles[display.id]) : 'Click to lock in'}</small></div>
    <div class="selection-bar__actions">${btn('RANDOM SELECT','random-select','ghost')}${btn(`${selectedId ? 'VIEW CHARACTER PROFILE' : 'SELECT A FIGHTER'} ${icon('arrow')}`, 'confirm-select','primary',!selectedId)}</div></section>
    <nav class="select__nav" aria-label="Secondary navigation"><a href="/">BACK TO MENU</a><a href="/versus">GROUP VERSUS</a><button type="button" class="gate-admin-launch" data-action="admin-open">⚙ ADMIN</button></nav>
  </main>`;
}
function updateHover(id) {
  hoveredId = id;
  if (selectedId) return;
  const p = playerById(id);
  if (!p) return;
  const el = document.querySelector('main.select');
  if (el) el.setAttribute('style',palette(p));
  const intro = document.getElementById('select-intro'); if (intro) intro.textContent = p.intro;
  const name = document.getElementById('selection-name'); if (name) name.textContent = selectNames[p.id];
}

// Embedded YouTube playback retains the existing two-column soundtrack style.
// YouTube owns the music; no copyrighted audio is downloaded or hosted by this app.
const soundtrackSelectedIndices = {al:0,ji:0,pau:1,mond:1};
const hasVideoSoundtrack = p => ['al','ji','pau','mond'].includes(p.id) && p.tracks.some(t => ytEmbed(t.videoId));
function videoSoundtrackPanel(p, listLabel) {
  const index = Math.max(0, Math.min(soundtrackSelectedIndices[p.id] ?? 0, p.tracks.length - 1));
  const current = p.tracks[index];
  const videoUrl = `https://www.youtube.com/watch?v=${enc(current.videoId)}`;
  return `<div class="al-soundtrack-layout" data-soundtrack-id="${e(p.id)}">
      <div class="al-song-collection panel"><span class="panel-label">${e(listLabel)}</span>
        ${p.tracks.map((track,i)=>`<div class="al-song-entry ${i===index?'is-active':''}"><span>${String(i+1).padStart(2,'0')}</span><div><strong>${e(track.title)}</strong><small>${e(track.artist)}</small></div><button type="button" class="al-track-play" data-action="play-video-track" data-player="${e(p.id)}" data-index="${i}" aria-label="Play ${e(track.title)} by ${e(track.artist)}" aria-pressed="false">PLAY ▶</button></div>`).join('')}
        <div class="al-playlist-note">Choose PLAY to load the selected song in the official YouTube player. Internet access is required, and some videos may restrict embedded playback.</div>
      </div>
      <div class="al-spotlight panel"><span class="panel-label">SOUNDTRACK PLAYER · OFFICIAL VIDEO</span>
        <div class="video-frame"><iframe id="video-soundtrack-player" loading="lazy" src="${ytEmbed(current.videoId)}?rel=0" title="${e(current.artist)} — ${e(current.title)}" allow="autoplay; encrypted-media; picture-in-picture; web-share" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe></div>
        <div class="al-spotlight__text"><div><strong id="video-now-playing-title">${e(current.title)}</strong><span id="video-now-playing-artist">${e(current.artist)}</span></div><a id="video-song-external" href="${videoUrl}" target="_blank" rel="noopener noreferrer">WATCH ON YOUTUBE ↗</a></div>
      </div>
    </div>`;
}
function playVideoTrack(playerId,index) {
  const p = playerById(playerId);
  if (!p || !hasVideoSoundtrack(p) || !Number.isInteger(index) || index<0 || index>=p.tracks.length) return;
  const track = p.tracks[index];
  if (!/^[a-zA-Z0-9_-]{11}$/.test(track.videoId || '')) return;
  soundtrackSelectedIndices[playerId] = index;
  const iframe = document.getElementById('video-soundtrack-player');
  if (!iframe) return;
  iframe.title = `${track.artist} — ${track.title}`;
  iframe.src = `${ytEmbed(track.videoId)}?autoplay=1&rel=0`;
  const title = document.getElementById('video-now-playing-title');
  const artist = document.getElementById('video-now-playing-artist');
  const external = document.getElementById('video-song-external');
  if (title) title.textContent = track.title;
  if (artist) artist.textContent = track.artist;
  if (external) external.href = `https://www.youtube.com/watch?v=${enc(track.videoId)}`;
  document.querySelectorAll('.al-track-play').forEach(button => {
    const active = Number(button.dataset.index) === index;
    button.textContent = active ? 'NOW PLAYING ▶' : 'PLAY ▶';
    button.setAttribute('aria-pressed', String(active));
    button.closest('.al-song-entry')?.classList.toggle('is-active', active);
  });
}

function profilePage(p) {
  return pageFrame(p, `<section class="hero">
      <div class="hero__copy"><div class="eyebrow">${e(p.fighterId)} / ONLINE</div><div class="hero__name"><span>${e(p.nickname)}</span><em>${e(p.title)}</em></div><p>${e(p.intro)}</p><blockquote>${e(p.quote)}</blockquote>${p.quoteMeaning ? `<p class="motto-meaning">${e(p.quoteMeaning)}</p>` : ''}
        <div class="hero__actions">${linkButton(`${purl(p)}/music`,'OPEN SOUNDTRACK','ghost')}${linkButton(`${purl(p)}/games`,'GAME LIBRARY','ghost')}</div></div>
      <div class="hero__visual"><div class="hero__number">${e(p.number)}</div>${portrait(p,{hero:true})}<small>${e(p.photoCredit)}</small></div>
      <div class="hero__quick"><div><span>FULL NAME</span><strong>${e(p.name)}</strong></div><div><span>ROLE</span><strong>${e(p.role)}</strong></div><div><span>PERSONALITY</span><strong>${e(p.personality)}</strong></div></div>
    </section>
    <section class="content-section">${sectionHead('01','FIGHTER DATA','PLAYER PROFILE')}
      <div class="data-grid"><div class="info-card panel">${[['Legal name',p.name],['Age',p.age],['Birthday',p.birthday],['Occupation',p.role]].map(([label,val]) => `<div class="info-row"><span>${e(label)}</span><strong>${e(val)}</strong></div>`).join('')}</div>
      <div class="stats panel">${Object.entries(p.stats).map(([name,val]) => `<div class="stat"><div><span>${e(name)}</span><strong>${val}%</strong></div><div class="stat__track"><i style="width:${val}%"></i></div></div>`).join('')}</div>
      <div class="fun-facts panel"><span class="panel-label">FUN FACT FILES</span>${p.funFacts.map((fact,i) => `<div><b>0${i+1}</b><p>${e(fact)}</p></div>`).join('')}</div></div>
    </section>
    <section class="content-section">${sectionHead('02','COMBAT LOADOUT','SKILLS & ABILITIES')}
      <div class="ability-grid">${p.abilities.map((a,i) => `<article class="ability panel"><div class="ability__top"><span>${e(a.kind)} skill</span><b>0${i+1}</b></div><div class="ability__glyph">${e(a.name.slice(0,2).toUpperCase())}</div><div class="card-title">${e(a.name)}</div><p>${e(a.description)}</p><div class="ability__level"><span>${Number.isInteger(a.level) ? 'MASTERY' : 'PERSONAL STRENGTH'}</span><strong>${Number.isInteger(a.level) ? `${a.level}%` : 'PROFILE SKILL'}</strong></div></article>`).join('')}</div>
    </section>
    <section class="content-section content-section--last">${sectionHead('03','SIDE QUESTS','HOBBIES')}
      <div class="hobby-grid">${p.hobbies.map((h,i) => `<a class="hobby-card panel" href="${p.id === 'pau' && h.slug === 'dancing-singing' ? `${purl(p)}/music` : `${purl(p)}/hobby/${enc(h.slug)}` }"><span>0${i+1}</span><small>${e(h.kicker)}</small><div class="card-title">${e(h.name)}</div><p>${e(h.description)}</p><i>${icon('arrow')}</i></a>`).join('')}</div></section>`);
}

function musicPage(p) {
  if (hasVideoSoundtrack(p)) return subpage(p, `${back(purl(p),'BACK TO PROFILE')}${sectionHead('M01',`${p.nickname}’S FAVORITE TRACKS`,'SOUNDTRACK')}
    <p class="al-soundtrack-description">Select a track to play its official video inside the soundtrack player. Playback depends on YouTube permissions. No recordings are downloaded or hosted here.</p>
    ${videoSoundtrackPanel(p,`SONG COLLECTION · ${String(p.tracks.length).padStart(2,'0')}`)}
    <div class="music-meta"><div class="panel"><span class="panel-label">FAVORITE GENRES</span>${p.genres.map(genre=>`<b>${e(genre)}</b>`).join('')}</div>
    <div class="panel"><span class="panel-label">FAVORITE ARTISTS</span>${p.artists.map(artist=>`<b>${e(artist)}</b>`).join('')}</div></div>`);
  if (!musicState || musicState.playerId !== p.id) musicState = {playerId:p.id,track:0,volume:0.8};
  const track = p.tracks[musicState.track];
  const video = p.videos[0];
  return subpage(p, `${back(purl(p),'BACK TO PROFILE')}${sectionHead('M01', `${p.nickname}'S AUDIO ARCHIVE`, 'MUSIC LOADOUT')}
    <div class="music-console panel">
      <audio id="music-audio" preload="metadata" src="${e(track.src)}"></audio>
      <div class="album-art"><span>${String(musicState.track+1).padStart(2,'0')}</span><i></i><b>DEMO AUDIO</b></div>
      <div class="now-playing"><small>NOW PLAYING / PLAYABLE DEMO</small><div class="card-title">${e(track.title)}</div><p>${e(track.artist)}</p>
        <input type="range" class="range" id="music-progress" aria-label="Track progress" min="0" max="100" value="0">
        <div class="time-row"><span id="music-current-time">0:00</span><span id="music-duration">0:00</span></div>
        <div class="player-controls"><button type="button" aria-label="Previous track" data-action="track-prev">${icon('next')}</button><button type="button" aria-label="Play or pause" class="play-button" data-action="track-toggle" id="music-play">${icon('play')}</button><button type="button" aria-label="Next track" data-action="track-next">${icon('next')}</button><label>VOL <input type="range" id="music-volume" aria-label="Volume" value="${Math.round(musicState.volume*100)}" max="100" min="0"></label></div>
      </div>
      <div class="track-list"><span class="panel-label">PLAYLIST / ${p.tracks.length} TRACKS</span>
        ${p.tracks.map((item,i) => `<button type="button" data-action="choose-track" data-index="${i}" class="${i === musicState.track ? 'is-active' : ''}"><b>0${i+1}</b><span>${e(item.title)}<small>${e(item.artist)}</small></span><i>LOAD</i></button>`).join('')}
      </div>
    </div>
    <div class="music-meta"><div class="panel"><span class="panel-label">FAVORITE GENRES</span>${p.genres.map(genre=>`<b>${e(genre)}</b>`).join('')}</div>
      <div class="panel"><span class="panel-label">FAVORITE ARTISTS</span>${p.artists.map(artist=>`<b>${e(artist)}</b>`).join('')}</div>
      <div class="panel video-tease"><span class="panel-label">VIDEO CHANNEL</span><div class="card-title">${e(video.title)}</div><p>${e(video.artist)}</p>${linkButton(`${purl(p)}/video/${enc(video.id)}`,`WATCH MUSIC VIDEO ${icon('arrow')}`)}</div>
    </div>`);
}
function bindMusic() {
  const audio = document.getElementById('music-audio');
  if (!audio) return;
  audio.volume = musicState.volume;
  const progress = document.getElementById('music-progress');
  const durationEl = document.getElementById('music-duration');
  const currentEl = document.getElementById('music-current-time');
  audio.addEventListener('loadedmetadata', () => {
    if (Number.isFinite(audio.duration)) { progress.max = String(audio.duration); durationEl.textContent = formatTime(audio.duration); }
  });
  audio.addEventListener('timeupdate', () => { progress.value = String(audio.currentTime); currentEl.textContent = formatTime(audio.currentTime); });
  audio.addEventListener('ended', () => advanceTrack(1));
  audio.addEventListener('pause', updatePlayState);
  audio.addEventListener('play', updatePlayState);
  progress.addEventListener('input', () => { if (Number.isFinite(audio.duration)) audio.currentTime = +progress.value; });
  document.getElementById('music-volume').addEventListener('input', ev => {
    musicState.volume = +ev.target.value / 100; audio.volume = musicState.volume;
  });
}
function updatePlayState() {
  const audio = document.getElementById('music-audio');
  const playBtn = document.getElementById('music-play');
  if (audio && playBtn) playBtn.innerHTML = icon(audio.paused ? 'play' : 'pause');
  document.querySelectorAll('.track-list button').forEach((button,i) => {
    const label = button.querySelector('i');
    if (label) label.textContent = i === musicState.track && audio && !audio.paused ? 'PLAYING' : 'LOAD';
  });
}
function advanceTrack(direction) {
  if (!musicState) return;
  const p = playerById(musicState.playerId);
  musicState.track = (musicState.track + direction + p.tracks.length) % p.tracks.length;
  render();
}
function videoPage(p, videoId) {
  const v = p.videos.find(item => item.id === videoId) || p.videos[0];
  const source = ytEmbed(v.id);
  return subpage(p, `${back(`${purl(p)}/music`,'BACK TO SOUNDTRACK')}${sectionHead('V01','AUTHORIZED YOUTUBE EMBED','VIDEO CHANNEL')}
    <div class="video-layout"><div class="video-frame">${source ? `<iframe allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen loading="lazy" src="${source}" title="${e(v.title)}"></iframe>` : 'Video unavailable'}</div>
      <div class="video-copy panel"><span class="panel-label">NOW SCREENING</span><div class="card-title">${e(v.title)}</div><h3>${e(v.artist)}</h3><p>${e(v.description)}</p><div class="system-note">If the source owner disables embedding, open the configured YouTube URL directly.</div></div></div>`);
}

// Game-specific facts use accurate labels instead of treating pets or characters
// as an in-game "role". Uploaded photos are used directly: each Roblox avatar
// is shown on the game card, and each pet photo is shown on the game detail page.
function gameArtwork(g, detail=false) {
  const picture = g.image || '';
  const className = detail ? 'game-detail__image' : 'game-cover__image';
  return `<span class="game-art__fallback" aria-hidden="true">${e(g.cover || 'GAME')}</span>${picture
    ? `<img class="${className}" src="${e(picture)}" alt="${e(g.title)} Roblox avatar screenshot" loading="lazy">`
    : ''}`;
}
function gameFactRows(g) {
  const extra = Array.isArray(g.details) && g.details.length
    ? g.details.map(d => [d.label, d.value])
    : [['IN-GAME ROLE', g.role]];
  return [['PLATFORM', g.platform], ...extra, ['MODE', g.category]];
}
function gamesPage(p) {
  const categories = [...new Set(p.games.map(g => g.category))];
  return subpage(p, `${back(purl(p),'BACK TO PROFILE')}${sectionHead('G01',`${p.nickname}'S SAVE DATA`,'MY GAME LIBRARY')}
    <div class="filter-row">${categories.map(category => `<span>${e(category)}</span>`).join('')}</div>
    <div class="game-grid">${p.games.map(g => `<a class="game-card panel" href="${purl(p)}/games/${enc(g.slug)}"><div class="game-cover ${g.image ? 'game-cover--has-image' : ''}">${gameArtwork(g)}<b>${e(p.nickname)}</b></div><small>${e(g.category)} / ${e(g.platform)}</small><div class="card-title">${e(g.title)}</div><p>${e(g.description)}</p>${Array.isArray(g.details) && g.details.length ? `<div class="game-card__facts">${g.details.map(d=>`<div><span>${e(d.label)}</span><strong>${e(d.value)}</strong></div>`).join('')}</div>` : ''}<i>OPEN SAVE FILE ${icon('arrow')}</i></a>`).join('')}</div>`);
}
function gameDetailPage(p, slug) {
  const g = p.games.find(g => g.slug === slug) || p.games[0];
  const petScreenshot = g.detailImage || g.image || '';
  return subpage(p, `${back(`${purl(p)}/games`,'BACK TO LIBRARY')}
    <div class="game-detail"><div class="game-detail__art ${g.image ? 'game-detail__art--has-image' : ''}">${gameArtwork(g,true)}<b>${e(g.category)}</b></div><div class="game-detail__copy"><div class="eyebrow">SAVE FILE / ${e(g.slug.toUpperCase())}</div><div class="display-title">${e(g.title)}</div><p>${e(g.description)}</p>
      ${gameFactRows(g).map(([label,val]) => `<div class="detail-row"><span>${e(label).toUpperCase()}</span><strong>${e(val)}</strong></div>`).join('')}</div></div>
    ${g.videoId && ytEmbed(g.videoId)
      ? `<div class="video-frame video-frame--game"><iframe allowfullscreen loading="lazy" src="${ytEmbed(g.videoId)}" title="${e(g.title)} gameplay"></iframe></div>`
      : petScreenshot
        ? `<div class="media-placeholder media-placeholder--image panel"><img class="game-media-image" src="${e(petScreenshot)}" alt="${e(g.title)} favorite pet screenshot" loading="lazy"></div>`
        : `<div class="media-placeholder panel">${icon('play')}<div><b>GAMEPLAY SLOT EMPTY</b><span>Add an authorized YouTube video ID in data/players.json.</span></div></div>`}`);
}
function hobbyPage(p, slug) {
  const h = p.hobbies.find(h => h.slug === slug) || p.hobbies[0];
  if (h.slug === 'gaming') { history.replaceState({}, '', `${purl(p)}/games`); return gamesPage(p); }
  if (p.id === 'pau' && h.slug === 'dancing-singing') { history.replaceState({}, '', `${purl(p)}/music`); return musicPage(p); }
  return subpage(p, `${back(purl(p),'BACK TO PROFILE')}<div class="hobby-hero"><span>${e(h.kicker)}</span><div class="display-title">${e(h.name)}</div><p>${e(h.description)}</p></div>
    <div class="showcase-grid">${h.items.map((item,i) => `<div class="showcase-card panel"><span>${p.id==='mond'?'PERSONAL NOTE':'ARCHIVE'} 0${i+1}</span><div class="showcase-card__art">${icon('spark')}</div><div class="card-title">${e(item)}</div>${['mond','ji'].includes(p.id)?'':`<p>Replace this card with ${e(h.name.toLowerCase())} details, images, links, or an authorized embed.</p>`}</div>`).join('')}</div>`);
}

function versusPage() {
  return `<main class="versus screen">${ambient('red')}${navHeader('SELECT','TEAM BATTLE')}
    <div class="versus__title"><small>FOUR PLAYERS ENTER</small><div>THE WHOLE <b>ROSTER</b></div><p>Four personalities. One unbeatable party.</p></div>
    <div class="versus-grid">${players.map((p,i) => `<div class="versus-card" style="${palette(p)}">${portrait(p)}<div><span>P${e(p.number)}</span><strong>${e(p.nickname)}</strong><small>${e(p.title)}</small></div>${i < players.length - 1 ? '<i>VS</i>':''}</div>`).join('')}</div>
    <div class="versus__actions">${linkButton('/roster',`MEET THE WHOLE ROSTER ${icon('arrow')}`)}${linkButton('/select','BACK TO SELECT','ghost')}</div>
  </main>`;
}
function rosterPage() {
  return `<main class="roster-page screen">${ambient()}${navHeader('SELECT','FRIENDSHIP MODE')}
    <section class="roster-hero"><div class="eyebrow">GROUP PROFILE / CO-OP MODE</div><div class="display-title">ONE ROSTER.<br>ZERO QUIET MOMENTS.</div><p>This space is ready for the group’s real story, shared memories, and favorite traditions.</p></section>
    <section class="memory-grid">${memoryTitles.map((title,i) => `<article class="memory panel"><span>MEMORY 0${i+1}</span><div class="card-title">${e(title)}</div><p>Add a true group memory or friendship fact here.</p></article>`).join('')}</section>
    <section class="roster-strip">${players.map(p => `<a style="${palette(p)}" href="${purl(p)}">${portrait(p)}<span>${e(p.nickname)}<small>${e(p.title)}</small></span></a>`).join('')}</section>
  </main>`;
}
function missingPage() {
  return `<main class="boot screen">${ambient()}<div class="boot__content"><div class="eyebrow">ERROR / 404</div><div class="display-title">FIGHTER NOT FOUND</div><p>This player or page is not in the roster.</p>${linkButton('/select',`BACK TO SELECT ${icon('arrow')}`)}</div></main>`;
}
function render() {
  if (gateUi.adminOpen) {
    app.innerHTML=gateUi.adminPage();
    gateUi.bindStage();
    document.title='Admin Settings | Fighter Select';
    return;
  }
  if (gateUi.status?.enabled && !gateUi.status?.accessGranted && location.pathname!=='/') {
    app.innerHTML=gateUi.challengePage();
    gateUi.bindStage();
    document.title='AGREE CHALLENGE | Fighter Select';
    return;
  }
  const path = decodeURIComponent(location.pathname).split('/').filter(Boolean);
  if (path.length && !players.length) {
    app.innerHTML=`<main class="boot screen">${ambient()}<div class="boot__content">LOADING FIGHTERS…</div></main>`;
    return;
  }
  let html;
  if (!path.length) html = bootPage();
  else if (path.length===1 && path[0]==='select') html=selectPage();
  else if (path.length===1 && path[0]==='versus') html=versusPage();
  else if (path.length===1 && path[0]==='roster') html=rosterPage();
  else if (path[0]==='profile' && playerById(path[1])) {
    const p = playerById(path[1]);
    if (path.length===2) html=profilePage(p);
    else if (path.length===3 && path[2]==='music') html=musicPage(p);
    else if (path.length===4 && path[2]==='video') html=videoPage(p,path[3]);
    else if (path.length===3 && path[2]==='games') html=gamesPage(p);
    else if (path.length===4 && path[2]==='games') html=gameDetailPage(p,path[3]);
    else if (path.length===4 && path[2]==='hobby') html=hobbyPage(p,path[3]);
  }
  app.innerHTML = html || missingPage();
  document.title = `${playerById(path[1])?.nickname || 'Fighter Select'} | Four-Player Edition`;
  const audio = document.getElementById('music-audio'); if (audio) bindMusic();
  app.querySelectorAll('img').forEach(img => {
    const portraitEl = img.closest('.portrait');
    if (portraitEl && img.classList.contains('portrait__pose--hover')) {
      const enableHover = () => portraitEl.classList.add('portrait--hover-loaded');
      if (img.complete && img.naturalWidth > 0) enableHover();
      else img.addEventListener('load', enableHover, {once:true});
    }
    const showErrorFallback = () => {
      img.hidden = true;
      if (portraitEl && img.classList.contains('portrait__pose--hover')) {
        portraitEl.classList.remove('portrait--hover-loaded');
      }
      if (portraitEl && img.classList.contains('portrait__pose--base')) {
        const fb = portraitEl.querySelector('.portrait__fallback');
        if (fb) fb.hidden = false;
      }
    };
    img.addEventListener('error', showErrorFallback);
    if (img.complete && img.naturalWidth === 0) showErrorFallback();
  });
  app.querySelectorAll('.fighter-card').forEach(card => {
    card.addEventListener('mouseenter', () => updateHover(card.dataset.id));
    card.addEventListener('focus', () => updateHover(card.dataset.id));
  });
}
function navigate(url, replace=false) {
  const normalized = new URL(url,window.location.href);
  if (normalized.origin!==location.origin) { location.assign(normalized.href); return; }
  if (replace) history.replaceState({},'',normalized.pathname);
  else if (location.pathname!==normalized.pathname) history.pushState({},'',normalized.pathname);
  window.scrollTo(0,0);
  render();
}
app.addEventListener('click', ev => {
  const anchor = ev.target.closest('a[href]');
  if (anchor && ev.button===0 && !ev.ctrlKey && !ev.metaKey && !ev.shiftKey && !ev.altKey && !anchor.target) {
    const target = new URL(anchor.href,location.href);
    if (target.origin===location.origin) { ev.preventDefault(); navigate(target.pathname); return; }
  }
  const button = ev.target.closest('button[data-action]');
  if (!button || button.disabled) return;
  const action=button.dataset.action;
  if (gateUi.handleClick(action,button)) return;
  if (action==='toggle-sound') { muted=!muted; render(); }
  else if (action==='select-player') { selectedId=button.dataset.id; hoveredId=selectedId; render(); }
  else if (action==='random-select') { const p=players[Math.floor(Math.random()*players.length)]; selectedId=p.id; hoveredId=p.id; render(); }
  else if (action==='confirm-select') { if (selectedId) navigate(purl(playerById(selectedId))); }
  else if (action==='track-prev') advanceTrack(-1);
  else if (action==='track-next') advanceTrack(1);
  else if (action==='play-video-track') playVideoTrack(button.dataset.player,Number(button.dataset.index));
  else if (action==='choose-track') { musicState.track=+button.dataset.index; render(); }
  else if (action==='track-toggle') {
    const audio=document.getElementById('music-audio');
    if (audio) {
      if (audio.paused) audio.play().catch(() => {
        button.setAttribute('title','Audio could not load. Check your internet connection.');
      }); else audio.pause();
    }
  }
});
app.addEventListener('input', ev => gateUi.handleInput(ev.target));
app.addEventListener('submit', ev => {
  if (gateUi.handleSubmit(ev.target)) ev.preventDefault();
});
window.addEventListener('popstate',render);
async function loadPlayers() {
  if (players.length) return;
  const response = await fetch('/api/players', {headers:{Accept:'application/json'},credentials:'same-origin'});
  if (!response.ok) throw new Error('Could not load fighter profiles');
  const data = await response.json();
  if (!Array.isArray(data) || data.length!==4) throw new Error('Expected the four-player roster');
  players=data;
    // Keep old character bookmarks working, including nested music/game/hobby pages.
    const renamedIds = {echo:'al', nova:'ji', mimi:'pau', jax:'mond'};
    const oldRoute = location.pathname.match(/^\/profile\/(echo|nova|mimi|jax)(?=\/|$)/);
    if (oldRoute) {
      const newId = renamedIds[oldRoute[1]];
      history.replaceState({}, '', location.pathname.replace(
        new RegExp(`^/profile/${oldRoute[1]}(?=/|$)`), `/profile/${newId}`
      ) + location.search + location.hash);
    }
}
async function start() {
  try {
    await gateUi.init();
    if (gateUi.status.accessGranted) await loadPlayers();
    render();
  } catch (error) {
    app.innerHTML = `<main class="boot screen">${ambient()}<div class="boot__content"><div class="display-title">SERVER UNAVAILABLE</div><p>${e(error.message)}</p><p>Start Spring Boot, then refresh this page. Check GET /api/gate/status.</p></div></main>`;
  }
}
start();
