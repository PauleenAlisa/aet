/* Fighter Select's EXTREME AGREE CHALLENGE. The server decides admission and
   stores the admin password only in its own configuration, never in this file. */
'use strict';
const gateUi = {
  status: null,
  adminOpen: false,
  error: '',
  busy: false,
  ui: {id:'', clicks:0, lastClick:0, chase:0, sequence:[], holding:false, dodges:0, combo:[], failures:0, taps:0, reveals:0},
  timer: null,

  async request(path, body) {
    const response = await fetch('/api/gate/' + path, {
      method: body === undefined ? 'GET' : 'POST',
      credentials: 'same-origin',
      headers: body === undefined ? {Accept:'application/json'} : {'Content-Type':'application/json',Accept:'application/json'},
      cache:'no-store',
      ...(body === undefined ? {} : {body:JSON.stringify(body)})
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.detail || data.message || data.error || 'Please try again.');
    return data;
  },

  async init() { this.status = await this.request('status'); },
  async advance(proof) {
    if (this.busy || !this.status?.challenge) return;
    this.busy = true; this.error = '';
    try {
      this.status = await this.request('agree', {challengeId:this.status.challenge.id, proof});
      this.resetUI();
      if (this.status.accessGranted) {
        await loadPlayers();
        navigate('/select', true);
      } else render();
    } catch (error) {this.error = error.message;render();}
    finally {this.busy = false;}
  },
  resetUI() {
    this.ui = {id:'', clicks:0, lastClick:0, chase:0, sequence:[], holding:false, dodges:0, combo:[], failures:0, taps:0, reveals:0};
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
  },
  async fail(message) {
    if (this.busy) return;
    this.busy = true;
    try {
      const before = this.status?.completedSteps ?? 0;
      this.status = await this.request('mistake',{});
      const reset = before > this.status.completedSteps || this.ui.id !== this.status.challenge?.id;
      this.error = reset
        ? 'THREE STRIKES. Back to condition ONE! All your progress is gone. The rules have reshuffled.'
        : `${message} Strike ${this.status.strikes}/3. Three strikes reset EVERYTHING.`;
      if (reset) { this.resetUI(); render(); }
      else this.showError();
    } catch (err) {this.error=err.message;this.showError();}
    finally {this.busy=false;}
  },
  async restart() {
    try {this.status = await this.request('restart',{});this.error='';this.resetUI();render();}
    catch(error) {this.error=error.message;render();}
  },
  openAdmin() {this.adminOpen=true;this.error='';render();},
  closeAdmin() {this.adminOpen=false;this.error='';render();},
  async login(password) {
    this.busy=true;this.error='';
    try {this.status=await this.request('admin/login',{password});await loadPlayers();render();}
    catch(error) {this.error=error.message;render();}
    finally {this.busy=false;}
  },
  async toggle() {
    this.busy=true;this.error='';
    try {this.status=await this.request('admin/toggle',{enabled:!this.status.enabled});await loadPlayers();render();}
    catch(error) {this.error=error.message;render();}
    finally {this.busy=false;}
  },
  async logout() {
    try {
      await this.request('admin/logout',{});
      this.adminOpen=false;this.error='';this.resetUI();players=[];
      this.status=await this.request('status');
      navigate('/',true);
    } catch(error) {this.error=error.message;render();}
  },
  shell(content, heading) {
    return `<main class="gate-screen screen">${ambient()}<header class="gate-topbar"><a href="/" class="mini-brand">PROFILE <b>SELECT</b></a><span>TERMS.EXE // ${e(heading)}</span><button class="gate-text-button" type="button" data-action="admin-open">⚙ ADMIN ACCESS</button></header>${content}</main>`;
  },
  errorBox() {return this.error ? `<p class="gate-error" role="alert">⚠ ${e(this.error)}</p>` : '';},
  challengePage() {
    const state = this.status;
    const ch = state.challenge;
    if (!ch) return this.shell('<div class="gate-card">Opening character selection…</div>','DONE');
    const step = state.completedSteps + 1;
    const pct = Math.round((state.completedSteps / state.totalSteps)*100);
    const phrase = ch.config?.phrase || '';
    const seq = ch.config?.sequence || [5,3,1,4,2];
    const mode = ch.mode;
    let interaction = '';
    const agreeBtn = (label='I AGREE ✓',action='gate-agree',attrs='') => `<button class="gate-agree-btn" type="button" data-action="${action}" ${attrs}>${e(label)}</button>`;
    const mini = t => `<div class="gate-mini">${t}</div>`;
    switch(mode) {
      case 'double': interaction=agreeBtn('SEVEN CLICKS. FAST.','gate-double') + '<div class="gate-mini" id="gate-triple-caption">Rapid hits: 0 / 7</div>'; break;
      case 'hold': interaction=agreeBtn('HOLD FOR 8.5 SECONDS.','gate-hold','aria-label="Hold to agree for eight and a half seconds"') + mini('Release early and the timer resets. Mouse, touch, or keyboard.'); break;
      case 'chase': interaction=`<div class="gate-chase-zone"><button type="button" data-action="gate-chase" class="gate-chase-button" style="left:8%;top:34%">CATCH ME, LOSER</button></div><div class="gate-mini" id="gate-chase-caption">Caught: 0 / 12</div>`; break;
      case 'reverse': interaction=`<div class="gate-reverse-options">${agreeBtn('YES! I AGREE ✓','gate-fake-agree')}${agreeBtn('NO. I DISAGREE ✕','gate-reverse')}</div>`; break;
      case 'checks': interaction=`<div class="gate-checks">${Array.from({length:9},(_,i)=>`<label><input type="checkbox" data-gate-check data-check-index="${i}"> Clause ${i+1}: ${e(['I promise to read.','I surrender my snacks.','I love extra steps.','I definitely read everything.','I enjoy inconvenience.','I accept fake paperwork.','I will stop complaining.','This clause seems suspicious.','My mouse has filed a complaint.'][i])}</label>`).join('')}</div>${agreeBtn('VERIFY NINE BOXES','gate-check-submit')}`; break;
      case 'type': interaction=`<label class="gate-phrase-label">EXACT CHARACTERS ONLY<strong>${e(phrase)}</strong><input id="gate-phrase" type="text" autocomplete="off" autocapitalize="off" spellcheck="false" aria-label="Exact agreement phrase" placeholder="One tiny typo = one strike"></label>${agreeBtn('SUBMIT EXACT PHRASE','gate-type-submit')}`; break;
      case 'slider': interaction=`<label class="gate-slide-label" for="gate-slider">TARGET: <b>${e(ch.config.target)}%</b> <strong id="gate-slider-value">0%</strong></label><input id="gate-slider" type="range" min="0" max="100" value="0" step="1">${agreeBtn('SUBMIT PERCENTAGE','gate-slider-submit')}${mini('Keyboard arrow keys are allowed. One percent off is a STRIKE.')}`; break;
      case 'sequence': interaction=`<div class="gate-mini" id="gate-sequence-order">MEMORIZE: <strong>${seq.map(v=>e(v)).join(' → ')}</strong> (vanishes in 4s)</div><div class="gate-sequence">${[1,2,3,4,5,6,7,8].map(i=>`<button type="button" data-action="gate-sequence" data-number="${i}">${String(i).padStart(2,'0')}</button>`).join('')}</div><div class="gate-mini" id="gate-sequence-caption">Correct presses: 0 / 8</div>`; break;
      case 'timer': interaction=`<div class="gate-clock">⏳ <span id="gate-countdown">WAIT…</span></div>${agreeBtn('YOU CANNOT CLICK YET','gate-timer','disabled')}`; break;
      case 'target': interaction=`<div class="gate-target-grid gate-target-grid--extreme">${Array.from({length:30},(_,i)=>i+1).map(n=>`<button type="button" data-action="gate-target" data-slot="${n}" aria-label="${n===ch.config.correctSlot?'AGREE exclamation mark':'AGREE period'}">${n===ch.config.correctSlot?'AGREE!':'AGREE.'}</button>`).join('')}</div>${mini('Thirty nearly identical buttons. Find ONE exclamation mark.')}`; break;
      case 'math': interaction=`<div class="gate-math">(${e(ch.config.a)} × ${e(ch.config.b)}) + (${e(ch.config.c)} × ${e(ch.config.d)}) − ${e(ch.config.minus)} = ?</div><label class="gate-phrase-label">ACCOUNTANT APPROVAL<input id="gate-math" type="number" inputmode="numeric" placeholder="Exact answer" aria-label="Math answer"></label>${agreeBtn('VERIFY MY MATHEMATICS','gate-math-submit')}`; break;
      case 'memory': interaction=`<div class="gate-memory" aria-live="polite"><span id="gate-memory-code">${e(ch.config.code)}</span></div><button type="button" data-action="gate-memory-reveal" class="gate-outline-btn" id="gate-memory-reveal">ONE EXTRA REVEAL</button><label class="gate-phrase-label">TYPE THE VANISHING CODE<input id="gate-memory-input" type="text" autocapitalize="off" autocomplete="off" spellcheck="false" aria-label="Memorized code" placeholder="Letters, numbers, hyphens"></label>${agreeBtn('VERIFY MEMORY','gate-memory-submit')}`; break;
      case 'scroll': interaction=`<div class="gate-scroll-terms" id="gate-scroll-terms" tabindex="0" role="region" aria-label="Scrollable terms">${Array.from({length:40},(_,i)=>`<p><b>Clause ${i+1}:</b> I solemnly acknowledge the absurd possibility that I will need to read every single clause of this entirely fictional agreement, and that I will never complain about choosing to play the extreme difficulty mode.</p>`).join('')}<p><b>FINAL CLAUSE:</b> There are really forty clauses. Congratulations on wasting precious seconds.</p></div>${agreeBtn('CONFIRM ALL 40 CLAUSES','gate-scroll-submit','disabled')}${mini('Scroll INSIDE the little terms box. The page itself does not count.')}`; break;
      case 'switches': interaction=`<div class="gate-checks gate-switches">${Array.from({length:9},(_,i)=>`<label><input type="checkbox" data-gate-switch> SWITCH ${String(i+1).padStart(2,'0')}</label>`).join('')}</div>${agreeBtn('AUDIT SWITCHES','gate-switches-submit')}`; break;
      case 'combo': interaction=`<div class="gate-mini" id="gate-combo-instructions">RITUAL: ${ch.config.combo.map(k=>k==='A'?'AGREE':'DISAGREE').join(' → ')} <small>(HIDES IN 4s)</small></div><div class="gate-combo"><button type="button" data-action="gate-combo" data-kind="A" class="gate-agree-btn">AGREE ✓</button><button type="button" data-action="gate-combo" data-kind="D" class="gate-outline-btn">DISAGREE ✕</button></div><div class="gate-mini" id="gate-combo-caption">Correct taps: 0 / ${ch.config.combo.length}</div>`; break;
      case 'tapcount': interaction=`<div class="gate-clickcount" id="gate-clickcount">0 / ${e(ch.config.count)}</div><button type="button" class="gate-agree-btn" data-action="gate-tapcount">TAP EXACTLY ${e(ch.config.count)} TIMES</button>${agreeBtn('CLAIM MY CLICKS','gate-tap-submit')}${mini('One click too many is a strike. No take-backs.')}`; break;
      case 'captcha': interaction=`<div class="gate-fruit-grid" aria-label="Fruit counting puzzle">${ch.config.icons.map(icon=>`<span>${e(icon)}</span>`).join('')}</div><label class="gate-phrase-label">NUMBER OF RED APPLES (NOT LEMONS)<input id="gate-captcha" inputmode="numeric" type="number" min="0" aria-label="Apple count" placeholder="Count carefully"></label>${agreeBtn('VERIFY FRUIT COUNT','gate-captcha-submit')}`; break;
      case 'arrows': interaction=`<div class="gate-arrow-seq">${ch.config.arrows.map(dir=>`<span>${({U:'↑',D:'↓',L:'←',R:'→'})[dir]}</span>`).join('')}</div><div class="gate-arrow-pad">${[['U','↑'],['L','←'],['D','↓'],['R','→']].map(([dir,symbol])=>`<button type="button" data-action="gate-arrow" data-dir="${dir}">${symbol}</button>`).join('')}</div><div class="gate-mini" id="gate-arrow-caption">Correct moves: 0 / 11</div>`; break;
      case 'mirror': interaction=`<div class="gate-mirror-word">${e(ch.config.phrase)}</div><label class="gate-phrase-label">REVERSE THE WHOLE LINE<input id="gate-mirror" type="text" autocomplete="off" autocapitalize="off" spellcheck="false" aria-label="Reversed phrase" placeholder="Last character first"></label>${agreeBtn('SUBMIT MIRRORED TEXT','gate-mirror-submit')}`; break;
      default: interaction=agreeBtn();
    }
    return this.shell(`<div class="gate-wrap"><div class="gate-kicker">RAGEBAIT AGREEMENT PROTOCOL // EXTREME MODE</div><div class="gate-title">AGREE<span>EEE!</span></div>
      <p class="gate-lead">Ten brutal conditions. Three mistakes erase your progress. It is technically possible. Your patience might not survive.</p>
      <div class="gate-progress-text"><span>CRUEL CONDITION ${String(step).padStart(2,'0')} / 10</span><span>${pct}% ESCAPED</span></div>
      <div class="gate-strikes" aria-label="Mistake counter">${Array.from({length:3},(_,i)=>`<span class="${i<(state.strikes||0)?'is-strike':''}">${i<(state.strikes||0)?'✕ STRIKE':'○ LIFE'}</span>`).join('')}<strong>3 WRONG ANSWERS = BACK TO ZERO</strong></div><div class="gate-progress"><i style="width:${pct}%"></i></div>
      <article class="gate-card"><div class="gate-card-number">${String(step).padStart(2,'0')} <span>TERMS YOU REGRET ACCEPTING</span></div><div class="gate-card-title">${e(ch.title)}</div>
       <p class="gate-term">“${e(ch.term)}”</p><p class="gate-instruction">${e(ch.hint)}</p><div class="gate-stage" data-mode="${e(mode)}">${interaction}</div>
       ${this.errorBox()}<div class="gate-card-foot"><span>PARODY GAME · NOT A LEGAL AGREEMENT</span><button type="button" class="gate-text-button" data-action="gate-restart">RESHUFFLE FROM ZERO ↻</button></div>
      </article></div>`, 'HARD CHECKPOINT');
  },
  adminPage() {
    const configured = this.status?.adminConfigured;
    const logged = this.status?.adminAuthenticated;
    return this.shell(`<div class="gate-wrap gate-wrap--admin"><div class="gate-kicker">AUTHORIZED HUMANS ONLY</div><div class="gate-title">ADMIN <span>MODE</span></div>
      <article class="gate-card"><div class="gate-card-title">${logged?'THE SECRET CONTROL ROOM':'ENTER ADMIN PASSWORD'}</div>
       ${logged
          ? `<p class="gate-term">You can skip the Agree challenge, or switch it off for everyone using this server.</p>
             <div class="gate-admin-status">AGREE CHALLENGE: <b>${this.status.enabled?'ENABLED':'DISABLED'}</b></div>
             <div class="gate-admin-actions"><button type="button" class="gate-agree-btn" data-action="admin-toggle">${this.status.enabled?'DISABLE FOR EVERYONE':'ENABLE FOR EVERYONE'}</button>
             <button type="button" class="gate-outline-btn" data-action="admin-continue">SKIP TO ROSTER →</button>
             <button type="button" class="gate-outline-btn" data-action="admin-logout">LOG OUT</button></div>
             <p class="gate-mini">Changes to the global switch are saved on the server and persist after restart.</p>`
          : configured
            ? `<p class="gate-term">Admins can skip the challenge or disable it. Enter the server-configured password.</p><form id="gate-admin-login" class="gate-admin-login"><label for="gate-admin-password">PASSWORD</label><input type="password" id="gate-admin-password" name="password" autocomplete="current-password" required autofocus placeholder="Admin password"><button class="gate-agree-btn" type="submit">UNLOCK ADMIN</button></form>`
            : `<p class="gate-term">Admin login is not configured yet. Start Spring Boot with the <code>AGREE_ADMIN_PASSWORD</code> environment variable to enable it. No default password is included.</p>`}
       ${this.errorBox()}<div class="gate-card-foot"><span>THE ADMIN PASSWORD IS VERIFIED BY SPRING BOOT</span><button type="button" class="gate-text-button" data-action="admin-close">← BACK</button></div>
      </article></div>`, 'ADMIN');
  },
  bindStage() {
    if (this.timer) {clearTimeout(this.timer);this.timer=null;}
    const ch=this.status?.challenge;
    if (!ch) return;
    if (this.ui.id !== ch.id) this.resetUI();
    this.ui.id=ch.id;
    if (ch.mode==='timer') {
      const remaining=Math.max(0,Number(ch.waitMs ?? 12000));
      const button=document.querySelector('[data-action="gate-timer"]');
      const caption=document.getElementById('gate-countdown');
      if (button && caption) {
        const unlock=()=>{button.disabled=false;button.textContent='FINALLY. I AGREE ✓';caption.textContent='NOW!';};
        if (remaining<=0) unlock();
        else {caption.textContent=`${(remaining/1000).toFixed(1)} SECONDS`;this.timer=setTimeout(unlock,remaining+150);}
      }
    }
    if (ch.mode==='hold') {
      const button=document.querySelector('[data-action="gate-hold"]');
      if (!button) return;
      let holdTimer;
      const start=ev=>{
        if(ev.type==='keydown' && !['Space','Enter'].includes(ev.code))return;
        if(ev.repeat || this.ui.holding)return;
        if(ev.type==='keydown')ev.preventDefault();
        this.ui.holding=true;button.textContent='KEEP HOLDING…';
        holdTimer=setTimeout(()=>{if(this.ui.holding){this.ui.holding=false;this.advance('held');}},8500);
      };
      const stop=()=>{this.ui.holding=false;clearTimeout(holdTimer);if(document.contains(button))button.textContent='HOLD FOR 8.5 SECONDS.';};
      button.addEventListener('pointerdown',start);
      button.addEventListener('pointerup',stop);
      button.addEventListener('pointerleave',stop);
      button.addEventListener('pointercancel',stop);
      button.addEventListener('keydown',start);
      button.addEventListener('keyup',stop);
      button.addEventListener('blur',stop);
      button.addEventListener('contextmenu',ev=>ev.preventDefault());
    }
    if (ch.mode==='memory') {
      const code=document.getElementById('gate-memory-code');
      if (code) this.timer=setTimeout(()=>{code.textContent='● ● ● ● ● ● ● ● ● ● ● ● ● ●';},1100);
    }
    if (ch.mode==='sequence') {
      this.timer=setTimeout(()=>{const caption=document.getElementById('gate-sequence-order');if(caption)caption.textContent='ORDER HIDDEN. Hope you memorized it.';},4000);
    }
    if (ch.mode==='combo') {
      this.timer=setTimeout(()=>{const caption=document.getElementById('gate-combo-instructions');if(caption)caption.textContent='RITUAL HIDDEN. Good luck.';},4000);
    }
    if (ch.mode==='scroll') {
      const area=document.getElementById('gate-scroll-terms');
      const agree=document.querySelector('[data-action="gate-scroll-submit"]');
      const check=()=>{if(area && agree && area.scrollTop+area.clientHeight>=area.scrollHeight-8){agree.disabled=false;agree.textContent='FINALLY, I AGREE';}};
      area?.addEventListener('scroll',check);
      check();
    }
    if (ch.mode==='chase') {
      const button=document.querySelector('[data-action="gate-chase"]');
      button?.addEventListener('pointerenter',()=>{
        if(this.ui.dodges<5 && !window.matchMedia('(prefers-reduced-motion: reduce)').matches){
          this.ui.dodges++;
          this.moveChaseButton(button);
        }
      });
    }
  },
  moveChaseButton(button) {
    button.style.left=(2+Math.floor(Math.random()*72))+'%';
    button.style.top=(2+Math.floor(Math.random()*68))+'%';
  },
  handleClick(action,button) {
    if (action==='admin-open') {this.openAdmin();return true;}
    if (action==='admin-close') {this.closeAdmin();return true;}
    if (action==='admin-toggle') {this.toggle();return true;}
    if (action==='admin-logout') {this.logout();return true;}
    if (action==='admin-continue') {this.closeAdmin();navigate('/select');return true;}
    if (action==='gate-restart') {this.restart();return true;}
    if (!action.startsWith('gate-')) return false;
    const ch=this.status?.challenge;if(!ch)return true;
    switch(action) {
      case 'gate-agree': this.advance('tap'); break;
      case 'gate-double': {
        const now=Date.now();this.ui.clicks=(now-this.ui.lastClick<320)?this.ui.clicks+1:1;
        this.ui.lastClick=now;
        if(this.ui.clicks>=7)this.advance('septuple');
        else {const label=document.getElementById('gate-triple-caption');if(label)label.textContent=`Rapid hits: ${this.ui.clicks} / 7`;}
        break;
      }
      case 'gate-hold': break;
      case 'gate-chase': {
        this.ui.chase++;
        const label=document.getElementById('gate-chase-caption');
        if(label)label.textContent=`Caught: ${Math.min(this.ui.chase,12)} / 12`;
        if(this.ui.chase>=12)this.advance('caught');
        else this.moveChaseButton(button);
        break;
      }
      case 'gate-fake-agree':this.fail('The shiny button was BAIT. Read the instructions!');break;
      case 'gate-reverse':this.advance('reverse');break;
      case 'gate-check-submit': {
        const mask=[...document.querySelectorAll('[data-gate-check]')].map(c=>c.checked?'1':'0').join('');
        if(mask==='010010010')this.advance(mask);
        else this.fail('Wrong checkboxes. ONLY boxes 2, 5 and 8.');
        break;
      }
      case 'gate-type-submit': {
        const typed=document.getElementById('gate-phrase')?.value ?? '';
        if(typed===ch.config.phrase)this.advance(typed);
        else this.fail('One character is wrong. Check spacing AND punctuation.');
        break;
      }
      case 'gate-slider-submit': {
        const val=Number(document.getElementById('gate-slider')?.value);
        if(val===Number(ch.config.target))this.advance(String(val));
        else this.fail(`You selected ${val}%. It demands ${ch.config.target}% EXACTLY.`);
        break;
      }
      case 'gate-sequence': {
        const n=Number(button.dataset.number), seq=ch.config.sequence;
        if(n!==seq[this.ui.sequence.length]) {
          this.ui.sequence=[];this.fail('Wrong number. The eight-button sequence was reset.');
          const label=document.getElementById('gate-sequence-caption');if(label)label.textContent='Correct presses: 0 / 8';
        } else {
          this.ui.sequence.push(n);
          const label=document.getElementById('gate-sequence-caption');if(label)label.textContent=`Correct presses: ${this.ui.sequence.length} / 8`;
          if(this.ui.sequence.length===seq.length)this.advance(this.ui.sequence.join('-'));
        }
        break;
      }
      case 'gate-timer':this.advance('waited');break;
      case 'gate-target': {
        if(Number(button.dataset.slot)===ch.config.correctSlot)this.advance('slot-'+button.dataset.slot);
        else this.fail('WRONG AGREE. One punctuation mark decides your fate.');
        break;
      }
      case 'gate-math-submit': {
        const answer=document.getElementById('gate-math')?.value;
        const x=ch.config,correct=x.a*x.b+x.c*x.d-x.minus;
        if(answer!==''&&Number(answer)===correct)this.advance(String(correct));
        else this.fail('Your arithmetic disagrees. Try a calculator.');
        break;
      }
      case 'gate-memory-reveal': {
        if(this.ui.reveals>=1){this.fail('You already used the extra reveal!');break;}
        this.ui.reveals++;
        const display=document.getElementById('gate-memory-code');
        if(display){display.textContent=ch.config.code;
          if(this.timer)clearTimeout(this.timer);
          this.timer=setTimeout(()=>{if(document.contains(display))display.textContent='● ● ● ● ● ● ● ● ● ● ● ● ● ●';},1100);
        }
        button.disabled=true;button.textContent='NO MORE REVEALS';
        break;
      }
      case 'gate-memory-submit': {
        const typed=document.getElementById('gate-memory-input')?.value ?? '';
        if(typed===ch.config.code)this.advance(typed);
        else this.fail('Wrong vanished code. Next time memorize every dash.');
        break;
      }
      case 'gate-scroll-submit':this.advance('scrolled');break;
      case 'gate-switches-submit': {
        const mask=[...document.querySelectorAll('[data-gate-switch]')].map(c=>c.checked?'1':'0').join('');
        if(mask==='101001001')this.advance(mask);
        else this.fail('The switch audit failed. ONLY 1, 3, 6, and 9 should be ON.');
        break;
      }
      case 'gate-combo': {
        const pattern=ch.config.combo, symbol=button.dataset.kind;
        if(symbol!==pattern[this.ui.combo.length]) {
          this.ui.combo=[];this.fail('Ritual error. Your nine-step combination starts over.');
        } else {
          this.ui.combo.push(symbol);
          if(this.ui.combo.length===pattern.length)this.advance('combo');
        }
        const label=document.getElementById('gate-combo-caption');
        if(label)label.textContent=`Correct taps: ${this.ui.combo.length} / ${pattern.length}`;
        break;
      }
      case 'gate-tapcount': {
        this.ui.taps++;
        const label=document.getElementById('gate-clickcount');
        if(label)label.textContent=`${this.ui.taps} / ${ch.config.count}`;
        if(this.ui.taps>ch.config.count){this.ui.taps=0;this.fail('OVERCLICK! The click counter returns to zero.');}
        break;
      }
      case 'gate-tap-submit': {
        if(this.ui.taps===ch.config.count)this.advance(String(ch.config.count));
        else this.fail(`You clicked ${this.ui.taps} times, but the target is ${ch.config.count}.`);
        break;
      }
      case 'gate-captcha-submit': {
        const val=document.getElementById('gate-captcha')?.value ?? '';
        const correct=ch.config.icons.filter(v=>v==='🍎').length;
        if(val!=='' && Number(val)===correct)this.advance(String(correct));
        else this.fail('Wrong apple count. Those lemons were NOT apples.');
        break;
      }
      case 'gate-arrow': {
        const seq=ch.config.arrows,dir=button.dataset.dir;
        if(dir!==seq[this.ui.sequence.length]){this.ui.sequence=[];this.fail('WRONG DIRECTION. Start all eleven arrows again.');}
        else {this.ui.sequence.push(dir);if(this.ui.sequence.length===seq.length)this.advance(seq.join(''));}
        const label=document.getElementById('gate-arrow-caption');if(label)label.textContent=`Correct moves: ${this.ui.sequence.length} / ${seq.length}`;
        break;
      }
      case 'gate-mirror-submit': {
        const typed=document.getElementById('gate-mirror')?.value ?? '';
        const correct=[...ch.config.phrase].reverse().join('');
        if(typed===correct)this.advance(correct);
        else this.fail('That sentence is not perfectly reversed. Even punctuation counts.');
        break;
      }
    }
    return true;
  },
  showError() {
    const region=document.querySelector('.gate-error');
    if(region)region.textContent='⚠ '+this.error;
    else {
      const stage=document.querySelector('.gate-stage');
      if(stage)stage.insertAdjacentHTML('afterend',`<p class="gate-error" role="alert">⚠ ${e(this.error)}</p>`);
    }
  },
  handleInput(target) {
    if (target?.id==='gate-slider') {
      const label=document.getElementById('gate-slider-value');
      if(label)label.textContent=target.value+'%';
    }
  },
  handleSubmit(form) {
    if (form.id==='gate-admin-login') {this.login(form.elements.password.value);return true;}
    return false;
  }
};
