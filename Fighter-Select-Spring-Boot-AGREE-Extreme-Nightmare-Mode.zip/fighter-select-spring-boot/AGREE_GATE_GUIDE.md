# Fighter Select — AGREE Challenge + Admin Control

## How it works

The normal experience is **Start → 10 shuffled, deliberately frustrating mini-agreements → Character selection**. All 4 profile cards, music, games and uploaded photos stay intact.

The 10 stages are chosen and shuffled for each new session from a pool of 11 mini-games: simple click, quick double click, long press, chase, inverted agree/disagree, check boxes, type an exact phrase, slider, click numbers in order, wait for a timer, and avoid decoy buttons. Finish all 10 to open the roster. Players retain access for the current server/browser session. These are **humorous in-game conditions**, not real legal consent.

Entering `/select` or a profile URL directly does not skip the game. The Java server also rejects unauthenticated `/api/players` calls while the gate is enabled. A new browser session normally starts the challenge again. On every restart/reshuffle the challenge order changes.

## Set up the admin password (Mac Terminal)

You must have Java 17+ and Apache Maven. From the extracted `fighter-select-spring-boot` folder:

```bash
cd /Users/pau/Downloads/fighter-select-spring-boot
export AGREE_ADMIN_PASSWORD='replace-with-your-own-strong-password'
mvn clean spring-boot:run
```

Choose a **unique, strong password**; replace the example value. The password is read by Spring Boot on the server, **never hard-coded into JavaScript or displayed in the app**. Use your own terminal, not screenshots/messages, to enter it. There is **no default admin password**.

Alternatively, after Maven is installed, run `bash run-mac.sh` from the project directory to be prompted privately for the admin password.

Now open http://localhost:8080. On the start screen or the agreement screen, click **⚙ ADMIN** to enter the password. Once signed in, select **SKIP TO ROSTER**, or use **DISABLE FOR EVERYONE** to turn the game off. The same button becomes **ENABLE FOR EVERYONE** to restore it. A global toggle is saved in `config/agree-gate.properties` so it persists across restarts. The `config/` setting is excluded from Git; it is not a password file.

If you are already running the server in another terminal without the password, **stop it using Ctrl+C** and restart it using the commands above. Environment variables must be set in the **same terminal** that launches Maven. VS Code's Run Java button doesn't pass variables from an unrelated terminal automatically.

If Homebrew/Maven is missing on Mac, use the official instructions at https://brew.sh/ to install Homebrew, then `brew install maven`. Check `mvn -version` before running Spring Boot. You can also install Maven directly from https://maven.apache.org/download.cgi (Homebrew is optional).

## Other settings

- The game is initially enabled (`AGREE_GATE_ENABLED=true`). After an admin toggle, the file setting takes precedence. To reset it, stop the server and remove `config/agree-gate.properties`.
- Set `AGREE_GATE_STATE_FILE` to customize the persistent setting location; leave it blank to disable persistence (testing only).
- If `AGREE_ADMIN_PASSWORD` is unset, the game still works but admin login remains unavailable.
- Admin login throttles repeated failed attempts (five wrong passwords lead to a 30-second lockout per session).
- Admin login uses server-side HTTP sessions and HttpOnly, SameSite=Lax cookies. For any public hosting, use HTTPS and production-grade authentication/CSRF protections rather than treating this local demo as a full identity platform.

## Diagnostics

- `GET /api/gate/status` — gate status and current challenge (never reveals the password).
- `GET /api/players` — returns HTTP 403 until the session is admitted, if the gate is enabled.
- To test: `mvn test`, then `mvn spring-boot:run`.
- Browser cache: reload using Cmd+Shift+R after upgrading the project.
