# AGREEEEE! — EXTREME / NIGHTMARE MODE

This build includes a deliberately frustrating **parody** agreement challenge before the four-player character roster opens. It is not actual legal consent.

## Rules

- Exactly **10 conditions** per visitor run, selected randomly without repeats from **19 puzzle types**.
- **Three mistakes reset the entire run to Condition 1**, and the server shuffles a fresh set of challenges. Mistakes persist across page refreshes within the same visitor session.
- The 19 challenge types include: seven rapid clicks, 8.5-second hold, twelve moving-button catches, reverse Agree/Disagree, nine checkboxes, exact phrase, precise percentage slider, eight-number sequence, twelve-second wait, thirty near-identical buttons, compound arithmetic, 1.1-second code, forty scroll clauses, nine switches, nine-step combo, exact 24–31 clicks, fruit-counting puzzle, eleven-arrow sequence, and reversed-text puzzle.
- The challenge remains possible to complete. It is designed to be annoying, not secretly unbeatable.

## Admin control

To set an admin password and launch the app on macOS/Linux, open a terminal **inside** the extracted `fighter-select-spring-boot` folder and run:

```bash
bash run-mac.sh
```

Alternatively, set `AGREE_ADMIN_PASSWORD` as an environment variable and start with `mvn clean spring-boot:run`. The **ADMIN ACCESS** button provides password-protected options to skip the game or disable it globally. There is **no built-in default password**; do not publish your password in the project or in screenshots.

Turning off the game globally is saved to `./config/agree-gate.properties`, so the state persists when the server restarts. This is a **local demonstration project**, bound to `127.0.0.1` by default.

## What was changed

- `src/main/java/com/fighterselect/gate/AgreeGateService.java`: difficulty, randomized challenges, server-backed strike tracking.
- `src/main/java/com/fighterselect/gate/AgreeGateController.java`: `POST /api/gate/mistake` endpoint.
- `src/main/resources/static/js/gate-ui.js`: puzzle controls and three-strike UI.
- `src/main/resources/static/css/app.css`: denser puzzle layout, strike counter, mobile styles.
- `src/main/resources/static/index.html`: cache-busting asset version.
- `src/test/java/com/fighterselect/AgreeGateIntegrationTests.java`: updated challenge proof tests and three-strike reset assertion.

## Troubleshooting

If `bash run-mac.sh` reports `No such file or directory`, first change into the correct folder with `cd ~/Downloads/fighter-select-spring-boot` (or your actual extraction location). Check `ls` for `pom.xml` and `run-mac.sh`. If the application exits, look for the **first `Caused by:`** line above Maven's `BUILD FAILURE` summary. You can collect the full error with `mvn clean spring-boot:run 2>&1 | tee startup.log`.

Browser-side playthroughs and a Java gate-service self-test have passed, but a full dependency-resolving Spring Boot Maven build was not run in this environment.
