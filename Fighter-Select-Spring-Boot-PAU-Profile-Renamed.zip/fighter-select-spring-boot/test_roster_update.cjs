const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = fs.existsSync(path.join(__dirname, 'src/main/resources/data/players.json')) ? __dirname : path.join(__dirname, 'fighter-select-spring-boot');
const roster = JSON.parse(fs.readFileSync(path.join(root,'src/main/resources/data/players.json'),'utf8'));
const stories = JSON.parse(fs.readFileSync(path.join(root,'src/main/resources/data/life-stories.json'),'utf8'));
const code = fs.readFileSync(path.join(root,'src/main/resources/static/js/app.js'),'utf8');
assert.deepEqual(roster.map(x => x.id), ['ji','mimi','al','mond']);
assert.deepEqual(stories.map(x => x.playerId), roster.map(x => x.id));
assert.equal(roster[2].accent, '#40D784');
assert.equal(roster[0].title, 'The Kpop Darling ng Tondo Manila');
assert.equal(roster[3].title, 'The Dark One');
assert.equal(roster[3].videos.length, 3);
assert.equal(roster[3].age, '20');
assert.equal(roster[3].birthday, 'July 31, 2006');
assert.equal(roster[3].role, 'IT student');
assert.equal(roster[3].statNotes, undefined);

assert.ok(stories.every(s => Object.keys(s.nodes).length===101));

async function openPage(inputPath, inherited) {
  const page = {innerHTML:'',querySelectorAll(){return []},addEventListener(){}};
  const localStore = new Map(inherited?.entries() || []);
  const storage = {getItem(k){return localStore.get(k) ?? null;},setItem(k,v){localStore.set(k,v);}};
  const location = {origin:'http://localhost:8080',href:'http://localhost:8080'+inputPath,pathname:inputPath.split('?')[0].split('#')[0],search:'',hash:''};
  const history = {replaceState(_a,_b,url){const u = new URL(url,location.origin); location.pathname=u.pathname;location.search=u.search;location.hash=u.hash;location.href=u.href},pushState(_a,_b,url){location.pathname=url;location.href=location.origin+url}};
  const ctx = vm.createContext({
    document:{getElementById(id){return id==='app'?page:null;},title:''},
    window:{addEventListener(){},location,scrollTo(){}},location,history,localStorage:storage,
    fetch:async url=>({ok:true,json:async()=>url==='/api/players'?roster:stories}),
    URL,encodeURIComponent,decodeURIComponent,Math,console, setTimeout
  });
  vm.runInContext(code,ctx);
  await new Promise(resolve=>setTimeout(resolve,15));
  assert.ok(page.innerHTML, 'rendered html');
  assert.doesNotMatch(page.innerHTML,/ROSTER UNAVAILABLE|FIGHTER NOT FOUND/,inputPath);
  return {ctx,page,location,localStore};
}
(async()=>{
  for(const id of ['ji','mond','al']){
    const result = await openPage(`/profile/${id}`);
    assert.match(result.page.innerHTML,new RegExp(`profile-shell player-${id}`));
    assert.match(result.page.innerHTML,new RegExp(`/life/${id}`));
    assert.ok(result.page.innerHTML.includes(id==='ji'?'JAEMAR IBAÑEZ':id==='al'?'Alfrancis Juvir Delos Trino':'Richmond Ebasan'));
    assert.doesNotMatch(result.page.innerHTML,/al-soundtrack-layout/, `${id}: soundtrack should be on a separate Music page`);
    assert.match(result.page.innerHTML,/OPEN SOUNDTRACK/);
    await openPage(`/life/${id}`);
    const music = await openPage(`/profile/${id}/music`);
    assert.match(music.page.innerHTML,/al-soundtrack-layout/, `${id}: Music page should contain soundtrack player`);
    if (id==='mond') assert.doesNotMatch(music.page.innerHTML,/FEATURED MUSIC VIDEOS|mond-featured/);

  }
  const legacyPaths = [
    ['/profile/nova', '/profile/ji'],
    ['/profile/jax/music','/profile/mond/music'],
    ['/profile/jax/hobby/chess','/profile/mond/hobby/chess'],
    ['/life/nova','/life/ji'],
    ['/life/jax','/life/mond'],
    ['/profile/echo','/profile/al']
  ];
  for(const [oldPath,newPath] of legacyPaths){
    const result=await openPage(oldPath);
    assert.equal(result.location.pathname,newPath);
  }
  for(const [id,oldId] of [['ji','nova'],['mond','jax'],['al','echo']]){
    const r=await openPage(`/life/${id}`);
    const save=vm.runInContext(`initialLifeState(playerById('${id}'))`,r.ctx);
    save.playerId=oldId;
    const legacy=new Map([[`fighter-select-life-v3:${oldId}`,JSON.stringify(save)]]);
    const result=await openPage(`/life/${id}`,legacy);
    assert.ok(result.localStore.get(`fighter-select-life-v3:${id}`),`saved migrated for ${id}`);
    const restored=JSON.parse(result.localStore.get(`fighter-select-life-v3:${id}`));
    assert.equal(restored.playerId,id);
  }
  console.log('PASS: Separate Music pages; MOND age/birthday/role and no featured panel/stat descriptions; preserved other profiles, life pages, redirects and save migration.');
})().catch(e=>{console.error(e);process.exitCode=1});
