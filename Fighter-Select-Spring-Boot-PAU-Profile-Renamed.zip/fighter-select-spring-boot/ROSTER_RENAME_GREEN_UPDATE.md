# Green AL and renamed JI/MOND

| Character | Current player ID | Legacy ID | Accent |
|---|---|---|---|
| JI | `ji` | `nova` | Purple (`#9F7AEA`) |
| PAU | `mimi` | — | unchanged |
| AL | `al` | `echo` | **Emerald green (`#40D784`)** / mint (`#BBF7D0`) |
| MOND | `mond` | `jax` | original warm gold (`#FFBE5C`) |

Other features, soundtrack embeds, character details, and Life Mode storyline have not been changed.

### Routes

- `/profile/ji`, `/life/ji`, `/api/players/ji`, `/api/life-stories/ji`
- `/profile/mond`, `/life/mond`, `/api/players/mond`, `/api/life-stories/mond`
- `/profile/al`, `/life/al`

Previous **browser** URLs redirect to the newer IDs. The Java JSON API uses only the new IDs. Local browser saves are migrated to the corresponding new keys while keeping the original saves untouched. Your college-life story itself has not been reset.
