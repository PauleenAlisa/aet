# Roblox: Adopt Me — player photo map

The game cards use each player's Roblox **avatar** screenshot, and the photo panel
on each game detail page uses that player's favorite **pet** screenshot.

| Player | Game-card avatar | Game-detail pet photo |
|---|---|---|
| PAU | `pau-roblox-avatar-20261120.png` (black cat / avatar) | `pau-adoptme-crocodile-20261120-v2.png` (Crocodile) |
| JI | `ji-roblox-avatar-20261120.png` (house / Roblox avatar) | `ji-adoptme-arctic-reindeer-20261120.png` (Arctic Reindeer) |

The images are stored in `src/main/resources/static/assets/`. Their references are
stored as `image` and `detailImage` under each player's `roblox-adopt-me` game
record in `src/main/resources/data/players.json`. The Java `Player.Game` record
includes both fields. Other games and character modules remain unchanged.
