# AL Profile Update — The Only Child

The third fighter now uses ID `al` (formerly `echo`) throughout the running Spring Boot application.

- **Full name:** Alfrancis Juvir Delos Trino
- **Age:** 21
- **Birthday:** July 31, 2005
- **Occupation:** College student in BSIT
- **Title:** The Only Child
- **Motto:** You can't have an easy life and a great character. You only get to choose one.
- Stats, skills, games, hobbies, and fun facts remain exactly as previously provided.
- The Life Journey (18 Milestones) profile section has been removed. The four-year choice-based college game remains unchanged, with graduation as its ending.
- All five soundtrack tracks now have their own verified official YouTube videos. Click **PLAY** beside a song to load and start its video inside the existing soundtrack panel. YouTube controls handle pause/volume and seeking, and each song has a direct YouTube link if embedding is blocked.
- The app does not copy, download, or host copyrighted audio. Working playback requires an internet connection and permission to embed videos.
- Older browser saves using the previous `echo` ID are migrated automatically to `al`. Old profile and life URLs redirect to the new identifier.

## Songs

1. Dilaw — Uhaw (Tayong Lahat): https://www.youtube.com/watch?v=rWF42VRvsLg
2. The Jackson 5 — Who's Lovin' You: https://www.youtube.com/watch?v=hkjWgEj6loc
3. Asin — Masdan Mo Ang Kapaligiran: https://www.youtube.com/watch?v=KqwxE2ySrK0
4. Luther Vandross — Dance with My Father: https://www.youtube.com/watch?v=wmDxJrggie8
5. Eraserheads — Spoliarium: https://www.youtube.com/watch?v=GjysCFxM7Tg

## Running

Run `mvn spring-boot:run` in the project directory, then visit http://localhost:8080/profile/al. Click PLAY THIS LIFE to enter the 1st-to-4th-year college simulation.
