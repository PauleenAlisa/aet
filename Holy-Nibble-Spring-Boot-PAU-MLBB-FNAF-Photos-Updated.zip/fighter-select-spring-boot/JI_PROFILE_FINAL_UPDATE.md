# JI profile update

JI has been updated using the latest supplied details, while preserving the existing Spring Boot layout, purple theme, separate Music module, and eight-semester college-life game.

- Profile: JAEMAR IBAÑEZ; 20; August 3, 2006; Student under IT; The kpop darling ng tondo manila; personality HANGKULITTTT; motto unchanged; roster subtitle Maldita.
- Soundtrack: Gnarly (KATSEYE), FIRESTARTER (K/DA), Hootie Frutti (KATSEYE), POP/STARS (K/DA), MORE (K/DA). All five embed external YouTube videos and have a Watch on YouTube fallback. The spelling “Hootie Frutti” follows the official KATSEYE release.
- Games: MLBB (Mid / Support, Guin Pop), Roblox: Adopt Me (Arctic Reindeer), Honor of Kings (pro players / proof of purchase mentioned without adding an unprovided image), League of Legends (Lux main).
- Stats: Creative 70, Fast Learner 50, Collaboration 64, Communication 80, Honest 90.
- Abilities: Strategy 68, Teamwork 60, Explore 70, PHSYCHO BALL 80, Kili-Kili Power 100.
- Hobbies: Gaming, Dancing, Music, Volleyball, Researching.
- Fun facts: all four supplied.

**Note on counts:** the source notes say max 3 skills/hobbies but provide 5 distinct entries in each. All five are retained so no submitted personal detail is omitted. The same card layout renders additional entries automatically.

## Running
From this directory: `mvn spring-boot:run` then navigate to `http://localhost:8080/profile/ji` or `http://localhost:8080/profile/ji/music`.

YouTube playback requires the internet and permission from the video owner. One cannot verify purchases through a text description; no purchase screenshot was supplied.
