# Separate Soundtrack Module and MOND Profile Update

## Soundtrack pages

The profile pages no longer display a duplicate soundtrack section. Open a character's music by selecting **OPEN SOUNDTRACK** on their profile or **MUSIC** in the top navigation. Routes remain:

- `/profile/ji/music` — JI
- `/profile/mimi/music` — PAU (existing demo tracks)
- `/profile/al/music` — AL
- `/profile/mond/music` — MOND

The five soundtrack songs for JI, AL, and MOND remain selectable through an embedded YouTube player. The separate Mond **Featured Music Videos** panel was removed, but his song list remains. The Music page continues to show favorite genres and artists. Embedded playback requires internet and depends on YouTube permissions.

## MOND player profile

- Age: **20**
- Birthday: **July 31, 2006**
- Occupation: **IT student**
- Percentage stats remain. Their extra text descriptions are no longer displayed on player profiles.

All other profile information and all four college-life games are unchanged.

## Run

```bash
mvn spring-boot:run
```

Open `http://localhost:8080`. Test the Java application with `mvn test` if Maven is installed.
