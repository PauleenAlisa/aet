# Real photo sources for games and hobbies

This version replaces the earlier AI-generated gallery panels with **real photography from Unsplash**.
Images are linked from the original Unsplash CDN so **internet access is required** for new game and hobby pictures.
The images are thematic illustrations, **not screenshots of the actual named games**. They do not imply sponsorship or endorsement.
Original user-uploaded profile photos and the two characters' Roblox/Adopt Me screenshots remain bundled locally and unchanged.

All external photographs are listed as free to use under the [Unsplash License](https://unsplash.com/license).

| Usage | Photographer | Source photo |
| --- | --- | --- |
| anime | Branden Skeli | [Real Pokémon-themed Nintendo Switch setup](https://unsplash.com/photos/a-game-controller-and-a-game-controller-L4Sa-fVWvSg) |
| badminton | Luthfi Ali Qodri | [Badminton player on a court](https://www.pexels.com/photo/badminton-player-on-a-court-8796050/) |
| basketball | Azim Ronnie | [Actual basketball players on a court](https://unsplash.com/photos/people-playing-basketball-on-court-euFYX7Zg2lM/) |
| beads | engin akyurt | [Close up of colorful beads and bracelets](https://unsplash.com/photos/a-close-up-of-a-bunch-of-beads-wWb2leISpmI) |
| bowling | Pavel Danilyuk | [A bowler in a bowling alley](https://www.pexels.com/photo/a-bowler-in-a-bowling-alley-7429506/) |
| chess | Gustavo Alejandro Espinosa Reyes | [Two people playing chess](https://unsplash.com/photos/two-people-playing-chess-on-a-table-hFQ7q9UM74w) |
| content | Branden Skeli | [Gaming screens / content creation setup](https://unsplash.com/photos/gamers-setup-with-multiple-monitors-and-rgb-lighting-zHzRrYV_Ars) |
| crochet | Barney Goodman | [Person crocheting yarn](https://unsplash.com/photos/person-crocheting-with-multicolored-yarn-T-HlYDchDE8) |
| dance | Daria Trofimova | [People dancing](https://unsplash.com/photos/a-group-of-people-dancing-amZs91uOEHU) |
| esports | Branden Skeli | [Real multi-monitor competitive gaming setup](https://unsplash.com/photos/gamers-setup-with-multiple-monitors-and-rgb-lighting-zHzRrYV_Ars) |
| gaming | Branden Skeli | [Real gaming setup with controller](https://unsplash.com/photos/a-person-holding-a-cup-and-a-game-controller-in-front-of-a-television-L0Razurc1Og) |
| music | Viktor Forgacs | [Headphones on piano in music studio](https://unsplash.com/photos/headphones-on-piano-keyboard-in-studio-H6YkQEnD5Gk) |
| origami | Lia Schmidt | [Origami birds hanging from strings](https://unsplash.com/photos/a-group-of-origami-birds-hanging-from-strings-omibpE1ngXA) |
| painting | Christopher Stites | [Real watercolor painting supplies and hand](https://unsplash.com/photos/watercolor-painting-on-wooden-table-IRtYiIuadf8) |
| reading | Jadon Johnson | [Reading a book among shelves](https://unsplash.com/photos/young-woman-sits-among-bookshelves-with-open-book-3JyMYkbOFTg) |
| research | Jadon Johnson | [Reading and researching books](https://unsplash.com/photos/young-woman-sits-among-bookshelves-with-open-book-3JyMYkbOFTg) |
| soccer | Leo_Visions | [Soccer ball on grass](https://unsplash.com/photos/a-soccer-ball-sits-on-a-green-field-RV5I1lGcspU) |
| swimming | Serena Repice Lentini | [Person swimming in pool](https://unsplash.com/photos/person-swimming-on-pool-LTLBUvs4UdQ) |
| volleyball | Steven Abraham | [Real volleyball match](https://unsplash.com/photos/people-playing-volleyball-EDXhKsNQDRU) |
| youtube | Branden Skeli | [Person with a controller and TV](https://unsplash.com/photos/a-person-holding-a-cup-and-a-game-controller-in-front-of-a-television-L0Razurc1Og) |

To substitute your own photo later, edit `src/main/resources/static/js/app.js` (`realHobbyPhotos`) or game image URLs in `src/main/resources/data/players.json`.
If an image cannot load because of a network restriction, the existing themed card remains but the image may be unavailable.
