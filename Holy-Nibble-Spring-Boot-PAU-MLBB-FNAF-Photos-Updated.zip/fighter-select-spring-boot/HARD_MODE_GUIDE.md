# AGREEEEE! Hard Mode — 10 randomized challenges

The **START** button now leads to ten randomly chosen challenges from a 15-challenge pool, shuffled for each new visitor session or after clicking **RESHUFFLE FROM ZERO**. These are comic, made-up terms and **not** legal consent.

Harder mechanics include:

- Triple-click rapidly (three clicks within 560 ms of one another)
- Hold a button for 2.6 seconds without releasing
- Catch a moving button six times (the first two cursor approaches can dodge)
- Ignore the large green Agree and use Disagree instead
- Check precisely two out of five checkboxes
- Type a case-sensitive phrase including punctuation
- Land a slider on an exact randomized percentage
- Enter a randomly ordered five-number sequence
- Wait 5.5 seconds before a button unlocks
- Find the only `AGREE!` among eleven `AGREE.` buttons
- Solve a multiplication-plus-three problem
- Memorize a short code before it vanishes
- Scroll all the way down a long terms box
- Flip exactly two of five switches
- Perform a four-button Agree/Disagree ritual

You can always interact with the page using keyboard or mouse/touch; some controls provide instructions on how. The 10 terms are selected from the 15 challenges without duplicates per run.

The **admin login / bypass / disable-for-everyone** configuration is unchanged. Set `AGREE_ADMIN_PASSWORD` on the Spring Boot server before starting; there is no default password. The global setting persists in `config/agree-gate.properties`.

## Run on Mac

From the project folder containing `pom.xml`:

```bash
cd ~/Downloads/fighter-select-spring-boot
bash run-mac.sh
```

Or set an admin password in the current terminal and run:

```bash
export AGREE_ADMIN_PASSWORD='YOUR_OWN_PRIVATE_STRONG_PASSWORD'
mvn clean spring-boot:run
```

If Spring Boot fails during startup, share the `Caused by:` lines **above** the Maven BUILD FAILURE banner. The final `Process terminated with exit code: 1` line alone does not reveal the cause.
