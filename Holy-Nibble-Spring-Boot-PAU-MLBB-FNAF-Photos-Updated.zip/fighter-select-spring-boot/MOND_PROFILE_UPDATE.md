# MOND — The Dark One profile update

The fourth fighter now uses internal ID `mond` instead of `jax`, with save migration and older bookmark redirects. The visible name is `MOND`. No new Life Journey milestones were added.

- **Motto:** Keep Moving Forward. (With the supplied reflection.)
- **Music:** Bagsakan, Raining in Manila, Beer, Titibo-tibo, 711.
- **Featured videos:** Lola Amour official music video, Moira Dela Torre official music video, TONEEJAY official lyric video.
- **Games:** Mobile Legends: Bang Bang (Gold Lane), Pokémon Champions (Pokémon Trainer).
- **Stats and descriptions:** Determination 90, Adaptability 85, Problem-Solving 85, Teamwork 80, Creativity 80.
- **Skills:** Communication 80, Time Management 75, Attention to Detail 85.
- **Hobbies:** Chess (including two quotes from father), mobile gaming, listening to OPM.
- **Fun facts:** Six supplied facts.
- **Legal name:** From the original site footer (`Richmond Ebasan`). **Age and birthday:** Not provided, so left unspecified.

Music links used by the soundtrack embed (media remains hosted by YouTube):

1. Bagsakan — https://www.youtube.com/watch?v=rbKxoz1ZfiM
2. Raining in Manila — https://www.youtube.com/watch?v=pur5iB-xuIQ
3. Beer — https://www.youtube.com/watch?v=Gw6NMsqBQcw
4. Titibo-tibo — https://www.youtube.com/watch?v=Cp_7VA7076I
5. 711 (official lyric video) — https://www.youtube.com/watch?v=9RJ-oc7cvW0

The soundtrack play buttons request autoplay after a deliberate click; YouTube may disallow autoplay or embedding, in which case users can open the original video in a new tab.

Run with JDK 17+ and Maven:

```sh
mvn spring-boot:run
```

Then visit `http://localhost:8080/profile/mond`.
