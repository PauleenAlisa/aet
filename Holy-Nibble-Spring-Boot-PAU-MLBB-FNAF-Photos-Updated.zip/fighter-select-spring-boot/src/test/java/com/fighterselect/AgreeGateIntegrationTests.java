package com.fighterselect;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(properties = {
        "agree.admin.password=TestStrongPasswordOnly",
        "agree.gate.initial-enabled=true",
        "agree.gate.state-file="
})
@AutoConfigureMockMvc
class AgreeGateIntegrationTests {
    @Autowired MockMvc mvc;
    @Autowired ObjectMapper json;

    @Test
    void tenRandomizedAgreementsAreRequiredBeforePlayerDataCanLoad() throws Exception {
        MockHttpSession visitor = new MockHttpSession();
        mvc.perform(get("/api/players").session(visitor)).andExpect(status().isForbidden());
        JsonNode status = parse(mvc.perform(get("/api/gate/status").session(visitor))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString());
        assertEquals(0, status.get("completedSteps").asInt());
        Set<String> modes = new HashSet<>();
        for (int n = 0; n < 10; n++) {
            JsonNode challenge = status.get("challenge");
            assertNotNull(challenge);
            String mode = challenge.get("mode").asText();
            modes.add(mode);
            String proof = switch (mode) {
                case "double" -> "septuple";
                case "hold" -> "held";
                case "chase" -> "caught";
                case "reverse" -> "reverse";
                case "checks" -> "010010010";
                case "type" -> challenge.get("config").get("phrase").asText();
                case "sequence" -> StreamSupport.stream(challenge.get("config").get("sequence").spliterator(), false)
                        .map(JsonNode::asText).collect(Collectors.joining("-"));
                case "timer" -> "waited";
                case "target" -> "slot-" + challenge.get("config").get("correctSlot").asText();
                case "math" -> String.valueOf(challenge.get("config").get("a").asInt()
                        * challenge.get("config").get("b").asInt()
                        + challenge.get("config").get("c").asInt() * challenge.get("config").get("d").asInt()
                        - challenge.get("config").get("minus").asInt());
                case "memory" -> challenge.get("config").get("code").asText();
                case "scroll" -> "scrolled";
                case "switches" -> "101001001";
                case "combo" -> "combo";
                case "tapcount" -> challenge.get("config").get("count").asText();
                case "captcha" -> String.valueOf(StreamSupport.stream(challenge.get("config").get("icons").spliterator(), false)
                        .filter(icon -> "🍎".equals(icon.asText())).count());
                case "arrows" -> StreamSupport.stream(challenge.get("config").get("arrows").spliterator(), false)
                        .map(JsonNode::asText).collect(Collectors.joining());
                case "mirror" -> new StringBuilder(challenge.get("config").get("phrase").asText()).reverse().toString();
                default -> throw new AssertionError("Unknown hard-mode challenge: " + mode);
            };
            if (mode.equals("timer")) Thread.sleep(12300L);
            status = parse(mvc.perform(post("/api/gate/agree").session(visitor)
                            .contentType("application/json")
                            .content(json.writeValueAsBytes(Map.of("challengeId", challenge.get("id").asText(), "proof", proof))))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString());
            assertEquals(n + 1, status.get("completedSteps").asInt());
        }
        assertEquals(10, modes.size());
        assertTrue(status.get("accessGranted").asBoolean());
        mvc.perform(get("/api/players").session(visitor)).andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(4));
        mvc.perform(get("/api/players").session(new MockHttpSession())).andExpect(status().isForbidden());
    }

    @Test
    void adminRequiresPasswordAndCanToggleGateForEveryone() throws Exception {
        MockHttpSession admin = new MockHttpSession();
        mvc.perform(post("/api/gate/admin/toggle").session(admin)
                .contentType("application/json").content("{\"enabled\":false}"))
                .andExpect(status().isForbidden());
        mvc.perform(post("/api/gate/admin/login").session(admin)
                .contentType("application/json").content("{\"password\":\"incorrect\"}"))
                .andExpect(status().isUnauthorized());
        mvc.perform(post("/api/gate/admin/login").session(admin)
                .contentType("application/json").content("{\"password\":\"TestStrongPasswordOnly\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.adminAuthenticated").value(true))
                .andExpect(jsonPath("$.accessGranted").value(true));
        mvc.perform(post("/api/gate/admin/toggle").session(admin)
                .contentType("application/json").content("{\"enabled\":false}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.enabled").value(false));
        mvc.perform(get("/api/players").session(new MockHttpSession())).andExpect(status().isOk());
        mvc.perform(post("/api/gate/admin/toggle").session(admin)
                .contentType("application/json").content("{\"enabled\":true}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.enabled").value(true));
        mvc.perform(get("/api/players").session(new MockHttpSession())).andExpect(status().isForbidden());
        mvc.perform(post("/api/gate/admin/logout").session(admin).contentType("application/json").content("{}"))
                .andExpect(status().isOk());
    }


    @Test
    void threeStrikesEraseTheEntireRunAndRandomizeAgain() throws Exception {
        MockHttpSession visitor = new MockHttpSession();
        JsonNode initial = parse(mvc.perform(get("/api/gate/status").session(visitor))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString());
        assertEquals(0, initial.get("strikes").asInt());
        String firstId = initial.get("challenge").get("id").asText();
        for (int strike = 1; strike <= 2; strike++) {
            initial = parse(mvc.perform(post("/api/gate/mistake").session(visitor)
                    .contentType("application/json").content("{}"))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString());
            assertEquals(strike, initial.get("strikes").asInt());
            assertEquals(firstId, initial.get("challenge").get("id").asText());
        }
        JsonNode reset = parse(mvc.perform(post("/api/gate/mistake").session(visitor)
                .contentType("application/json").content("{}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString());
        assertEquals(0, reset.get("strikes").asInt());
        assertEquals(0, reset.get("completedSteps").asInt());
        assertNotEquals(firstId, reset.get("challenge").get("id").asText());
    }

    private JsonNode parse(String body) throws Exception {return json.readTree(body);}
}
