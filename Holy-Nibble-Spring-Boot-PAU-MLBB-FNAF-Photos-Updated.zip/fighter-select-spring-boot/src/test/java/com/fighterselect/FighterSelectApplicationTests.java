package com.fighterselect;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(properties = {"agree.gate.initial-enabled=false", "agree.gate.state-file="})
@AutoConfigureMockMvc
class FighterSelectApplicationTests {
    @Autowired MockMvc mvc;

    @Test
    void listsFourRenamedPlayers() throws Exception {
        mvc.perform(get("/api/players"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(4))
                .andExpect(jsonPath("$[0].id").value("ji"))
                .andExpect(jsonPath("$[1].id").value("pau"))
                .andExpect(jsonPath("$[2].id").value("al"))
                .andExpect(jsonPath("$[3].id").value("mond"));
    }

    @Test
    void playerDetailAndNotFound() throws Exception {
        mvc.perform(get("/api/players/al"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.fighterId").value("FTR-003"))
                .andExpect(jsonPath("$.hobbies.length()").value(4));
        mvc.perform(get("/api/players/echo"))
                .andExpect(status().isNotFound());
        mvc.perform(get("/api/players/unknown"))
                .andExpect(status().isNotFound());
    }

    @Test
    void alProfileContainsPersonalizedSoundtrackAndVideo() throws Exception {
        mvc.perform(get("/api/players/al"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nickname").value("AL"))
                .andExpect(jsonPath("$.age").value("21"))
                .andExpect(jsonPath("$.birthday").value("July 31, 2005"))
                .andExpect(jsonPath("$.role").value("IT Student"))
                .andExpect(jsonPath("$.title").value("The Only Child"))
                .andExpect(jsonPath("$.stats['Discipline and Consistency']").value(94))
                .andExpect(jsonPath("$.stats['Clutch Adaptability']").value(88))
                .andExpect(jsonPath("$.tracks.length()").value(5))
                .andExpect(jsonPath("$.tracks[0].title").value("Uhaw"))
                .andExpect(jsonPath("$.tracks[4].title").value("Spoliarium"))
                .andExpect(jsonPath("$.videos[0].id").value("rWF42VRvsLg"))
                .andExpect(jsonPath("$.tracks[0].videoId").value("rWF42VRvsLg"))
                .andExpect(jsonPath("$.tracks[1].videoId").value("hkjWgEj6loc"))
                .andExpect(jsonPath("$.tracks[2].videoId").value("KqwxE2ySrK0"))
                .andExpect(jsonPath("$.tracks[3].videoId").value("wmDxJrggie8"))
                .andExpect(jsonPath("$.tracks[4].videoId").value("GjysCFxM7Tg"))
                .andExpect(jsonPath("$.games.length()").value(5))
                .andExpect(jsonPath("$.funFacts.length()").value(4))
                .andExpect(jsonPath("$.abilities.length()").value(4));
    }

    @Test
    void mondProfileIncludesAllRequestedFieldsAndMusicVideos() throws Exception {
        mvc.perform(get("/api/players/mond"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nickname").value("MOND"))
                .andExpect(jsonPath("$.title").value("The Dark One"))
                .andExpect(jsonPath("$.quote").value("Keep Moving Forward."))
                .andExpect(jsonPath("$.age").value("20"))
                .andExpect(jsonPath("$.birthday").value("July 31, 2006"))
                .andExpect(jsonPath("$.role").value("IT student"))
                .andExpect(jsonPath("$.statNotes").doesNotExist())
                .andExpect(jsonPath("$.stats.Determination").value(90))
                .andExpect(jsonPath("$.stats.Adaptability").value(85))
                .andExpect(jsonPath("$.stats['Problem-Solving']").value(85))
                .andExpect(jsonPath("$.abilities.length()").value(3))
                .andExpect(jsonPath("$.abilities[0].level").value(80))
                .andExpect(jsonPath("$.abilities[1].level").value(75))
                .andExpect(jsonPath("$.abilities[2].level").value(85))
                .andExpect(jsonPath("$.hobbies[0].name").value("Chess"))
                .andExpect(jsonPath("$.tracks.length()").value(5))
                .andExpect(jsonPath("$.tracks[0].title").value("Bagsakan"))
                .andExpect(jsonPath("$.videos.length()").value(3))
                .andExpect(jsonPath("$.videos[0].id").value("pur5iB-xuIQ"))
                .andExpect(jsonPath("$.videos[1].id").value("Cp_7VA7076I"))
                .andExpect(jsonPath("$.videos[2].id").value("9RJ-oc7cvW0"))
                .andExpect(jsonPath("$.games.length()").value(2))
                .andExpect(jsonPath("$.games[0].role").value("Gold Lane"))
                .andExpect(jsonPath("$.games[1].role").value("Pokémon Trainer"))
                .andExpect(jsonPath("$.funFacts.length()").value(5));
    }

    @Test
    void renamesJiAndMondAndUsesGreenForAl() throws Exception {
        mvc.perform(get("/api/players/ji"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nickname").value("JI"))
                .andExpect(jsonPath("$.name").value("JAEMAR IBAÑEZ"));
        mvc.perform(get("/api/players/mond"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nickname").value("MOND"))
                .andExpect(jsonPath("$.title").value("The Dark One"));
        mvc.perform(get("/api/players/al"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.accent").value("#40D784"))
                .andExpect(jsonPath("$.accent2").value("#BBF7D0"))
                .andExpect(jsonPath("$.rgb").value("64,215,132"));
        mvc.perform(get("/api/players/nova")).andExpect(status().isNotFound());
        mvc.perform(get("/api/players/jax")).andExpect(status().isNotFound());
    }

    @Test
    void jiProfileIncludesUpdatedPersonalDataMusicGamesAndAbilities() throws Exception {
        mvc.perform(get("/api/players/ji"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("JAEMAR IBAÑEZ"))
                .andExpect(jsonPath("$.nickname").value("JI"))
                .andExpect(jsonPath("$.age").value("20"))
                .andExpect(jsonPath("$.birthday").value("August 3, 2006"))
                .andExpect(jsonPath("$.role").value("IT Student"))
                .andExpect(jsonPath("$.personality").value("HANGKULITTTT"))
                .andExpect(jsonPath("$.title").value("The kpop darling ng tondo manila"))
                .andExpect(jsonPath("$.accent").value("#9F7AEA"))
                .andExpect(jsonPath("$.stats.Creative").value(70))
                .andExpect(jsonPath("$.stats['Fast Learner']").value(50))
                .andExpect(jsonPath("$.abilities.length()").value(5))
                .andExpect(jsonPath("$.abilities[3].level").value(80))
                .andExpect(jsonPath("$.abilities[4].level").value(100))
                .andExpect(jsonPath("$.hobbies.length()").value(5))
                .andExpect(jsonPath("$.games.length()").value(4))
                .andExpect(jsonPath("$.games[1].role").value("Favorite pet: Arctic Reindeer"))
                .andExpect(jsonPath("$.games[3].role").value("Lux main"))
                .andExpect(jsonPath("$.tracks.length()").value(5))
                .andExpect(jsonPath("$.tracks[1].title").value("FIRESTARTER"))
                .andExpect(jsonPath("$.tracks[1].videoId").value("Mmw-PpWhKFg"))
                .andExpect(jsonPath("$.tracks[2].title").value("Hootie Frutti"))
                .andExpect(jsonPath("$.funFacts.length()").value(4));
    }

    @Test
    void pauProfileShowsNewDetailsAndPreviousIdIsNoLongerAnApiPlayer() throws Exception {
        mvc.perform(get("/api/players/pau"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Pauleen Alisa Amatorio"))
                .andExpect(jsonPath("$.nickname").value("PAU"))
                .andExpect(jsonPath("$.age").value("20"))
                .andExpect(jsonPath("$.birthday").value("December 19, 2005"))
                .andExpect(jsonPath("$.role").value("IT Student"))
                .andExpect(jsonPath("$.title").value("Une touche-à-tout"))
                .andExpect(jsonPath("$.accent").value("#F05A69"))
                .andExpect(jsonPath("$.stats.Curiosity").value(99))
                .andExpect(jsonPath("$.tracks.length()").value(5))
                .andExpect(jsonPath("$.tracks[0].title").value("You’re Under Arrest"))
                .andExpect(jsonPath("$.videos[0].id").value("jOTfBlKSQYY"))
                .andExpect(jsonPath("$.games.length()").value(3))
                .andExpect(jsonPath("$.games[1].role").value("Favorite pet: Crocodile · 1,655 hours played"))
                .andExpect(jsonPath("$.abilities.length()").value(6))
                .andExpect(jsonPath("$.hobbies.length()").value(6))
                .andExpect(jsonPath("$.funFacts.length()").value(5));
        mvc.perform(get("/api/players/mimi")).andExpect(status().isNotFound());
    }

    @Test
    void mondPhotoAssetsAreBundledAndAlIsAnItStudent() throws Exception {
        mvc.perform(get("/api/players/mond"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.portrait").value("/assets/mond-main-restored.jpg"))
                .andExpect(jsonPath("$.hoverPortrait").value("/assets/mond-hover-upright-restored.jpg"));
        mvc.perform(get("/assets/mond-main-restored.jpg")).andExpect(status().isOk());
        mvc.perform(get("/assets/mond-hover-upright-restored.jpg")).andExpect(status().isOk());
        mvc.perform(get("/api/players/al"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.role").value("IT Student"));
    }

    @Test
    void usesAccurateGameFactLabelsInsteadOfGenericRoles() throws Exception {
        mvc.perform(get("/api/players/ji"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.games[1].details[0].label").value("Favorite Pet"))
                .andExpect(jsonPath("$.games[1].details[0].value").value("Arctic Reindeer"));
        mvc.perform(get("/api/players/pau"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.games[1].details[0].label").value("Favorite Pet"))
                .andExpect(jsonPath("$.games[1].details[0].value").value("Crocodile"))
                .andExpect(jsonPath("$.games[1].details[1].label").value("Hours Played"))
                .andExpect(jsonPath("$.games[1].details[1].value").value("1,655"))
                .andExpect(jsonPath("$.games[2].details[0].label").value("Favorite Character"))
                .andExpect(jsonPath("$.games[2].details[0].value").value("Mangle"))
                .andExpect(jsonPath("$.games[2].details[1].label").value("Favorite Title"))
                .andExpect(jsonPath("$.games[2].details[1].value").value("VR: Help Wanted"));
    }

    @Test
    void supportsDeepLinksToPages() throws Exception {
        mvc.perform(get("/select")).andExpect(status().isOk())
                .andExpect(forwardedUrl("/index.html"));
        mvc.perform(get("/profile/al")).andExpect(status().isOk())
                .andExpect(forwardedUrl("/index.html"));
        mvc.perform(get("/profile/al/music")).andExpect(status().isOk())
                .andExpect(forwardedUrl("/index.html"));
        mvc.perform(get("/profile/ji/music")).andExpect(status().isOk())
                .andExpect(forwardedUrl("/index.html"));
        mvc.perform(get("/profile/pau")).andExpect(status().isOk())
                .andExpect(forwardedUrl("/index.html"));
        mvc.perform(get("/profile/pau/music")).andExpect(status().isOk())
                .andExpect(forwardedUrl("/index.html"));
        // Legacy browser route is caught and rewritten to /profile/pau by JS.
        mvc.perform(get("/profile/mimi/music")).andExpect(status().isOk())
                .andExpect(forwardedUrl("/index.html"));
    }

    @Test
    void removedLifeStoryRoutesAreNotAvailable() throws Exception {
        mvc.perform(get("/api/life-stories")).andExpect(status().isNotFound());
        mvc.perform(get("/api/life-stories/ji")).andExpect(status().isNotFound());
        mvc.perform(get("/life/ji")).andExpect(status().isNotFound());
    }

    @Test
    void alSkillsExposeMasteryPercentages() throws Exception {
        mvc.perform(get("/api/players/al"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.abilities[0].level").value(93))
                .andExpect(jsonPath("$.abilities[1].level").value(89))
                .andExpect(jsonPath("$.abilities[2].level").value(90))
                .andExpect(jsonPath("$.abilities[3].level").value(74));
    }

}
