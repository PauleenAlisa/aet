package com.fighterselect.model;

import java.util.List;
import java.util.Map;

/** JSON schema mirrors the original React project's src/data.ts player records. */
public record Player(
        String id,
        String number,
        String fighterId,
        String name,
        String nickname,
        String age,
        String birthday,
        String role,
        String title,
        String personality,
        String intro,
        String quote,
        String quoteMeaning,
        String portrait,
        String hoverPortrait,
        String photoCredit,
        String accent,
        String accent2,
        String rgb,
        Map<String, Integer> stats,
        List<Ability> abilities,
        List<Hobby> hobbies,
        List<String> artists,
        List<String> genres,
        List<Track> tracks,
        List<Video> videos,
        List<Game> games,
        List<String> funFacts
) {
    public record Ability(String kind, String name, String description, Integer level) {}
    public record Hobby(String slug, String name, String kicker, String description, List<String> items) {}
    public record Track(String title, String artist, String src, String videoId) {}
    public record Video(String id, String title, String artist, String description) {}
    public record Game(String slug, String title, String category, String platform,
                       String role, String description, String cover, String videoId,
                       List<GameDetail> details, String image, String detailImage) {}
    public record GameDetail(String label, String value) {}
}
