package com.fighterselect.gate;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/gate")
public class AgreeGateController {
    private final AgreeGateService gate;

    public AgreeGateController(AgreeGateService gate) { this.gate = gate; }

    public record AgreeRequest(String challengeId, String proof) {}
    public record LoginRequest(String password) {}
    public record ToggleRequest(boolean enabled) {}

    @GetMapping("/status")
    public Map<String, Object> status(HttpSession session) { return gate.status(session); }

    @PostMapping("/agree")
    public Map<String, Object> agree(HttpSession session, @RequestBody AgreeRequest body) {
        return gate.agree(session, body.challengeId(), body.proof());
    }

    @PostMapping("/mistake")
    public Map<String, Object> mistake(HttpSession session) { return gate.mistake(session); }

    @PostMapping("/restart")
    public Map<String, Object> restart(HttpSession session) { return gate.restart(session); }

    @PostMapping("/admin/login")
    public Map<String, Object> login(HttpSession session, @RequestBody LoginRequest body) {
        return gate.login(session, body.password());
    }

    @PostMapping("/admin/toggle")
    public Map<String, Object> toggle(HttpSession session, @RequestBody ToggleRequest body) {
        return gate.setEnabled(session, body.enabled());
    }

    @PostMapping("/admin/logout")
    public Map<String, Object> logout(HttpServletRequest request) {
        return gate.logout(request.getSession());
    }
}
