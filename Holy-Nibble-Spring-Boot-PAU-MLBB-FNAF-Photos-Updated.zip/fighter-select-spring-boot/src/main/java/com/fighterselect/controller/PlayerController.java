package com.fighterselect.controller;

import com.fighterselect.model.Player;
import com.fighterselect.gate.AgreeGateService;
import jakarta.servlet.http.HttpSession;
import com.fighterselect.service.PlayerService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class PlayerController {
    private final PlayerService service;
    private final AgreeGateService gate;

    public PlayerController(PlayerService service, AgreeGateService gate) {
        this.service = service;
        this.gate = gate;
    }

    @GetMapping("/players")
    public List<Player> players(HttpSession session) {
        gate.requireAccess(session);
        return service.findAll();
    }

    @GetMapping("/players/{id}")
    public Player player(@PathVariable String id, HttpSession session) {
        gate.requireAccess(session);
        return service.findById(id);
    }

    @GetMapping("/health")
    public Map<String, Object> health() {
        return Map.of("status", "UP", "fighterCount", service.findAll().size());
    }
}
