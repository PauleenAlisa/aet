package com.fighterselect.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fighterselect.model.Player;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Service
public class PlayerService {
    private final List<Player> players;

    public PlayerService(ObjectMapper mapper) throws IOException {
        try (InputStream in = new ClassPathResource("data/players.json").getInputStream()) {
            this.players = List.copyOf(mapper.readValue(in, new TypeReference<List<Player>>() {}));
        }
    }

    public List<Player> findAll() {
        return players;
    }

    public Player findById(String id) {
        return players.stream()
                .filter(player -> player.id().equals(id))
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Fighter not found: " + id));
    }
}
