package com.fighterselect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FighterSelectApplication {
    public static void main(String[] args) {
        SpringApplication.run(FighterSelectApplication.class, args);
    }
}
