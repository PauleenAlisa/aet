# Current fighter roster and profile URLs

| Character | Current player ID | Legacy ID | Accent |
|---|---|---|---|
| JI | `ji` | `nova` | Purple (`#9F7AEA`) |
| PAU | `pau` | `mimi` | Red (`#F05A69`) |
| AL | `al` | `echo` | Emerald green (`#40D784`) |
| MOND | `mond` | `jax` | Warm gold (`#FFBE5C`) |

Current pages are `/profile/ji`, `/profile/pau`, `/profile/al` and `/profile/mond`.
The old player IDs remain supported for profile bookmarks only through browser redirects.

This edition includes the character profiles, separate soundtracks, favorite games, hobby modules, and group roster. The earlier interactive college Life Stories feature has been removed.
