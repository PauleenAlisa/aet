# Holy Nibble — harder chase mini-game

- Intro brand changed to **HOLY NIBBLE**.
- Pre-roster gate now says **Unlock the Roster** and describes JI, PAU, AL, and MOND.
- Removed the TERMS.EXE header, the PARODY GAME footer label, and the Reshuffle From Zero button, and the requested 2/5/8 checkbox puzzle. The small gear icon still opens the password-protected admin panel.
- Chase game: **30 catches**, first 10 pointer approaches can dodge, target shrinks after 8/15/24 catches, starts automatically relocating after 6 catches (every 1.1 seconds, then 0.65 seconds and finally 0.37 seconds). Three wrong answers in the overall challenge still reset progress.
- Reduced-motion users can play without the continuous movement.
- Spring Boot backend still chooses 10 of the available challenge types.
- Run: `bash run-mac.sh` from the project folder (requires Maven and JDK 17+).
- Full Maven startup must be tested on your machine.

## Fix: chase stuck at 24/30 (2026-11-21)

- At the smallest, fastest stage the moving button could move between mouse-down and mouse-up. The browser would then drop the `click`, making progress appear stuck at 24 catches.
- The chase now counts **one catch on pointer-down**, preventing dropped clicks while keeping the 30-catch requirement and difficult movement.
- Normal follow-up click events are ignored to prevent counting one press twice; keyboard/assistive-tech clicks still count once.
- Failed final network submissions can be retried instead of locking the counter at 30/30.
- Verified with Chromium mouse actions from 24 through 30, 30 keyboard catches, and a double-count check.
