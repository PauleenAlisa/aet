#!/usr/bin/env bash
# Local Spring Boot launcher for macOS/Linux (requires Maven and Java 17+).
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v mvn >/dev/null 2>&1; then
  echo "Apache Maven is missing. Install it first (on Mac: brew install maven),"
  echo "or download Maven directly from https://maven.apache.org/download.cgi"
  echo "Then verify with: mvn -version"
  exit 1
fi

if [[ -z "${AGREE_ADMIN_PASSWORD:-}" ]]; then
  printf 'Choose admin password for this run (or press Enter to disable admin access): '
  IFS= read -r -s AGREE_ADMIN_PASSWORD
  printf '\n'
  export AGREE_ADMIN_PASSWORD
fi

exec mvn clean spring-boot:run
