/*
 * Spring Boot edition of the four-player fighter select application.
 * The Java backend owns the roster (GET /api/players). This browser-side file
 * replaces React's rendering/router with standard, dependency-free JavaScript.
 */
'use strict';

const app = document.getElementById('app');
const selectNames = { nova: 'JI', mimi: 'PAU', echo: 'AL', jax: 'MOND' };
const selectTitles = { nova: 'Sunoo', mimi: 'Alisa', echo: 'Juvir', jax: 'Dekaizer' };
const localNovaPose = '/assets/763925829_1039672735429831_7750910218737029479_n.jpg';
const localNovaHover = '/assets/5009b66c-6554-4adc-8bf4-c701f24f4834.jpg';
const memoryTitles = ['How the squad formed', 'The story everyone retells', 'Favorite group activity', 'Next adventure'];
const lifeStatNames = ['Happiness', 'Energy', 'Smarts', 'Confidence', 'Social'];
let players = [];
let lifeStories = [];
let selectedId = null;
let hoveredId = 'nova';
let lifeState = null;
let musicState = null;
let muted = true;

const e = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[ch]));
const enc = encodeURIComponent;
const palette = p => `--accent:${e(p.accent)};--accent-2:${e(p.accent2)};--accent-rgb:${e(p.rgb)}`;
const icon = name => `<span class="icon icon--${e(name)}" aria-hidden="true">${({arrow:'→',sound:')))',mute:'×',play:'▶',pause:'Ⅱ',next:'▶|',back:'←',spark:'✦'})[name] ?? ''}</span>`;
const purl = p => `/profile/${enc(p.id)}`;
const ambient = (accent = '') => `<div aria-hidden="true" class="ambient ${accent ? `ambient--${e(accent)}` : ''}"><div class="grid-floor"></div><div class="orb orb--one"></div><div class="orb orb--two"></div><div class="noise"></div></div>`;
const linkButton = (url, label, variant = 'primary') => `<a class="button button--${variant}" href="${e(url)}">${label}</a>`;
const btn = (label, action, variant = 'primary', disabled = false) => `<button class="button button--${variant}" type="button" data-action="${e(action)}"${disabled ? ' disabled' : ''}>${label}</button>`;
const playerById = id => players.find(p => p.id === id);
const sectionHead = (index, kicker, title) => `<div class="section-head"><span>${e(index)}</span><div><small>${e(kicker)}</small><div class="section-title">${e(title)}</div></div><i></i></div>`;
const portrait = (p, {interactive = false, hero = false, local = false} = {}) => {
  const src = local && p.id === 'nova' ? localNovaPose : p.portrait;
  const hover = local && p.id === 'nova' ? localNovaHover : p.hoverPortrait;
  return `<div class="portrait ${interactive ? 'portrait--interactive' : ''} ${hero ? 'portrait--hero' : ''}">
    <img class="portrait__pose portrait__pose--base" alt="${e(p.nickname)} portrait" src="${e(src)}" loading="lazy">
    ${interactive ? `<img class="portrait__pose portrait__pose--hover" alt="" aria-hidden="true" src="${e(hover)}" loading="lazy">` : ''}
    <div class="portrait__fallback" hidden>${e(p.nickname.slice(0,1))}</div><div class="portrait__scan"></div>
  </div>`;
};
const navHeader = (label, subtitle) => `<header class="select__header"><a href="/select" class="mini-brand">FIGHTER <b>${e(label)}</b></a><div class="round-label">${e(subtitle)}</div></header>`;
const pageFrame = (p, inner) => `<main class="profile-shell player-${e(p.id)}" style="${palette(p)}">${ambient()}
  <header class="profile-nav"><a class="mini-brand" href="/select">FIGHTER <b>SELECT</b></a>
  <nav aria-label="Profile navigation"><a href="${purl(p)}">PROFILE</a><a href="/life/${enc(p.id)}">PLAY LIFE</a><a href="${purl(p)}/music">MUSIC</a><a href="${purl(p)}/games">GAMES</a><a href="/select">ROSTER</a></nav></header>
  ${inner}</main>`;
const back = (url, label) => `<a class="back-link" href="${e(url)}">${icon('back')} ${e(label)}</a>`;
const subpage = (p, inner) => pageFrame(p, `<div class="subpage">${inner}</div>`);
const formatTime = secs => Number.isFinite(secs) ? `${Math.floor(secs / 60)}:${String(Math.floor(secs % 60)).padStart(2,'0')}` : '0:00';
const ytEmbed = id => /^[a-zA-Z0-9_-]{6,20}$/.test(id || '') ? `https://www.youtube-nocookie.com/embed/${enc(id)}` : '';

function bootPage() {
  return `<main class="boot screen">${ambient()}
    <div class="topbar"><div class="brand-mark">FS // 24</div><button class="sound-toggle" type="button" data-action="toggle-sound" aria-label="${muted ? 'Enable' : 'Mute'} interface sound">${icon(muted ? 'mute' : 'sound')}<span>${muted ? 'SFX OFF' : 'SFX ON'}</span></button></div>
    <div class="boot__content"><div class="eyebrow">BSIT 3-2</div><div class="mega-title" aria-label="Fighter Select"><span>PROFILE</span><span class="mega-title__outline">SELECT</span></div><p class="boot__subtitle">uwu</p>${linkButton('/select', `START&nbsp;&nbsp; ${icon('arrow')}`)}<div class="press-start">PRESS START TO CONTINUE</div></div>
    <div class="boot__footer"><span>Jaemar Ibanez</span><span>Alfrancis Juvir Delos Trino</span><span>Pauleen Alisa Amatorio</span><span>Richmond Ebasan</span></div>
  </main>`;
}

function selectPage() {
  const display = playerById(selectedId || hoveredId) || players[0];
  return `<main class="select screen" style="${palette(display)}">${ambient('red')}
    <header class="select__header"><a class="mini-brand" href="/">PROFILE <span class="fg-inline-bold">SELECT</span></a><div class="round-label">ROSTER / 04</div></header>
    <section class="select__intro"><div><div class="eyebrow">YOOHOOOO PILI NA!</div><div class="display-title">SELECT STUDENT</div></div><p id="select-intro">${selectedId ? 'Selection locked. Confirm your fighter.' : e(display.intro)}</p></section>
    <section class="fighter-grid" aria-label="Fighter roster">${players.map(p => `<button class="fighter-card ${selectedId === p.id ? 'is-selected' : ''}" aria-pressed="${selectedId === p.id}" style="${palette(p)}" data-action="select-player" data-id="${e(p.id)}" type="button">
      ${portrait(p, {interactive:true,local:true})}<div class="fighter-card__shade"></div><div class="fighter-card__number">${e(p.number)}</div><div class="fighter-card__meta"><span>PLAYER ${e(p.number)}</span><strong>${e(selectNames[p.id])}</strong><small>${e(selectTitles[p.id])}</small></div><div class="fighter-card__corner">+</div>
    </button>`).join('')}</section>
    <section class="selection-bar"><div class="selection-bar__status"><span id="selection-caption">${selectedId ? 'SELECTED:' : 'CURRENT TARGET'}</span><strong id="selection-name">${e(selectNames[display.id])}</strong><small id="selection-title">${selectedId ? e(selectTitles[display.id]) : 'Click to lock in'}</small></div>
    <div class="selection-bar__actions">${btn('RANDOM SELECT','random-select','ghost')}${btn(`${selectedId ? 'READY / CONFIRM' : 'SELECT A FIGHTER'} ${icon('arrow')}`, 'confirm-select','primary',!selectedId)}</div></section>
    <nav class="select__nav" aria-label="Secondary navigation"><a href="/">BACK TO MENU</a><a href="/versus">GROUP VERSUS</a></nav>
  </main>`;
}
function updateHover(id) {
  hoveredId = id;
  if (selectedId) return;
  const p = playerById(id);
  if (!p) return;
  const el = document.querySelector('main.select');
  if (el) el.setAttribute('style',palette(p));
  const intro = document.getElementById('select-intro'); if (intro) intro.textContent = p.intro;
  const name = document.getElementById('selection-name'); if (name) name.textContent = selectNames[p.id];
}

const lifeStoryById = id => lifeStories.find(story => story.playerId === id);
const LIFE_SAVE_VERSION = 2;
const lifeSaveKey = id => `fighter-select-life-v${LIFE_SAVE_VERSION}:${id}`;
const lifeStatDescriptions = {Happiness:'Joy',Energy:'Wellbeing',Smarts:'Knowledge',Confidence:'Courage',Social:'Friendships'};
const lifeStages = ['FIRST YEAR','SECOND YEAR','THIRD YEAR','FOURTH YEAR','GRADUATION'];

function initialLifeState(p) {
  const story = lifeStoryById(p.id);
  return {
    version:LIFE_SAVE_VERSION,
    playerId:p.id,
    current:story.startNode,
    stats:{...story.startingStats},
    story:[],
    history:[]
  };
}
function readLifeSave(p) {
  const storyline = lifeStoryById(p.id);
  if (!storyline) return null;
  try {
    const saved=JSON.parse(localStorage.getItem(lifeSaveKey(p.id)));
    if (!saved || saved.version!==LIFE_SAVE_VERSION || saved.playerId!==p.id || !storyline.nodes[saved.current]
        || !Array.isArray(saved.story) || !Array.isArray(saved.history)
        || saved.story.length>5 || saved.history.length>5
        || !lifeStatNames.every(key=>Number.isInteger(saved.stats?.[key]) && saved.stats[key]>=0 && saved.stats[key]<=100)
        || saved.story.length!==saved.history.length) return null;
    return saved;
  } catch { return null; }
}
function saveLife(p) {
  try { localStorage.setItem(lifeSaveKey(p.id),JSON.stringify(lifeState)); } catch { /* private browsing may disable storage */ }
}
function loadLife(p) {
  if (!lifeState || lifeState.playerId!==p.id) lifeState=readLifeSave(p) || initialLifeState(p);
  return lifeState;
}
function graduationEnding(storyline, current) {
  // Score the changes resulting from decisions, not the character's starting stats.
  const delta = key => current.stats[key]-storyline.startingStats[key];
  const candidates = [
    ['scholar',delta('Smarts')*1.3+delta('Energy')*.2],
    ['connector',delta('Social')*1.3+delta('Happiness')*.25],
    ['trailblazer',delta('Confidence')*1.3+delta('Happiness')*.25]
  ];
  candidates.sort((a,b)=>b[1]-a[1]);
  return storyline.endings[candidates[0][0]];
}
function statEffectsText(effects) {
  return Object.entries(effects).map(([key,change])=>`${change>0?'+':''}${change} ${key}`).join('  ·  ');
}
function lifePage(p) {
  const storyline=lifeStoryById(p.id);
  if(!storyline) return missingPage();
  const state=loadLife(p);
  const scene=storyline.nodes[state.current];
  const finished=state.current==='graduation';
  const ending=finished?graduationEnding(storyline,state):null;
  const steps=state.story.length;
  const progress=finished?100:Math.round(steps/5*100);
  return `<main class="life-game screen" style="${palette(p)}">${ambient()}
    <header class="select__header life-game__header"><a class="mini-brand" href="${purl(p)}">FIGHTER <b>LIFE</b></a><div class="life-top-actions"><span class="round-label">STORY SAVE / ${e(p.number)}</span><a class="life-top-exit" href="${purl(p)}">EXIT TO PROFILE ${icon('back')}</a></div></header>
    <div class="life-game__layout"><aside class="life-card panel">
      <div class="life-card__portrait">${portrait(p)}<span>PLAYER ${e(p.number)}</span></div>
      <div class="life-card__identity"><small>THE LIFE OF</small><strong>${e(storyline.alias)}</strong><span>${e(selectTitles[p.id])} · ${e(p.title)}</span><div class="life-character-description">${e(storyline.tagline)}</div></div>
      <div class="life-age-card"><span>AGE</span><strong>${scene.age}</strong><div>${finished?'COLLEGE GRADUATE':e(scene.year)}</div></div>
      <div class="life-card__stats" aria-label="Current life stats">${lifeStatNames.map(name => `<div class="life-meter"><div><span>${e(name)}</span><b>${state.stats[name]}%</b></div><div class="life-meter__track"><i style="width:${state.stats[name]}%"></i></div></div>`).join('')}</div>
      <div class="life-card__footer">Your decisions change these stats. Progress saves automatically on this device.</div>
    </aside>
    <section class="life-story">
      <div class="life-story__heading"><div><div class="eyebrow">${e(storyline.alias)}'S STORY / INTERACTIVE LIFE SIMULATOR</div><h1>YOUR LIFE.<br><span>YOUR RULES.</span></h1></div><p>${e(storyline.intro)}</p></div>
      <div class="life-progress panel"><div class="life-progress__top"><span>YOUR JOURNEY</span><strong>${finished?'5 / 5 · GRADUATED':`${steps} / 5 CHOICES MADE`}</strong></div><div class="life-progress__bar" role="progressbar" aria-label="Life journey progress" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${progress}"><i style="width:${progress}%"></i></div><div class="life-progress__stages">${lifeStages.map((stage,i)=>`<span class="${finished||i<=steps?'is-reached':''}">${e(stage)}</span>`).join('')}</div></div>
      ${finished ? `<div class="life-event life-event--complete panel" aria-live="polite">
        <div class="grad-celebrate" aria-hidden="true"><span>✦</span><span>🎓</span><span>✦</span></div>
        <span class="life-event__kicker">AGE 22 / FOUR YEARS COMPLETED / GRADUATION DAY</span>
        <h2>YOU <span class="life-graduated">GRADUATED!</span></h2>
        <div class="life-degree"><span>CLASS OF YOUR OWN STORY</span><strong>${e(ending.title)}</strong><p>${e(ending.description)}</p></div>
        <p>Congratulations! ${e(storyline.alias)} finished college. Your choices shaped this version of their journey. Replay to discover different branches and graduation stories.</p>
        <div class="life-event__actions">${btn('↻ PLAY A DIFFERENT LIFE','restart-life')}${linkButton(purl(p),'BACK TO CHARACTER','ghost')}</div>
      </div>` : `<article class="life-event panel" aria-live="polite">
        <div class="life-event__top"><span class="life-event__kicker">${e(scene.year)} / DECISION ${steps+1} OF 5</span><b>AGE ${scene.age}</b></div>
        <div class="life-event__emoji" aria-hidden="true">${scene.age===18?'🏫':scene.age===19?'📚':scene.age===20?'💡':'🎓'}</div>
        <h2>${e(scene.title)}</h2><p>${e(scene.prompt)}</p>
        <div class="life-choice-head"><b>WHAT WILL ${e(storyline.alias)} DO?</b><span>CHOOSE YOUR NEXT MOVE</span></div>
        <div class="life-choices">${scene.choices.map((choice,i)=>`<button type="button" data-action="life-choice" data-index="${i}" aria-label="${e(choice.label)}"><span>0${i+1}</span><strong>${e(choice.label)}</strong><small>${e(statEffectsText(choice.effects))}</small>${icon('arrow')}</button>`).join('')}</div>
      </article>`}
      ${steps?`<section class="life-chronicle"><div class="life-chronicle__head"><div><span>YOUR STORY SO FAR</span><h3>Life timeline</h3></div><div class="life-story-tools">${btn('↶ UNDO LAST CHOICE','undo-life','ghost')}${btn('↻ RESTART','restart-life','ghost')}</div></div>
      <div class="life-timeline" aria-label="Life choice history">${state.story.slice().reverse().map((memory,i)=>`<article class="life-memory"><div class="life-memory__age">AGE <strong>${memory.age}</strong></div><div><span>${e(memory.year)}</span><p><b>${e(memory.choice)}</b> — ${e(memory.result)}</p></div></article>`).join('')}
      ${finished?`<article class="life-memory life-memory--graduation"><div class="life-memory__age">AGE <strong>22</strong></div><div><span>THE FINAL CHAPTER</span><p>🎓 ${e(storyline.alias)} graduated from college!</p></div></article>`:''}</div></section>`:''}
      <div class="life-footer-links"><a href="${purl(p)}">${icon('back')} RETURN TO CHARACTER PROFILE</a><a href="/select">CHOOSE ANOTHER LIFE ${icon('arrow')}</a></div>
    </section></div>
  </main>`;
}
function chooseLife(index) {
  if (!lifeState || !Number.isInteger(index)) return;
  const p=playerById(lifeState.playerId);
  const storyline=lifeStoryById(p?.id);
  const scene=storyline?.nodes[lifeState.current];
  const choice=scene?.choices?.[index];
  if (!choice || !storyline.nodes[choice.next]) return;
  lifeState.history.push({current:lifeState.current,stats:{...lifeState.stats}});
  for (const [name, change] of Object.entries(choice.effects)) {
    lifeState.stats[name]=Math.max(0,Math.min(100,lifeState.stats[name]+change));
  }
  lifeState.story.push({age:scene.age,year:scene.year,choice:choice.label,result:choice.result});
  lifeState.current=choice.next;
  saveLife(p);
  render();
  document.querySelector('.life-event')?.scrollIntoView({behavior:'smooth',block:'start'});
}
function undoLife() {
  if (!lifeState?.history.length) return;
  const previous=lifeState.history.pop();
  lifeState.current=previous.current;
  lifeState.stats=previous.stats;
  lifeState.story.pop();
  const p=playerById(lifeState.playerId);
  if (p) saveLife(p);
  render();
}
function restartLife() {
  const p=playerById(lifeState?.playerId);
  if (!p) return;
  lifeState=initialLifeState(p);
  saveLife(p);
  render();
}

function profilePage(p) {
  return pageFrame(p, `<section class="hero">
      <div class="hero__copy"><div class="eyebrow">${e(p.fighterId)} / ONLINE</div><div class="hero__name"><span>${e(p.nickname)}</span><em>${e(p.title)}</em></div><p>${e(p.intro)}</p><blockquote>${e(p.quote)}</blockquote>
        <div class="hero__actions">${linkButton(`/life/${enc(p.id)}`,`🎮 PLAY ${e(selectNames[p.id])}'S LIFE ${icon('arrow')}`)}${linkButton(`${purl(p)}/music`,'OPEN SOUNDTRACK','ghost')}${linkButton(`${purl(p)}/games`,'GAME LIBRARY','ghost')}</div></div>
      <div class="hero__visual"><div class="hero__number">${e(p.number)}</div>${portrait(p,{hero:true})}<div class="hero__tag">READY TO FIGHT</div><small>${e(p.photoCredit)}</small></div>
      <div class="hero__quick"><div><span>FULL NAME</span><strong>${e(p.name)}</strong></div><div><span>ROLE</span><strong>${e(p.role)}</strong></div><div><span>PERSONALITY</span><strong>${e(p.personality)}</strong></div></div>
    </section>
    <section class="profile-life-banner panel"><div class="profile-life-banner__copy"><div class="eyebrow">NEW FEATURE / LIFE SIMULATION</div><h2>LIVE ${e(selectNames[p.id])}'S <span>STORY.</span></h2><p>Step into a fictional college journey inspired by this character. Make decisions, unlock different story branches, track your stats, and reach graduation. Your progress saves automatically.</p></div><div class="profile-life-banner__cta"><span>5 DECISIONS · MULTIPLE PATHS · GRADUATION FINALE</span>${linkButton(`/life/${enc(p.id)}`,`PLAY THIS LIFE ${icon('arrow')}`)}</div></section>
    <section class="content-section">${sectionHead('01','FIGHTER DATA','PLAYER PROFILE')}
      <div class="data-grid"><div class="info-card panel">${[['Legal name',p.name],['Age',p.age],['Birthday',p.birthday],['Occupation',p.role]].map(([label,val]) => `<div class="info-row"><span>${e(label)}</span><strong>${e(val)}</strong></div>`).join('')}</div>
      <div class="stats panel">${Object.entries(p.stats).map(([name,val]) => `<div class="stat"><div><span>${e(name)}</span><strong>${val}</strong></div><div class="stat__track"><i style="width:${val}%"></i></div></div>`).join('')}</div>
      <div class="fun-facts panel"><span class="panel-label">FUN FACT FILES</span>${p.funFacts.map((fact,i) => `<div><b>0${i+1}</b><p>${e(fact)}</p></div>`).join('')}</div></div>
    </section>
    <section class="content-section">${sectionHead('02','COMBAT LOADOUT','SKILLS & ABILITIES')}
      <div class="ability-grid">${p.abilities.map((a,i) => `<article class="ability panel"><div class="ability__top"><span>${e(a.kind)} skill</span><b>0${i+1}</b></div><div class="ability__glyph">${e(a.name.slice(0,2).toUpperCase())}</div><div class="card-title">${e(a.name)}</div><p>${e(a.description)}</p><div class="ability__level"><span>MASTERY</span><strong>${a.level}%</strong></div></article>`).join('')}</div>
    </section>
    <section class="content-section content-section--last">${sectionHead('03','SIDE QUESTS','HOBBIES')}
      <div class="hobby-grid">${p.hobbies.map((h,i) => `<a class="hobby-card panel" href="${purl(p)}/hobby/${enc(h.slug)}"><span>0${i+1}</span><small>${e(h.kicker)}</small><div class="card-title">${e(h.name)}</div><p>${e(h.description)}</p><i>${icon('arrow')}</i></a>`).join('')}</div></section>`);
}

function musicPage(p) {
  if (!musicState || musicState.playerId !== p.id) musicState = {playerId:p.id,track:0,volume:0.8};
  const track = p.tracks[musicState.track];
  const video = p.videos[0];
  return subpage(p, `${back(purl(p),'BACK TO PROFILE')}${sectionHead('M01', `${p.nickname}'S AUDIO ARCHIVE`, 'MUSIC LOADOUT')}
    <div class="music-console panel">
      <audio id="music-audio" preload="metadata" src="${e(track.src)}"></audio>
      <div class="album-art"><span>${String(musicState.track+1).padStart(2,'0')}</span><i></i><b>DEMO AUDIO</b></div>
      <div class="now-playing"><small>NOW PLAYING / PLAYABLE DEMO</small><div class="card-title">${e(track.title)}</div><p>${e(track.artist)}</p>
        <input type="range" class="range" id="music-progress" aria-label="Track progress" min="0" max="100" value="0">
        <div class="time-row"><span id="music-current-time">0:00</span><span id="music-duration">0:00</span></div>
        <div class="player-controls"><button type="button" aria-label="Previous track" data-action="track-prev">${icon('next')}</button><button type="button" aria-label="Play or pause" class="play-button" data-action="track-toggle" id="music-play">${icon('play')}</button><button type="button" aria-label="Next track" data-action="track-next">${icon('next')}</button><label>VOL <input type="range" id="music-volume" aria-label="Volume" value="${Math.round(musicState.volume*100)}" max="100" min="0"></label></div>
      </div>
      <div class="track-list"><span class="panel-label">PLAYLIST / ${p.tracks.length} TRACKS</span>
        ${p.tracks.map((item,i) => `<button type="button" data-action="choose-track" data-index="${i}" class="${i === musicState.track ? 'is-active' : ''}"><b>0${i+1}</b><span>${e(item.title)}<small>${e(item.artist)}</small></span><i>LOAD</i></button>`).join('')}
      </div>
    </div>
    <div class="music-meta"><div class="panel"><span class="panel-label">FAVORITE GENRES</span>${p.genres.map(genre=>`<b>${e(genre)}</b>`).join('')}</div>
      <div class="panel"><span class="panel-label">FAVORITE ARTISTS</span>${p.artists.map(artist=>`<b>${e(artist)}</b>`).join('')}</div>
      <div class="panel video-tease"><span class="panel-label">VIDEO CHANNEL</span><div class="card-title">${e(video.title)}</div><p>${e(video.artist)}</p>${linkButton(`${purl(p)}/video/${enc(video.id)}`,`WATCH MUSIC VIDEO ${icon('arrow')}`)}</div>
    </div>`);
}
function bindMusic() {
  const audio = document.getElementById('music-audio');
  if (!audio) return;
  audio.volume = musicState.volume;
  const progress = document.getElementById('music-progress');
  const durationEl = document.getElementById('music-duration');
  const currentEl = document.getElementById('music-current-time');
  audio.addEventListener('loadedmetadata', () => {
    if (Number.isFinite(audio.duration)) { progress.max = String(audio.duration); durationEl.textContent = formatTime(audio.duration); }
  });
  audio.addEventListener('timeupdate', () => { progress.value = String(audio.currentTime); currentEl.textContent = formatTime(audio.currentTime); });
  audio.addEventListener('ended', () => advanceTrack(1));
  audio.addEventListener('pause', updatePlayState);
  audio.addEventListener('play', updatePlayState);
  progress.addEventListener('input', () => { if (Number.isFinite(audio.duration)) audio.currentTime = +progress.value; });
  document.getElementById('music-volume').addEventListener('input', ev => {
    musicState.volume = +ev.target.value / 100; audio.volume = musicState.volume;
  });
}
function updatePlayState() {
  const audio = document.getElementById('music-audio');
  const playBtn = document.getElementById('music-play');
  if (audio && playBtn) playBtn.innerHTML = icon(audio.paused ? 'play' : 'pause');
  document.querySelectorAll('.track-list button').forEach((button,i) => {
    const label = button.querySelector('i');
    if (label) label.textContent = i === musicState.track && audio && !audio.paused ? 'PLAYING' : 'LOAD';
  });
}
function advanceTrack(direction) {
  if (!musicState) return;
  const p = playerById(musicState.playerId);
  musicState.track = (musicState.track + direction + p.tracks.length) % p.tracks.length;
  render();
}
function videoPage(p, videoId) {
  const v = p.videos.find(item => item.id === videoId) || p.videos[0];
  const source = ytEmbed(v.id);
  return subpage(p, `${back(`${purl(p)}/music`,'BACK TO SOUNDTRACK')}${sectionHead('V01','AUTHORIZED YOUTUBE EMBED','VIDEO CHANNEL')}
    <div class="video-layout"><div class="video-frame">${source ? `<iframe allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen loading="lazy" src="${source}" title="${e(v.title)}"></iframe>` : 'Video unavailable'}</div>
      <div class="video-copy panel"><span class="panel-label">NOW SCREENING</span><div class="card-title">${e(v.title)}</div><h3>${e(v.artist)}</h3><p>${e(v.description)}</p><div class="system-note">If the source owner disables embedding, open the configured YouTube URL directly.</div></div></div>`);
}

function gamesPage(p) {
  const categories = [...new Set(p.games.map(g => g.category))];
  return subpage(p, `${back(purl(p),'BACK TO PROFILE')}${sectionHead('G01',`${p.nickname}'S SAVE DATA`,'MY GAME LIBRARY')}
    <div class="filter-row">${categories.map(category => `<span>${e(category)}</span>`).join('')}</div>
    <div class="game-grid">${p.games.map(g => `<a class="game-card panel" href="${purl(p)}/games/${enc(g.slug)}"><div class="game-cover"><span>${e(g.cover)}</span><b>${e(p.nickname)}</b></div><small>${e(g.category)} / ${e(g.platform)}</small><div class="card-title">${e(g.title)}</div><p>${e(g.description)}</p><i>OPEN SAVE FILE ${icon('arrow')}</i></a>`).join('')}</div>`);
}
function gameDetailPage(p, slug) {
  const g = p.games.find(g => g.slug === slug) || p.games[0];
  return subpage(p, `${back(`${purl(p)}/games`,'BACK TO LIBRARY')}
    <div class="game-detail"><div class="game-detail__art"><span>${e(g.cover)}</span><b>${e(g.category)}</b></div><div class="game-detail__copy"><div class="eyebrow">SAVE FILE / ${e(g.slug.toUpperCase())}</div><div class="display-title">${e(g.title)}</div><p>${e(g.description)}</p>
      ${[['PLATFORM',g.platform],['FAVORITE ROLE',g.role],['MODE',g.category]].map(([label,val]) => `<div class="detail-row"><span>${e(label)}</span><strong>${e(val)}</strong></div>`).join('')}</div></div>
    ${g.videoId && ytEmbed(g.videoId) ? `<div class="video-frame video-frame--game"><iframe allowfullscreen loading="lazy" src="${ytEmbed(g.videoId)}" title="${e(g.title)} gameplay"></iframe></div>` : `<div class="media-placeholder panel">${icon('play')}<div><b>GAMEPLAY SLOT EMPTY</b><span>Add an authorized YouTube video ID in data/players.json.</span></div></div>`}`);
}
function hobbyPage(p, slug) {
  const h = p.hobbies.find(h => h.slug === slug) || p.hobbies[0];
  if (h.slug === 'gaming') { history.replaceState({}, '', `${purl(p)}/games`); return gamesPage(p); }
  return subpage(p, `${back(purl(p),'BACK TO PROFILE')}<div class="hobby-hero"><span>${e(h.kicker)}</span><div class="display-title">${e(h.name)}</div><p>${e(h.description)}</p></div>
    <div class="showcase-grid">${h.items.map((item,i) => `<div class="showcase-card panel"><span>ARCHIVE 0${i+1}</span><div class="showcase-card__art">${icon('spark')}</div><div class="card-title">${e(item)}</div><p>Replace this card with ${e(h.name.toLowerCase())} details, images, links, or an authorized embed.</p></div>`).join('')}</div>`);
}

function versusPage() {
  return `<main class="versus screen">${ambient('red')}${navHeader('SELECT','TEAM BATTLE')}
    <div class="versus__title"><small>FOUR PLAYERS ENTER</small><div>THE WHOLE <b>ROSTER</b></div><p>Four personalities. One unbeatable party.</p></div>
    <div class="versus-grid">${players.map((p,i) => `<div class="versus-card" style="${palette(p)}">${portrait(p)}<div><span>P${e(p.number)}</span><strong>${e(p.nickname)}</strong><small>${e(p.title)}</small></div>${i < players.length - 1 ? '<i>VS</i>':''}</div>`).join('')}</div>
    <div class="versus__actions">${linkButton('/roster',`MEET THE WHOLE ROSTER ${icon('arrow')}`)}${linkButton('/select','BACK TO SELECT','ghost')}</div>
  </main>`;
}
function rosterPage() {
  return `<main class="roster-page screen">${ambient()}${navHeader('SELECT','FRIENDSHIP MODE')}
    <section class="roster-hero"><div class="eyebrow">GROUP PROFILE / CO-OP MODE</div><div class="display-title">ONE ROSTER.<br>ZERO QUIET MOMENTS.</div><p>This space is ready for the group’s real story, shared memories, and favorite traditions.</p></section>
    <section class="memory-grid">${memoryTitles.map((title,i) => `<article class="memory panel"><span>MEMORY 0${i+1}</span><div class="card-title">${e(title)}</div><p>Add a true group memory or friendship fact here.</p></article>`).join('')}</section>
    <section class="roster-strip">${players.map(p => `<a style="${palette(p)}" href="${purl(p)}">${portrait(p)}<span>${e(p.nickname)}<small>${e(p.title)}</small></span></a>`).join('')}</section>
  </main>`;
}
function missingPage() {
  return `<main class="boot screen">${ambient()}<div class="boot__content"><div class="eyebrow">ERROR / 404</div><div class="display-title">FIGHTER NOT FOUND</div><p>This player or page is not in the roster.</p>${linkButton('/select',`BACK TO SELECT ${icon('arrow')}`)}</div></main>`;
}
function render() {
  if (!players.length) return;
  const path = decodeURIComponent(location.pathname).split('/').filter(Boolean);
  let html;
  if (!path.length) html = bootPage();
  else if (path.length===1 && path[0]==='select') html=selectPage();
  else if (path.length===1 && path[0]==='versus') html=versusPage();
  else if (path.length===1 && path[0]==='roster') html=rosterPage();
  else if (path.length===2 && path[0]==='life' && playerById(path[1])) html=lifePage(playerById(path[1]));
  else if (path[0]==='profile' && playerById(path[1])) {
    const p = playerById(path[1]);
    if (path.length===2) html=profilePage(p);
    else if (path.length===3 && path[2]==='music') html=musicPage(p);
    else if (path.length===4 && path[2]==='video') html=videoPage(p,path[3]);
    else if (path.length===3 && path[2]==='games') html=gamesPage(p);
    else if (path.length===4 && path[2]==='games') html=gameDetailPage(p,path[3]);
    else if (path.length===4 && path[2]==='hobby') html=hobbyPage(p,path[3]);
  }
  app.innerHTML = html || missingPage();
  document.title = `${playerById(path[1])?.nickname || 'Fighter Select'} | Four-Player Edition`;
  const audio = document.getElementById('music-audio'); if (audio) bindMusic();
  app.querySelectorAll('img').forEach(img => {
    img.addEventListener('error', () => {
      img.hidden = true;
      const portraitEl = img.closest('.portrait');
      if (portraitEl) {
        const base = portraitEl.querySelector('.portrait__pose--base');
        if (img === base) {
          const fb = portraitEl.querySelector('.portrait__fallback');
          if (fb) fb.hidden = false;
        }
      }
    });
  });
  app.querySelectorAll('.fighter-card').forEach(card => {
    card.addEventListener('mouseenter', () => updateHover(card.dataset.id));
    card.addEventListener('focus', () => updateHover(card.dataset.id));
  });
}
function navigate(url, replace=false) {
  const normalized = new URL(url,window.location.href);
  if (normalized.origin!==location.origin) { location.assign(normalized.href); return; }
  if (replace) history.replaceState({},'',normalized.pathname);
  else if (location.pathname!==normalized.pathname) history.pushState({},'',normalized.pathname);
  window.scrollTo(0,0);
  render();
}
app.addEventListener('click', ev => {
  const anchor = ev.target.closest('a[href]');
  if (anchor && ev.button===0 && !ev.ctrlKey && !ev.metaKey && !ev.shiftKey && !ev.altKey && !anchor.target) {
    const target = new URL(anchor.href,location.href);
    if (target.origin===location.origin) { ev.preventDefault(); navigate(target.pathname); return; }
  }
  const button = ev.target.closest('button[data-action]');
  if (!button || button.disabled) return;
  const action=button.dataset.action;
  if (action==='toggle-sound') { muted=!muted; render(); }
  else if (action==='select-player') { selectedId=button.dataset.id; hoveredId=selectedId; render(); }
  else if (action==='random-select') { const p=players[Math.floor(Math.random()*players.length)]; selectedId=p.id; hoveredId=p.id; render(); }
  else if (action==='confirm-select') { if (selectedId) navigate(`/life/${enc(selectedId)}`); }
  else if (action==='life-choice') chooseLife(+button.dataset.index);
  else if (action==='undo-life') undoLife();
  else if (action==='restart-life') restartLife();
  else if (action==='track-prev') advanceTrack(-1);
  else if (action==='track-next') advanceTrack(1);
  else if (action==='choose-track') { musicState.track=+button.dataset.index; render(); }
  else if (action==='track-toggle') {
    const audio=document.getElementById('music-audio');
    if (audio) {
      if (audio.paused) audio.play().catch(() => {
        button.setAttribute('title','Audio could not load. Check your internet connection.');
      }); else audio.pause();
    }
  }
});
window.addEventListener('popstate',render);
async function start() {
  try {
    const responses = await Promise.all(['/api/players','/api/life-stories'].map(url=>fetch(url,{headers:{Accept:'application/json'}})));
    if (responses.some(response=>!response.ok)) throw new Error('Could not load fighter profiles or life stories');
    const [data,stories] = await Promise.all(responses.map(response=>response.json()));
    if(!Array.isArray(data) || data.length!==4) throw new Error('Expected the original four-player roster');
    if(!Array.isArray(stories) || stories.length!==4) throw new Error('Expected four character-specific life stories');
    players=data; lifeStories=stories;
    render();
  } catch (error) {
    app.innerHTML = `<main class="boot screen">${ambient()}<div class="boot__content"><div class="display-title">ROSTER UNAVAILABLE</div><p>${e(error.message)}</p><p>The Java Spring Boot server must be running. Check GET /api/players.</p></div></main>`;
  }
}
start();
