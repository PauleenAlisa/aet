package com.fighterselect.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fighterselect.model.LifeStory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Serves author-editable story graphs; fail fast when a choice links to a missing scene. */
@Service
public class LifeStoryService {
    private final List<LifeStory> stories;

    public LifeStoryService(ObjectMapper mapper, PlayerService players) throws IOException {
        try (InputStream in = new ClassPathResource("data/life-stories.json").getInputStream()) {
            stories = List.copyOf(mapper.readValue(in, new TypeReference<List<LifeStory>>() {}));
        }
        if (stories.size() != players.findAll().size()) {
            throw new IllegalStateException("Every fighter needs one life story");
        }
        Set<String> ids = new HashSet<>();
        for (LifeStory story : stories) {
            players.findById(story.playerId());
            if (!ids.add(story.playerId())) {
                throw new IllegalStateException("Duplicate life story for " + story.playerId());
            }
            validate(story);
        }
    }

    public List<LifeStory> findAll() {
        return stories;
    }

    public LifeStory findByPlayerId(String playerId) {
        return stories.stream()
                .filter(s -> s.playerId().equals(playerId))
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Life story not found: " + playerId));
    }

    private static void validate(LifeStory story) {
        Map<String, LifeStory.LifeNode> nodes = story.nodes();
        if (nodes == null || nodes.isEmpty() || !nodes.containsKey(story.startNode())
                || !nodes.containsKey("graduation")) {
            throw new IllegalStateException("Missing start or graduation scene: " + story.playerId());
        }
        if (!nodes.get("graduation").choices().isEmpty()) {
            throw new IllegalStateException("Graduation must end the story");
        }
        if (story.endings() == null || !story.endings().keySet().containsAll(
                Set.of("scholar", "connector", "trailblazer"))) {
            throw new IllegalStateException("Missing graduation ending for " + story.playerId());
        }
        Set<String> completed = new HashSet<>();
        walk(story, story.startNode(), new HashSet<>(), completed);
        if (!completed.equals(nodes.keySet())) {
            throw new IllegalStateException("Unreachable scenes for " + story.playerId());
        }
    }

    private static void walk(LifeStory story, String sceneId, Set<String> active, Set<String> visited) {
        if ("graduation".equals(sceneId)) {
            visited.add(sceneId);
            return;
        }
        if (visited.contains(sceneId)) return;
        if (!active.add(sceneId)) {
            throw new IllegalStateException("Life story contains a cycle: " + story.playerId());
        }
        LifeStory.LifeNode scene = story.nodes().get(sceneId);
        if (scene == null || scene.choices() == null || scene.choices().size() < 2) {
            throw new IllegalStateException("Each scene needs branching choices: " + sceneId);
        }
        for (LifeStory.LifeChoice choice : scene.choices()) {
            if (choice.next() == null || !story.nodes().containsKey(choice.next())) {
                throw new IllegalStateException("Broken life choice in " + story.playerId() + ": " + sceneId);
            }
            if (!story.startingStats().keySet().containsAll(choice.effects().keySet())) {
                throw new IllegalStateException("Unknown stat in " + story.playerId() + ": " + sceneId);
            }
            walk(story, choice.next(), active, visited);
        }
        active.remove(sceneId);
        visited.add(sceneId);
    }
}
