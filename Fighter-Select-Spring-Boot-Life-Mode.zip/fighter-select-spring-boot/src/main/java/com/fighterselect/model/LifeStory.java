package com.fighterselect.model;

import java.util.List;
import java.util.Map;

/** Editable, branching fictional college-life storyline for one fighter. */
public record LifeStory(
        String playerId,
        String alias,
        String tagline,
        String intro,
        String startNode,
        Map<String, Integer> startingStats,
        Map<String, LifeNode> nodes,
        Map<String, LifeEnding> endings
) {
    public record LifeNode(
            int age,
            String year,
            String title,
            String prompt,
            List<LifeChoice> choices
    ) {}

    public record LifeChoice(
            String label,
            String result,
            String next,
            Map<String, Integer> effects
    ) {}

    public record LifeEnding(String title, String description) {}
}
