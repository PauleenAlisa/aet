package com.fighterselect;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class FighterSelectApplicationTests {
    @Autowired MockMvc mvc;

    @Test
    void listsOriginalFourPlayers() throws Exception {
        mvc.perform(get("/api/players"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(4))
                .andExpect(jsonPath("$[0].id").value("nova"))
                .andExpect(jsonPath("$[1].id").value("mimi"))
                .andExpect(jsonPath("$[2].id").value("echo"))
                .andExpect(jsonPath("$[3].id").value("jax"));
    }

    @Test
    void playerDetailAndNotFound() throws Exception {
        mvc.perform(get("/api/players/echo"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.fighterId").value("FTR-003"))
                .andExpect(jsonPath("$.hobbies.length()").value(3));
        mvc.perform(get("/api/players/unknown"))
                .andExpect(status().isNotFound());
    }

    @Test
    void supportsDeepLinksToPages() throws Exception {
        mvc.perform(get("/select")).andExpect(status().isOk())
                .andExpect(forwardedUrl("/index.html"));
        mvc.perform(get("/profile/nova/music")).andExpect(status().isOk())
                .andExpect(forwardedUrl("/index.html"));
        mvc.perform(get("/life/jax")).andExpect(status().isOk())
                .andExpect(forwardedUrl("/index.html"));
    }

    @Test
    void eachCharacterHasAUniqueBranchingCollegeLifeAndGraduation() throws Exception {
        for (String id : new String[]{"nova", "mimi", "echo", "jax"}) {
            mvc.perform(get("/api/life-stories/" + id))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.playerId").value(id))
                    .andExpect(jsonPath("$.startNode").value("start"))
                    .andExpect(jsonPath("$.nodes.start.choices.length()").value(2))
                    .andExpect(jsonPath("$.nodes.graduation.age").value(22))
                    .andExpect(jsonPath("$.nodes.graduation.choices.length()").value(0))
                    .andExpect(jsonPath("$.endings.scholar.title").isString())
                    .andExpect(jsonPath("$.endings.connector.title").isString())
                    .andExpect(jsonPath("$.endings.trailblazer.title").isString());
        }
        mvc.perform(get("/api/life-stories"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(4));
        mvc.perform(get("/api/life-stories/unknown"))
                .andExpect(status().isNotFound());
    }
}
