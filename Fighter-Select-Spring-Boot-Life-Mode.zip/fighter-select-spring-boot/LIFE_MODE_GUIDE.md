# Life Mode — Branching College Story Game

## How players start

1. Select a fighter, then open their **character profile**.
2. Press **PLAY THIS LIFE** (also available from the profile navigation).
3. Choose one of the two answers at each event. Each answer changes the player's stats and determines the next scene.
4. Play through **five decisions** spanning college years 1 through 4. The story **always ends with graduation at age 22**.
5. Graduation shows one of three character-specific summaries based on choices. **UNDO LAST CHOICE** rewinds the latest decision, and **RESTART** begins again.

The player select flow also enters Life Mode when a character is confirmed. A different save is kept for every fighter in the current browser's `localStorage`.

## Stories currently included

| Fighter | Nickname | Story theme | School-life dilemmas |
|---|---|---|---|
| `nova` | JI / Sunoo | Calm competitor | Class friendships, gaming tournaments, software projects, mentoring and capstone defense |
| `mimi` | PAU / Alisa | Creative supporter | Digital art, design club, UI prototyping, accessibility and supporting friends |
| `echo` | AL / Juvir | Observant creative | Music curation, media club, sound design, filmmaking and finding confidence |
| `jax` | MOND / Dekaizer | Energetic organizer | Party games, school events, balancing commitments, teamwork and capstone demos |

These stories are **fictional alternate lives**, inspired by the characters' existing descriptions. They are not records of the real people shown in the app.

## Customize a character's life

Edit `src/main/resources/data/life-stories.json` and restart the Spring Boot app.

Each story has:

- `playerId`: must match a fighter in `players.json`
- `intro`, `tagline`, `alias`: text shown in Life Mode
- `startingStats`: five numbers from 0 to 100
- `startNode`: first scene ID, currently `start`
- `nodes`: events keyed by their scene ID, with `age`, `year`, `title`, `prompt` and `choices`
- `endings`: three possible graduation messages (`scholar`, `connector`, `trailblazer`)

Each choice looks like:

```json
{
  "label": "Join the student club",
  "result": "You make friends who help on future projects.",
  "next": "friends",
  "effects": {"Social": 10, "Happiness": 5, "Energy": -4}
}
```

Change the `next` ID to send a choice to a different scene. **Do not remove or rename `graduation`**: it is the final scene and must have no choices. The Java service validates the story graph at app startup and rejects broken links, loops, or unreachable scenes.

To add a scene, add a named entry under `nodes`, with at least two choices. Make sure all routes lead to `graduation` and all authored scenes are reachable. The built-in progress UI currently assumes five decisions per journey; if you change the number of stages, update the number 5 in `static/js/app.js`.

## Save behavior

- Saves are local to the browser, not stored in a database or shared among devices.
- Saves from all four characters are independent.
- Progress resumes after refresh. Restart discards that character's previous path.
- If you substantially rewrite a story graph, bump `LIFE_SAVE_VERSION` in `static/js/app.js` to invalidate older saves.

## Java endpoints

- `GET /api/life-stories` — all four authored story graphs
- `GET /api/life-stories/nova` — just JI's story
- `GET /api/life-stories/mimi`, `/echo`, `/jax` — other characters
- `GET /life/nova` (browser route) — the interactive Life Mode for JI

There is **no React, npm, or database requirement** for this edition. Spring Boot serves JSON; the browser runs the choice interface.
