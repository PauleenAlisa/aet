# Fighter Select — Spring Boot Edition

A Java **Spring Boot 3** conversion of the uploaded **Four-Player Fighter Select** React/TypeScript site. The original source's four characters, images, text, music, games, stats, abilities, hobbies, and routes are retained. The interactive browser interface has been rewritten using **plain HTML/CSS/JavaScript**, with **Java Spring MVC REST endpoints** supplying character data; no Node.js, npm, or React server is needed.

## Requirements

- **Java JDK 17 or later** (JDK 21 also works)
- **Apache Maven 3.9+** (`mvn` must be available on PATH)
- Internet connection for the **first** Maven dependency download and for remote Unsplash images, example music, fonts, and YouTube embeds

## Run it (Windows PowerShell, CMD, macOS, or Linux)

1. Unzip the download.
2. Open a terminal **inside the `fighter-select-spring-boot` folder** where `pom.xml` is located.
3. Verify installations:

   ```bash
   java -version
   mvn -version
   ```

4. Run the application:

   ```bash
   mvn spring-boot:run
   ```

5. Open **http://localhost:8080** in a browser.
6. Stop the server using **Ctrl+C**.

To build a distributable executable JAR:

```bash
mvn clean package
java -jar target/fighter-select-1.0.0.jar
```

To run tests:

```bash
mvn test
```

### Eclipse / Spring Tools

`File` → `Import` → `Maven` → `Existing Maven Projects` → select the project root → `Finish`. Run `src/main/java/com/fighterselect/FighterSelectApplication.java` as a **Java Application** or **Spring Boot App**.

### IntelliJ IDEA

`Open` → select `pom.xml` / project folder → **Load Maven Project** → run `FighterSelectApplication`.

## Features carried over

- Intro screen and Start button
- Hover-responsive **four-fighter selection**, Random Select and Confirm
- **New: Five-decision BitLife-style college-life game for each fighter**, with personalized story scenes, meaningful branching choices, live stats, a rewind button, and a graduation finale (multiple graduation outcomes)
- Life Mode automatically saves each character’s progress in browser **localStorage**; resume after reloading, switch characters independently, restart, or undo the last choice
- Per-player profiles with stats, ability cards, fun facts, and hobby links
- Playable example audio with next/previous/seek/volume
- Embedded YouTube video page
- Games library, game details and video embeds
- Hobby galleries
- Group versus and full roster pages
- Browser back/forward navigation and direct-link refresh support

> The "SFX ON/OFF" control matches the original project's visual toggle. The original did not include sound effects. Remote demo audio and embeds require a connection. Placeholder player names and information have **not** been invented or filled in.

## Project structure

```text
pom.xml                                    Maven / Spring Boot dependencies
src/main/java/com/fighterselect/
  FighterSelectApplication.java            Java Spring Boot entry point
  controller/PageController.java           MVC routes for browser pages
  controller/PlayerController.java         JSON REST API
  model/Player.java                        Strongly typed Java records
  service/PlayerService.java               Loads/serves roster data
  model/LifeStory.java                     Strongly typed branching story, choices and endings
  service/LifeStoryService.java             Validates and serves each life story
  controller/LifeStoryController.java       Story REST API
src/main/resources/
  application.properties                   App configuration and port
  data/players.json                        All editable fighter data
  data/life-stories.json                   Editable scene graph for four life games
  static/index.html                        Browser app entry point
  static/css/app.css                       Original styles (Tailwind import removed)
  static/js/app.js                         React-free frontend interactions
  static/assets/                           Uploaded character images
src/test/java/com/fighterselect/           Spring MVC tests
original-source-reference/                Original TSX/TS code for reference
```

## Java REST API

| Method | URL | Purpose |
|---|---|---|
| GET | `/api/players` | List all four fighter profiles |
| GET | `/api/players/nova` | Get one fighter by ID (`nova`, `mimi`, `echo`, `jax`) |
| GET | `/api/players/unknown` | Returns HTTP 404 |
| GET | `/api/health` | Returns status and fighter count |
| GET | `/api/life-stories` | All four college-life story graphs |
| GET | `/api/life-stories/mimi` | One character’s branching storyline |

Other web pages are handled by `PageController` and rendered in the browser, including `/select`, `/versus`, `/roster`, `/life/{playerId}`, and the `/profile/{playerId}/...` pages.

## Customize player data

Open **`src/main/resources/data/players.json`**. All fighter properties originate from the original `src/data.ts` and can be edited directly: `name`, `age`, `birthday`, `role`, `portrait`, `stats`, `abilities`, `hobbies`, `tracks`, `videos`, `games`, etc. Restart Spring Boot after modifying the JSON.

The roster-card aliases (JI, PAU, AL, MOND) and titles (Sunoo, Alisa, Juvir, Dekaizer) originate from the original `App.tsx`, and are stored in the top of `static/js/app.js` as `selectNames` and `selectTitles`. Update those to change the roster card labels.

See **`LIFE_MODE_GUIDE.md`** for the gameplay walkthrough, branching rules, and a concrete JSON editing example.

### Customize Life Mode and graduation

Edit **`src/main/resources/data/life-stories.json`** to change the fictional choices or outcome text for any fighter. Every fighter has a `startNode`, `startingStats`, a `nodes` map and three `endings`. Each choice has `label`, `result`, numeric `effects`, and `next` (the ID of the next scene). All branches must end at the `graduation` scene; the Java service validates these links at startup. The ending shown at graduation is based on the changes in **Smarts**, **Social**, and **Confidence** from the player’s choices. The five decisions cover college life from age 18 through 21; the graduation page is age 22.

These are **fictional alternate-life scenarios inspired by the placeholder character profiles**, not claims about the real people represented by the characters. Replace scenarios with your own authorized story details. Progress is stored **locally on each browser/device**, independently for each player, rather than on a server or shared account. Restart the app after editing the JSON, and use **RESTART** to begin a new story if existing saves are from a different story version.

### Technical notes

- Spring Boot uses **Java** for the app server and API; **HTML/CSS/JavaScript** still runs in the browser for animations, choice selection, audio, and page rendering. Spring is not a browser UI framework.
- Character data is read-only from JSON; no database is required or claimed.
- Life Mode saves in browser localStorage and normally survives refreshes. Clearing site data or using another browser/device starts a different save.
- The frontend works only when served via the Spring Boot project, not by opening `index.html` directly from disk, because it fetches `/api/players`.
- Spring Boot 3.5.6 uses the Java 17 baseline. To change the port, edit `server.port=8080` in `application.properties`.
